/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

This library contains functions for target local time synchronization
via time protocol or via simple NTP protocol.


How to use:
-----------

When using time protocol, you just have to call:

rtime("hostname");

and your target's time is set. Check however the return of this function.
It may return ERROR if unable to connect to time server.

If you prefer to use SNTP time synchronization, here are the steps to perform.
First of all you have to tell the library what are your NTP servers:

sntpAddServer("server1.com");
sntrAddServer("server2.com");
...

You can add up to 16 servers (see trim.c if you want make more).
From the list of servers you've just specified the NTP client will choose
a one that works.
An NTP server reports a universal UTC time. You may want to see your local time
set on the target. For this you have to apply a time shift to the UTC value.
Pay attention that this shift may change when switching summer/winter time, or
changing time zone. You'll have to do all these adjustments manually.

sntpSetTimeShift(2, 0);

This will add 2 hours and 0 minutes to the UTC in order to obtain your local time.

When you're done with all these preliminaries, perform a final call:

sntpAdjust();

This function will perform an NTP transaction with one of the servers (with a first
one that responds, actually). On success function returns OK and your local time is
set (and previously specified time shift applied).

You may also want to perform time synchronization regularly. For this, instead of
calling sntpAdjust() you must call:

sntpStartTask(60);

This function launches a synchronization task that will perform SNTP synchronization
every 60 (argument value) seconds. The task created has a name 'sntpTask'.

--------------------------------------------------------------------------------
2009, by Arthur Benilov (arthur.benilov@gmail.com)
