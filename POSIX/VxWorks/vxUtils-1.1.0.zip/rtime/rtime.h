/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

#ifndef __RTIME_H__
#define __RTIME_H__

/**
 * @file rtime.h
 *
 * Target date/time synchronization with remote host
 * via TIME protocol (RFC 868) and SNTP protocol.
 */

#include <vxWorks.h> 

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Synchronize with TIME server
 *
 * @param hostname TIME server host
 * @return OK or ERROR
 */
STATUS rtime ( char *hostname );

/**
 * Add an NTP server to the list of servers.
 * @param hostname NTP server host name.
 * @return OK or ERROR if host name is invalid.
 *
 */
STATUS sntpAddServer ( char *hostname );

/**
 * Set time shift for local time reporting.
 * @param hours Hours shift to be added to UTC time.
 * @param minutes Minutes shift to be added to UTC time.
 * @return OK.
 */
STATUS sntpSetTimeShift ( int hours, int minutes );

/**
 * Perform time adjustment via NTP.
 * @return OK or ERROR if NTP transation failed.
 */
STATUS sntpAdjust ( void );

/**
 * Start automatic NTP time adjustment task.
 * @param period Synchronization period in seconds.
 * @return OK or ERROR if task cannot be started.
 */
STATUS sntpStartTask ( unsigned int period );

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* __RTIME_H__ */
/* End of file */
