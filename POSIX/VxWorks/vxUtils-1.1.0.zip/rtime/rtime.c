/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

#include "rtime.h"

#include <vxWorks.h>
#include <time.h>
#include <timers.h>
#include <sockLib.h>
#include <inetLib.h>
#include <hostLib.h>
#include <ioLib.h>
#include <taskLib.h>
#include <sysLib.h>
#include <logLib.h>
#include <sntpcLib.h>
#include <errno.h>
#include <string.h>

#define TIME_PORT   37          /* TIME server TCP port */
#define TIME_ORIGIN 2208988800U /* Seconds for 01.01.1970 */

#define SNTP_TIMEOUT    200     /* SNTP timeout interval in ticks */
#define HOSTNAME_LENGTH 64      /* Host name string length */
/* NTP time offset (starting 1970) */
#define NTP_EPOCH       (86400U * (365U * 70U + 17U))
#define NTP_PORT        123     /* NTP server IP port number */
#define NTP_TIMEOUT     1000    /* Timeout waiting server's response, ms */
/* Maximal number of servers handled by this library */
#define NTP_MAX_SERVERS 16
#define NTP_PRIORITY    100     /* SNTP task priority */
#define NTP_STACK       4096    /* SNTP task stack size */

/**
 * Structure used to hold information on
 * NTP server.
 */
typedef
struct ntp_server_s {
    struct sockaddr_in addr;        /* Server IP address */
    char hostname[HOSTNAME_LENGTH]; /* Server host name */
} ntp_server_t;

/**
 * Structure describing the NTP packet.
 * See NTP protocol implementation for more information.
 */
typedef
struct ntp_packet {
    unsigned char mode : 3;
    unsigned char vn : 3;
    unsigned char li : 2;
    unsigned char stratum;
    char poll;
    char precision;
    unsigned long root_delay;
    unsigned long root_dispersion;
    unsigned long reference_identifier;
    unsigned long reference_timestamp_secs;
    unsigned long reference_timestamp_fraq;
    unsigned long originate_timestamp_secs;
    unsigned long originate_timestamp_fraq;
    unsigned long receive_timestamp_secs;
    unsigned long receive_timestamp_fraq;
    unsigned long transmit_timestamp_secs;
    unsigned long transmit_timestamp_fraq;
} ntp_packet_t;

/* Set of configured NTP servers */
static ntp_server_t ntp_servers[NTP_MAX_SERVERS];
static int ntp_servers_num = 0; /* Number of configured servers */
static int sntpTaskId      = 0; /* SNTP synchronizing task id */
static int sntpTaskDelay   = 0; /* SNTP task delay, in ticks */
static int secs_shift      = 0; /* Target time shift starting UTC, seconds */

/* ------------------------------------------------------ */

STATUS sntpAddServer ( char *hostname ) {
    if ( ntp_servers_num >= NTP_MAX_SERVERS ) {
        logMsg("%s NTP servers has been already configured. Cannot append more.\n", ntp_servers_num);
        return ERROR;
    }
    
    bzero(ntp_servers[ntp_servers_num].hostname, HOSTNAME_LENGTH);
    strncpy(ntp_servers[ntp_servers_num].hostname, hostname, HOSTNAME_LENGTH);
    
    /* Getting server's address */
    bzero((char *)&(ntp_servers[ntp_servers_num].addr), sizeof(struct sockaddr_in));
    
    ntp_servers[ntp_servers_num].addr.sin_family = AF_INET;
    ntp_servers[ntp_servers_num].addr.sin_port = htons(NTP_PORT);
            
    if ( ((ntp_servers[ntp_servers_num].addr.sin_addr.s_addr = inet_addr(hostname)) == (unsigned)ERROR) &&
         ((ntp_servers[ntp_servers_num].addr.sin_addr.s_addr = hostGetByName(hostname)) == (unsigned)ERROR) ) {
                logMsg("Cannot resolve '%s' host\n", hostname);
                return ERROR;
    }

    ntp_servers_num++;
    
    return OK;
}

/* ------------------------------------------------------ */

STATUS sntpSetTimeShift ( int hours, int minutes ) {
    secs_shift = (60 * hours + minutes) * 60;
    return OK;
}

/* ------------------------------------------------------ */

STATUS sntpGet ( ntp_server_t *server, struct timespec *ts ) {
    ntp_packet_t ntp_packet;
    
    int s;
    int rc;
    fd_set fds;
    struct timeval timeout;
    
    s = socket(AF_INET, SOCK_DGRAM, 0);
    if ( s < 0 ) {
        return s;
    }
    
    /* Connecting to NTP server */
    rc = connect(s, (struct sockaddr *) &server->addr, sizeof(struct sockaddr_in));
    if ( rc < 0 ) {
        close(s);
        return rc;
    }
    
    /* Initialize NTP packet */
    memset(&ntp_packet, 0, sizeof(ntp_packet));
    ntp_packet.vn = 4;
    ntp_packet.mode = 3;
    ntp_packet.originate_timestamp_secs = htonl(time(NULL) + NTP_EPOCH);
    
    rc = send(s, (char*)&ntp_packet, sizeof(ntp_packet), 0);
    if ( rc != sizeof(ntp_packet) ) {
        close(s);
        return ERROR;
    }
 
    /* Waiting for the answer */
    FD_ZERO(&fds);
    FD_SET(s, &fds);
    timeout.tv_sec = NTP_TIMEOUT / 1000;
    timeout.tv_usec = (NTP_TIMEOUT % 1000) * 1000;
    rc = select(s+1, &fds, NULL, NULL, &timeout);
    if ( rc == 0 || rc == ERROR ) {
        close(s);
        return ERROR;
    }
    
    /* Receive the answer from the NTP server */
    rc = recvfrom(s, (char*)&ntp_packet, sizeof(ntp_packet), 0, NULL, NULL);
    if ( rc != sizeof(ntp_packet) ) {
        close(s);
        return rc;
    }
    
    ts->tv_sec = ntohl(ntp_packet.transmit_timestamp_secs) - NTP_EPOCH + secs_shift;
    ts->tv_nsec = ntohl(ntp_packet.transmit_timestamp_fraq) * 1000 / 4295;
    
    close(s);
    
    return OK;
}

/* ------------------------------------------------------ */

STATUS sntpAdjust ( void ) {
    int i;
    struct timespec ts;
    int success;

    success = 0;

    for ( i = 0; i < ntp_servers_num; i++ ) {
        ntp_server_t *server = &ntp_servers[i];
        if ( sntpGet(server, &ts) == OK ) {
            /* We've managed to fetch at least one time stamp */
            success = 1;
            break;
        }
    }

    if ( success ) {
        clock_settime(CLOCK_REALTIME, &ts);
        return OK;
    }
    
    return ERROR;
}

/* ------------------------------------------------------ */

STATUS sntpTask ( void ) {
    while ( 1 ) {
        sntpAdjust();
        taskDelay(sntpTaskDelay);
    }
}

/* ------------------------------------------------------ */

STATUS sntpStartTask ( unsigned int period ) {
    if ( sntpTaskId == 0 ) {
        sntpTaskDelay = period * sysClkRateGet();
        sntpTaskId = taskSpawn("tSNTP", NTP_PRIORITY, 0, NTP_STACK,
                             (FUNCPTR)sntpTask,
                             0,0,0,0,0,0,0,0,0,0);
        if ( sntpTaskId == ERROR ) {
            logMsg("Cannot spawn SNTP client task.\n");
        } else {        
            return OK;
        }
    }
    
    return ERROR;
}

/* ------------------------------------------------------ */


STATUS rtime ( char *hostname ) {
    unsigned int host;
    struct sockaddr_in addr;
    int sock;
    unsigned long time;
    struct timespec ts;
    
    /* Resolving host */
    if ( (int)(host = inet_addr(hostname)) == ERROR ) {
        if ( (int)(host = hostGetByName(hostname)) == ERROR ) {
            logMsg("Cannot resolve host %s\n", hostname);
            return ERROR;
        }
    }
    
    bzero((char*)&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = host;
    addr.sin_port = TIME_PORT;
    
    /* Create socket */
    if ( (sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0 ) {
        logMsg("Cannot create socket. Errno=%d (%s)\n", errno, strerror(errno));
        return ERROR;
    }
    
    /* Connect */
    if ( connect(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0 ) {
        logMsg("Cannot connect to %s:%d. Errno=%d (%s)\n", hostname, addr.sin_port, errno, strerror(errno));
        close(sock);
        return ERROR;
    }
    
    /* Reading server's time */
    if ( read(sock, (char*)&time, 4) != 4 ) {
        logMsg("Cannot read from %s:%d. Errno=%d (%s)\n", hostname, addr.sin_port, errno, strerror(errno));
        close(sock);
        return ERROR;
    }
        
    /* Setting up time */
    ts.tv_sec = ntohl(time) - TIME_ORIGIN;
    ts.tv_nsec = 0;
    clock_settime(CLOCK_REALTIME, &ts);
    
    close(sock);

    return OK;
}

/* ------------------------------------------------------ */

STATUS sntp ( char *hostname ) {
    struct timespec ts;
    STATUS status = OK;
    
    status = sntpcTimeGet(hostname, SNTP_TIMEOUT, &ts);
    if ( status == OK ) {        
        clock_settime(CLOCK_REALTIME, &ts);
    } else
        logMsg("SNTP failed. Errno=%d (%s)\n", errno, strerror(errno));
    
    return status;
}

/* ------------------------------------------------------ */
/* End of file */
