/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
 
/*
    This is a simple example of HTTP server usage.
    It shows how to start the server, register some CGI functions
    and handle HTTP requests within these functions.
*/

/* Here is forward declaration of two CGI functions */
static void cgi_test1_html ( char *params, int length );
static void cgi_test2_html ( char *params, int length );
 
/**
 * Entry point. Here we start the server and register some CGI functions.
 */
void httpd_example ( ) {
    
    /* Starting the server, listening on port 80 */
    if ( HTTPD_OK != httpd_start(80) ) {
        logMsg("Cannot start the server!\n");
        return;
    }
    
    /* Registering CGI functions. Note, that you cannot
     * register them before starting the server.
     */
    httpd_register_resource("/test1.html", &cgi_test1_html);
    httpd_register_resource("/test2.html", &cgi_test2_html);
    
    /* From now we are done. Server is running, CGI functions
     * will be called when a client requests
     * http://target/test1.html or http://target/test2.html
     */
}

/* ------------------------------------------------------ */
/**
 * Here is a first CGI function.
 * We assume that stdio redirection is enabled, so we can
 * use printf() for output to a client. The argument we receive
 * here is a parameters string as it sent by a client.
 */
static void cgi_test1_html ( char *params, int length ) {
    char name[64];    

    /* The first thing to do before performing any output
     * is to send an HTTP header, stating HTTP result
     * and content type we are about to send.
     * Here we are going to send an HTML data.
     */
    httpd_header(HTTP_OK, CONTENT_TEXT_HTML);
    
    printf("<HTML><HEAD><TITLE>%s</TITLE></HEAD>\n", __FUNCTION__);
    printf("<BODY>\n");
    printf("<P>Request handled by %s<BR>\n", __FUNCTION__);
    printf("<P>Received data[%d]: %s<BR>\n", length, params);
    
    /* Here we try to fetch parameter 'name'.
     * So that when a client requests something like
     * http://target/test1.html?name=foo
     * will obtain a sting 'foo' as a value of
     * name parameter.
     */
    if ( httpd_get_param(params, "name", name) == HTTPD_OK ) {
        printf("<H2>name=\"%s\"</H2>\n", name);
    } else
        printf("<H2>name parameter was not sent</H2>\n");
    
    printf("</BODY></HTML>\n");
}

/* ------------------------------------------------------ */
/**
 * Here is another CGI function.
 * The difference here is that we'll try to maintain a
 * keep-alive connection. It is not possible with a previous function
 * because the length of content is unknown. Now we put
 * all the data we want to send into a temporary buffer,
 * deternime its length and send a keep-alive header.
 *
 * When a client (i.g. web browser) receives a keep-alive
 * response it may want to send a second, third, etc. request
 * via the same connection without closing a socket. This
 * increase somehow HTTP performance.
 */
void cgi_test2_html ( char *params, int length ) {
    char *buffer;
    int i;
    
    /* Allocating memory for temporary buffer.
     * We use dynamic allocation in order to not to use stack
     * memory which is limited.
     * Note, that if you use global or static variables here you have
     * protect them by mutex because several session tasks
     * may want to execute the same CGI function at the same time.
     */
    buffer = (char *)malloc(2048);
    bzero(buffer, 2048);
    
    /* Here we'll output an XML file with some information.
     * Note that you cannot use printf() or other functions
     * that output to stdio since this may break an HTTP stream.
     * (Well, if you have stdio redirection option disabled
     * you may use printf, since it will print to your target
     * console in this case).
     */
    strcat(buffer, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    strcat(buffer, "<data>\n");
    for ( i = 0; i < 10; i++ ) {
        char tmp[64] = '\0';
        
        /* Some dumb random values */
        sprintf(tmp, "<item id=\"%d\" value=\"%f\" />\n", i, rand());
        strcat(buffer, tmp);
    }
    strcat(buffer, "</data>\n");
    
    /* Send an HTTP header and previously prepared content */
    httpd_keep_alive(HTTPD_OK, CONTENT_TEXT_XML, strlen(buffer), buffer);
    
    free(buffer); /* Don't forget to free allocated memory */
}

/* ------------------------------------------------------ */
/* End of file */
 