/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

#ifndef __HTTPD_H__
#define __HTTPD_H__

/**
 * Maximal number of sessions (and asociated threads)
 * allowed for the server
 */
#define HTTPD_MAX_SESSIONS  6

/**
 * HTTP Request timeout in ms
 */
#define HTTPD_REQUEST_TIMEOUT	1000

/**
 * HTTP Keep-alive connection incoming data wait
 * Actual timeout will be HTTPD_REQUEST_TIMEOUT * HTTPD_KEEP_ALIVE_TIMEOUT 
 */
#define HTTPD_KEEP_ALIVE_TIMEOUT    5

/**
 * HTTP stdio redirection for CGI functions
 */
#define HTTPD_STDIO_REDIRECT    1

/**
 * Maxumal input buffer size
 */
#define HTTPD_MAX_INPUT_BUFFER_SIZE     4096

/**
 * maximal output buffer size
 */
#define HTTPD_MAX_OUTPUT_BUFFER_SIZE     4096

/**
 * Http server tasks priority
 */
#define HTTPD_MAIN_PRIORITY     100
#define HTTPD_SESSION_PRIORITY  101

/**
 * Http task stack size
 */
#define HTTPD_MAIN_STACK_SIZE       (4*1024)
#define HTTPD_SESSION_STACK_SIZE    (32*1024)

/**
 * Allow files loading from the local file system
 */
#define HTTPD_ALLOW_FILES		1
#define HTTPD_DOC_ROOT			"./htdocs"
#define HTTPD_INDEX_FILE		"index.html"

/**
 * Return codes for httpd functions.
 * Positives are for status, negatives for errors.
 */
typedef signed int ret_t;

/**
 * httpd functions possible return values.
 */
#define HTTPD_OK            0	/* Return with no error		    */
#define HTTPD_ERROR         -1  /* Unknown error                */
#define HTTPD_SOCKET_ERROR  -2  /* socket() error               */
#define HTTPD_BIND_ERROR    -3  /* bind() error                 */
#define HTTPD_LISTEN_ERROR  -4  /* listen() error               */
#define HTTPD_HOOK_ERROR    -5  /* taskDeleteHookAdd() error    */
#define HTTPD_IOCTL_ERROR   -6  /* ioctl() error                */
#define HTTPD_READ_ERROR    -7  /* read() error                 */
#define HTTPD_WRITE_ERROR   -8  /* write() error                */
#define HTTPD_DATA_ERROR    -9  /* The treated data seems to be invalid
                                    Usually provoked by invalid requests
                                    from the browser.           */
#define HTTPD_ALREADY_STARTED	-10	/* The HTTPD server is already started */

/**
 * HTTP response status
 */
#define HTTP_OK                 200
#define HTTP_NOT_FOUND          404
#define HTTP_SERVER_ERROR       500
#define HTTP_NOT_IMPLEMENTED    501

/**
 * HTTP content types
 */
typedef
enum {
    CONTENT_TEXT_HTML,
    CONTENT_TEXT_XML,
    CONTENT_TEXT_PLAIN,
    CONTENT_IMAGE_GIF,
    CONTENT_IMAGE_JPEG,
    CONTENT_IMAGE_PNG
} http_content_t;

/**
 * Pointer to the URL-handling function
 * @param paramstr A string of URL parameters fetched from the request
 * @param length A parameters string length or data size (useful for POST requests)
 */
typedef void(*httpd_func_t)(char *paramstr, int length);

/**
 * Starting up the http server
 * @param port Port number that will be listened by the http server
 * @return HTTPD_OK if everything is Ok, or error code
 */
ret_t httpd_start ( unsigned int port );

/**
 * Stop the http server
 * @return HTTPD_OK
 */
ret_t httpd_stop ( );

/**
 * Register http resource
 * @param url Virtual url address
 * @param funct Function that will be called if the url requested
 * @return HTTPD_OK if everything is well, error code elsewhere
 */
ret_t httpd_register_resource ( const char *url, httpd_func_t func );

/**
 * Remove resource from the list of registered resources
 * @param url Remove the specified url from the registered resources list
 * @return HTTPD_OK or error code
 */
ret_t httpd_unregister_resource ( const char *url );

/**
 * Output HTTP header to current http stream
 * @param status HTTP status
 * @param content Content type
 * @return HTTPD_OK or error code
 */
ret_t httpd_header ( int status, http_content_t content );

/**
 * Output HTTP header with 'keep-alive' option enabled, and send content of
 * a known length.
 * @param status HTTP status
 * @param content Content type
 * @param length Content length
 * @param data Content
 * @return HTTPD_OK or error code
 */
ret_t httpd_keep_alive ( int status, http_content_t content, int length, void *data );

/**
 * Output to current http stream.
 * One can simply use printf as far as stdio redirection is enabled
 * for http session tasks.
 * @param format Format string
 * @return HTTPD_OK or error code
 */
ret_t httpd_printf ( const char *format, ... );

/**
 * This function parses the URL parameters string to fetch
 * the required paramater value.
 * @param paramstr URL parameters string (e.g. "id=123&name=test")
 * @param param_name Name of the required parameter
 * @param value String buffer where to put the parameter value
 * @return HTTPD_OK if parameter was succesfully parsed, HTTPD_ERROR elsewhere
 */
ret_t httpd_get_param ( const char *paramstr, const char *param_name, char *value );

#endif /* __HTTPD_H__ */
