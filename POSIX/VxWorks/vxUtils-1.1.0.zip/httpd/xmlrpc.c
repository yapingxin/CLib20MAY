/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

#include <vxWorks.h>
#include <logLib.h>
#include <semLib.h>
#include <string.h>

#include "httpd.h"
#include "ezxml.h"

#include "xmlrpc.h"

/**
 * A list of all registered RPC routines
 */
typedef
struct xmlrpc_routine_s {
    char *                      name;   /* RPC routine name */
    xmlrpc_func_t               func;   /* Pointer to C function implementing this routine */
    struct xmlrpc_routine_s *    next;  /* Pointer to next routine in list */
} xmlrpc_routines_list_t;

xmlrpc_routines_list_t *xmlrpc_routines_list = NULL;

/**
 * Internal protective binary semaphore (mutex-like)
 */
SEM_ID xmlrpc_sem = NULL;

/**
 * Static forward declarations
 */
static char *xmlrpc_strdup ( const char *str );
static xmlrpc_value_t * xmlrpc_parse_members ( ezxml_t structure );
static xmlrpc_value_t * xmlrpc_parse_values ( ezxml_t values );


static __inline__ long long rt_get_ticks ( ) {
    long long ret;
    __asm__ __volatile__ ("rdtsc": "=A" (ret));
    return ret;
}

/* ------------------------------------------------------ */
/**
 * Allocate memory for a new string and copy a string in argument
 */
static char *xmlrpc_strdup ( const char *str ) {
    int len;
    char *s;
    if ( str == NULL )
        return NULL;
    len = strlen(str);
    if ( len <= 0 )
        return NULL;
    s = (char *)malloc(len + 1);
    strcpy(s, str);
    s[len] = '\0';
    return s;
}
    
/* ------------------------------------------------------ */
/**
 * Search for a particular routine registered at XML RPC server
 * @param name Routine name
 * @return Pointer to routine structure or NULL if not found
 */
struct xmlrpc_routine_s *xmlrpc_find_routine ( const char *name ) {
    struct xmlrpc_routine_s *item;
    
    if ( NULL == xmlrpc_routines_list || xmlrpc_sem == NULL )
        return NULL;
        
    semTake(xmlrpc_sem, WAIT_FOREVER);
    
    item = xmlrpc_routines_list;
    while ( item ) {
        if ( strcmp(item->name, name) == 0 ) {
            break;
        }
        item = item->next;
    }
    
    semGive(xmlrpc_sem);
    
    return item;
}

/* ------------------------------------------------------ */

STATUS xmlrpc_init ( int http_port ) {

    /* Starting http server */
    ret_t res = httpd_start(http_port);
    if ( res != HTTPD_OK && res != HTTPD_ALREADY_STARTED ) {
        return ERROR;
    }
    
    /* Registering CGI handler */
    httpd_register_resource("/xmlrpc", &xmlrpc_cgi_handler);
    
    /* Initializing semaphore */
    xmlrpc_sem = semBCreate(SEM_Q_FIFO, SEM_EMPTY);
    semGive(xmlrpc_sem);
    
    return OK;
}

/* ------------------------------------------------------ */
/**
 * Parse a structure members
 * @param structure XML <struct> node
 * @return XML RPC named value
 */
static xmlrpc_value_t * xmlrpc_parse_members ( ezxml_t structure ) {
    ezxml_t member;
    ezxml_t name;
    xmlrpc_value_t *values = NULL;
    xmlrpc_value_t *value = NULL;
    
    for ( member = ezxml_child(structure, "member"); member; member = member->next ) {
    
        name = ezxml_child(member, "name");        
        value = xmlrpc_parse_values (member);
        if ( value && name ) {
            if ( value->next != NULL ) {
                /* Only a single value per structure member is allowed */
                xmlrpc_free_value(value->next);
                value->next = NULL;
            }
            value->name = xmlrpc_strdup(name->txt);
            if ( values )
                xmlrpc_append_value(values, value);
            else
                values = value;
        }
    
    }
    
    return values;
}

/* ------------------------------------------------------ */
/**
 * Parse a set of values
 * @param param XML node containing <value></value> subnodes
 * @return XML RPC value
 */
static xmlrpc_value_t * xmlrpc_parse_values ( ezxml_t values ) {
    ezxml_t value;
    ezxml_t value_boolean;
    ezxml_t value_double;
    ezxml_t value_integer;
    ezxml_t value_string;
    ezxml_t value_array;
    ezxml_t value_struct;
    xmlrpc_value_t *tmp;
    xmlrpc_value_t *xmlrpc_value = NULL;

    for ( value = ezxml_child(values, "value"); value; value=value->next ) {
    
        /* BOOLEAN */
        if ( (value_boolean = ezxml_child(value, "boolean")) ) {
            int v = atoi(value_boolean->txt);
            tmp = xmlrpc_create_boolean(NULL, v);
            
        /* DOUBLE */
        } else if ( (value_double = ezxml_child(value, "double")) ) {
            double v =  atof(value_double->txt);
            tmp = xmlrpc_create_double(NULL, v);
                
        /* INTEGER (int) */
        } else if ( (value_integer = ezxml_child(value, "int")) ) {
            int v = atoi(value_integer->txt);
            tmp = xmlrpc_create_integer(NULL, v);
                
        /* INTEGER (i4) */
        } else if ( (value_integer = ezxml_child(value, "i4")) ) {
            int v = atoi(value_integer->txt);
            tmp = xmlrpc_create_integer(NULL, v);
            
        /* ARRAY */
        } else if ( (value_array = ezxml_child(value, "array")) ) {
            ezxml_t data_node = ezxml_child(value_array, "data");
            xmlrpc_value_t *array_values = xmlrpc_parse_values(data_node);
            tmp = xmlrpc_create_array(NULL, array_values);
            
        /* STRUCT */
        } else if ( (value_struct = ezxml_child(value, "struct")) ) {
            xmlrpc_value_t *struct_values = xmlrpc_parse_members(value_struct);
            tmp = xmlrpc_create_struct(NULL, struct_values);
                
        /* STRING (string)*/
        } else if ( (value_string = ezxml_child(value, "string")) ) {
            tmp = xmlrpc_create_string(NULL, value_string->txt);
                
        /* STRING by default */
        } else {
            tmp = xmlrpc_create_string(NULL, value->txt);
        }            

        
        /* Adding new parsed value to a list */
        if ( xmlrpc_value )
            xmlrpc_append_value(xmlrpc_value, tmp);
        else
            xmlrpc_value = tmp;
        
    } /* for (value) */
    
    return xmlrpc_value;
}

/* ------------------------------------------------------ */

void xmlrpc_cgi_handler ( char *data, int length ) {
    ezxml_t xml;
    ezxml_t methodCall;
    ezxml_t methodName;
    ezxml_t params;
    ezxml_t param;
    ezxml_t return_xml;
    char *buffer;
    
    struct xmlrpc_routine_s *routine = NULL;    
    xmlrpc_value_t *arguments = NULL;
    xmlrpc_value_t *arg;
    xmlrpc_value_t *return_value = NULL;    
        
    xml = ezxml_parse_str(data, length);   
    
    if ( strcmp(xml->name, "methodCall") != 0 ) {
        logMsg("XMLRPC: Invalid request: %s (should be 'methodCall')\n", xml->name);
        return;
    } else
        methodCall = xml;
        
    methodName = ezxml_child(methodCall, "methodName");
    if (!methodName) {
        logMsg("methodName error: %s\n", ezxml_error(methodName));
        return;
    }
    
    routine = xmlrpc_find_routine(methodName->txt);
    if ( !routine ) {
        logMsg("Routine '%s' is not registered\n", methodName->txt);
        return;
    }
        
    if ( !(routine->func) ) {
        logMsg("Routine '%s' is registered but set to NULL\n", methodName->txt);
        return;
    }
    
    /* Parsing parameters */
    params = ezxml_child(methodCall, "params");
    for ( param = ezxml_child(params, "param"); param; param=param->next ) {
        arg = xmlrpc_parse_values(param);
        if ( arg ) {
            if ( arguments )
                xmlrpc_append_value(arguments, arg);
            else
                arguments = arg;
        }
    }

    /* We have parsed all arguments, so now can execute the routine */    
    return_value = routine->func(arguments);
    
    return_xml = xmlrpc_get_return_xml(return_value);
    buffer = ezxml_toxml(return_xml);
    
    /* Sending response to client */
    httpd_keep_alive(HTTP_OK, CONTENT_TEXT_XML, strlen(buffer), buffer);
    /*
    httpd_header(HTTP_OK, CONTENT_TEXT_XML);
    httpd_printf("%s", buffer);
    */
    
    free(buffer);
    ezxml_free(return_xml);
    
    xmlrpc_free_value(arguments);
    xmlrpc_free_value(return_value);
    ezxml_free(xml);    
}

/* ------------------------------------------------------ */

STATUS xmlrpc_register_routine ( const char *name, xmlrpc_func_t func ) {
    struct xmlrpc_routine_s *routine;
    
    if ( NULL == xmlrpc_sem || NULL == name || NULL == func )
        return ERROR;
    routine = xmlrpc_find_routine(name);
    
    if ( routine != NULL ) {
        /* Replacing existing routine */
        semTake(xmlrpc_sem, WAIT_FOREVER);
        routine->func = func;
        semGive(xmlrpc_sem);
        return OK;
    }
    
    semTake(xmlrpc_sem, WAIT_FOREVER);
    
    /* Adding a new routine */
    routine = (struct xmlrpc_routine_s *)malloc(sizeof(struct xmlrpc_routine_s));
    if ( !routine ) {
        semGive(xmlrpc_sem);
        return ERROR;
    }
    routine->name = xmlrpc_strdup(name);
    routine->func = func;
    routine->next = xmlrpc_routines_list;
    xmlrpc_routines_list = routine;
    
    semGive(xmlrpc_sem);
    
    return OK;
}

/* ------------------------------------------------------ */

STATUS xmlrpc_unregister_routine ( const char *name ) {
    struct xmlrpc_routine_s *item;
    
    if ( NULL == xmlrpc_routines_list || NULL == xmlrpc_sem )
        return ERROR;
        
    semTake(xmlrpc_sem, WAIT_FOREVER);
    
    item = xmlrpc_routines_list;
    while ( item->next ) {
        if ( strcmp(item->next->name, name) == 0 ) {
            /* routine's been found */
            struct xmlrpc_routine_s *tmp = item->next;
            item->next = tmp->next;
            free(tmp->name);
            free(tmp);
            semGive(xmlrpc_sem);
            return OK;
        }
    }
    
    /* Check whether it's a very first item */
    if ( strcmp(xmlrpc_routines_list->name, name) == 0 ) {
        item = xmlrpc_routines_list;
        xmlrpc_routines_list = item->next;
        free(item->name);
        free(item);
    }
    
    semGive(xmlrpc_sem);
        
    return OK;
}

/* ------------------------------------------------------ */

xmlrpc_value_t * xmlrpc_create_integer ( const char *name, int value ) {
    xmlrpc_value_t *v = (xmlrpc_value_t *)malloc(sizeof(xmlrpc_value_t));
    v->type = XMLRPC_INTEGER;
    v->value.integer_value = value;
    v->name = xmlrpc_strdup(name);
    v->next = NULL;
    return v;
}

/* ------------------------------------------------------ */

xmlrpc_value_t * xmlrpc_create_boolean ( const char *name, int value ) {
    xmlrpc_value_t *v = (xmlrpc_value_t *)malloc(sizeof(xmlrpc_value_t));
    v->type = XMLRPC_BOOLEAN;
    v->value.boolean_value = value;
    v->name = xmlrpc_strdup(name);
    v->next = NULL;
    return v;
}

/* ------------------------------------------------------ */

xmlrpc_value_t * xmlrpc_create_string ( const char *name, const char *value ) {
    xmlrpc_value_t *v = (xmlrpc_value_t *)malloc(sizeof(xmlrpc_value_t));
    v->type = XMLRPC_STRING;
    v->value.string_value = xmlrpc_strdup(value);
    v->name = xmlrpc_strdup(name);
    v->next = NULL;
    return v;
}

/* ------------------------------------------------------ */

xmlrpc_value_t * xmlrpc_create_double ( const char *name, double value ) {
    xmlrpc_value_t *v = (xmlrpc_value_t *)malloc(sizeof(xmlrpc_value_t));
    v->type = XMLRPC_DOUBLE;
    v->value.double_value = value;
    v->name = xmlrpc_strdup(name);
    v->next = NULL;
    return v;
}

/* ------------------------------------------------------ */

xmlrpc_value_t * xmlrpc_create_array ( const char *name, xmlrpc_value_t *value ) {
    xmlrpc_value_t *v = (xmlrpc_value_t *)malloc(sizeof(xmlrpc_value_t));
    v->type = XMLRPC_ARRAY;
    v->value.array_value = value;
    v->name = xmlrpc_strdup(name);
    v->next = NULL;
    return v;
}

/* ------------------------------------------------------ */

xmlrpc_value_t * xmlrpc_create_struct ( const char *name, xmlrpc_value_t *value ) {
    xmlrpc_value_t *v = (xmlrpc_value_t *)malloc(sizeof(xmlrpc_value_t));
    v->type = XMLRPC_STRUCT;
    v->value.struct_value = value;
    v->name = xmlrpc_strdup(name);
    v->next = NULL;
    return v;
}

/* ------------------------------------------------------ */

xmlrpc_value_t * xmlrpc_create_fault ( const char *name, xmlrpc_value_t *fault_struct ) {
    xmlrpc_value_t *v = (xmlrpc_value_t *)malloc(sizeof(xmlrpc_value_t));
    v->type = XMLRPC_FAULT;
    v->value.fault_value = fault_struct;
    v->name = xmlrpc_strdup(name);
    v->next = NULL;
    return v;
}

/* ------------------------------------------------------ */

xmlrpc_value_t * xmlrpc_create_fault_code_text ( int code, const char *text ) {
    xmlrpc_value_t *f;
    xmlrpc_value_t *s;
    xmlrpc_value_t *v = xmlrpc_create_integer("faultCode", code);    
    xmlrpc_append_value(v, xmlrpc_create_string("faultString", text));    
    
    s = xmlrpc_create_struct(NULL, v);    
    f = xmlrpc_create_fault(NULL, s);

    return f;
}

/* ------------------------------------------------------ */

void xmlrpc_append_value ( xmlrpc_value_t *value, xmlrpc_value_t *new_value ) {
    xmlrpc_value_t *item;
    
    if ( value == NULL || new_value == NULL )
        return;
        
    item = value;
    while ( item->next != NULL )
        item = item->next;
        
    item->next = new_value;
}

/* ------------------------------------------------------ */

void xmlrpc_free_value ( xmlrpc_value_t *value ) {
    while ( value != NULL ) {
        xmlrpc_value_t *this_value = value;
        
        if ( value->type == XMLRPC_STRING ) {
            free(value->value.string_value);
        } else if ( value->type == XMLRPC_ARRAY ) {
            xmlrpc_free_value(value->value.array_value);
        } else if ( value->type == XMLRPC_STRUCT ) {
            xmlrpc_free_value(value->value.struct_value);
        }
    
        if ( value->name != NULL )
            free(value->name);
            
        value = value->next;
        free(this_value);
    }
}

/* ------------------------------------------------------ */

ezxml_t xmlrpc_xml_value ( xmlrpc_value_t *value ) {
    char buffer[32];
    ezxml_t val;
    ezxml_t data;
    ezxml_t xml = ezxml_new("value");

    if ( value ) {
        
        val = NULL;
        
        switch ( value->type ) {
        
            case XMLRPC_INTEGER:
                bzero(buffer, 32);
                val = ezxml_new("i4");                
                sprintf(buffer, "%d", value->value.integer_value);
                val = ezxml_set_flag(ezxml_set_txt(val, xmlrpc_strdup(buffer)), EZXML_TXTM);
                break;
                
            case XMLRPC_DOUBLE:
                bzero(buffer, 32);
                val = ezxml_new("double");
                sprintf(buffer, "%f", value->value.double_value);
                val = ezxml_set_flag(ezxml_set_txt(val, xmlrpc_strdup(buffer)), EZXML_TXTM);
                break;
                
            case XMLRPC_BOOLEAN:
                bzero(buffer, 32);
                val = ezxml_new("int");
                strcpy(buffer, (value->value.boolean_value) ? "1" : "0");
                val = ezxml_set_flag(ezxml_set_txt(val, xmlrpc_strdup(buffer)), EZXML_TXTM);
                break;
                
            case XMLRPC_ARRAY: {
                xmlrpc_value_t *item;
                val = ezxml_new("array");
                data = ezxml_new("data");
                item = value->value.array_value;
                while ( item ) {
                    ezxml_t array_value = xmlrpc_xml_value(item);
                    ezxml_insert(array_value, data, 0);
                    item = item->next;
                }
                ezxml_insert(data, val, 0);
                break;
            }
            
            case XMLRPC_STRUCT: {
                xmlrpc_value_t *item;
                val = ezxml_new("struct");
                item = value->value.struct_value;
                while ( item ) {
                    ezxml_t member = ezxml_new("member");
                    ezxml_t name = ezxml_new("name");
                    ezxml_t member_value = xmlrpc_xml_value(item);
                    name = ezxml_set_txt(name, item->name);
                    ezxml_insert(name, member, 0);
                    ezxml_insert(member_value, member, 0);
                    ezxml_insert(member, val, 0);
                    item = item->next;
                }
                break;
            }
                
            case XMLRPC_STRING:
            default:
                val = ezxml_new("string");
                val = ezxml_set_flag(ezxml_set_txt(val, xmlrpc_strdup(value->value.string_value)), EZXML_TXTM);
                break;
        }
        
        ezxml_insert(val, xml, 0);
        
    } /* if ( value ) */
    
    return xml;
}

/* ------------------------------------------------------ */

ezxml_t xmlrpc_get_return_xml ( xmlrpc_value_t *value ) {
    ezxml_t xml;
    
    xml = ezxml_new("methodResponse");
    if ( value->type == XMLRPC_FAULT ) {
        /* Processing fault value */
        /* Fault value is put in <fault></fault> tag */
        ezxml_t fault, val;
        
        fault = ezxml_new("fault");
        val = xmlrpc_xml_value(value->value.fault_value);
        ezxml_insert(val, fault, 0);
        ezxml_insert(fault, xml, 0);
    } else {
        /* Processing all other values */
        /* Other values are put in <param></para> tag */
        ezxml_t params;
        xmlrpc_value_t *item;

        params = ezxml_new("params");    
        item = value;
        while ( item ) {
            ezxml_t param = ezxml_new("param");
            ezxml_t val = xmlrpc_xml_value(item);
            ezxml_insert(val, param, 0);
            ezxml_insert(param, params, 0);
            item = item->next;
        }    
        ezxml_insert(params, xml, 0);
    }
    
    return xml;
}

/* ------------------------------------------------------ */
/* End of file */
