/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

#ifndef __XMLRPC_H__
#define __XMLRPC_H__

#include "ezxml.h"

/**
 * These identifiers define types supoprted by XML RPC spec.
 */
typedef enum {
    XMLRPC_INTEGER,     /* 32 bits signed integer value */
    XMLRPC_BOOLEAN,     /* Boolean value, 0 or 1        */
    XMLRPC_STRING,      /* A string                     */
    XMLRPC_DOUBLE,      /* 64 bits double value         */
    XMLRPC_DATE_TIME,   /* ISO8601 timestamp            */
    XMLRPC_BINARY,      /* Base64-encoded binary value  */
    XMLRPC_STRUCT,      /* Associative array            */
    XMLRPC_ARRAY,       /* Array of values              */
    
    XMLRPC_FAULT        /* For failure reporting back from RPC routines */
} xmlrpc_type_t;

/**
 * XML RPC value forward type declaration
 */
typedef struct xmlrpc_value_s xmlrpc_value_t;

/**
 * XML RPC value types mapped to C types
 */
typedef signed int          xmlrpc_integer_t;
typedef int                 xmlrpc_boolean_t;
typedef char *              xmlrpc_string_t;
typedef double              xmlrpc_double_t;
typedef char *              xmlrpc_date_time_t;
typedef char *              xmlrpc_binary_t;
typedef xmlrpc_value_t *    xmlrpc_struct_t;
typedef xmlrpc_value_t *    xmlrpc_array_t;
typedef xmlrpc_value_t *    xmlrpc_fault_t;

/**
 * The following structure defines 'any type' value used
 * by XML RPC. It has a type, name and some value.
 * It has as well a link pointer to another value that allows
 * to organize parameters list, structures and arrays
 */
struct xmlrpc_value_s {
    char * name;            /* Value name or NULL               */
    xmlrpc_type_t   type;   /* Type of this particular value    */    
    xmlrpc_value_t  *next;  /* Next value in list               */
  
    union {
        xmlrpc_integer_t    integer_value;
        xmlrpc_boolean_t    boolean_value;
        xmlrpc_string_t     string_value;
        xmlrpc_double_t     double_value;
        xmlrpc_date_time_t  date_time_value;
        xmlrpc_binary_t     binary_value;
        xmlrpc_struct_t     struct_value;
        xmlrpc_array_t      array_value;
        xmlrpc_fault_t      fault_value;
    } value;
};

/**
 * This is definition of an RPC function
 * RPC function receives a list of values (arguments) and
 * returns an XML RPC value in response
 */
typedef xmlrpc_value_t * (*xmlrpc_func_t)(xmlrpc_value_t *arguments);

/**
 * Initialize XML RPC server
 * This function will start an http server if not yet started and
 * bind an "/xmlrpc" resource that will handle all RPC calls
 *
 * @param http_port HTTP port number to listen for
 * @return OK or ERROR
 */
STATUS xmlrpc_init ( int http_port );

/**
 * XML RPC handler (CGI function for HTTP server)
 * This function will parse an incoming data as XML stream
 * and execute corresponding RPC routines
 *
 * @param data Some data sent by a client
 * @param length Number of bytes data contain
 */
void xmlrpc_cgi_handler ( char *data, int length );

/**
 * Register or unregister an RPC routine
 * This function will add a new routine to the list of registered routines.
 * If routine with the same name already exists, it will be replaced.
 *
 * @param name Routine name, e.g. "Service.run"
 * @param func Pointer to C function that will be called
 * @return OK or ERROR if there are any problems registering RPC routine
 */
STATUS xmlrpc_register_routine ( const char *name, xmlrpc_func_t func );

/**
 * Remove a routine from the list of registered RPC routines.
 * If routine name cannot be found, this function does nothing
 *
 * @param name Name of routine to be removed
 * @return OK
 */
STATUS xmlrpc_unregister_routine ( const char *name );

/**
 * Create integer value
 * @param name Value name or NULL
 * @param value Integer value
 * @return Pointer to new XML RPC value
 */
xmlrpc_value_t * xmlrpc_create_integer ( const char *name, int value );

/**
 * Create boolean value
 * @param name Value name or NULL
 * @param value Boolean value, 0 or 1
 * @return Pointer to new XML RPC value
 */
xmlrpc_value_t * xmlrpc_create_boolean ( const char *name, int value );

/**
 * Create string value
 * @param name Value name or NULL
 * @param value String value
 * @return Pointer to new XML RPC value
 */
xmlrpc_value_t * xmlrpc_create_string ( const char *name, const char * value );

/**
 * Create double value
 * @param name Value name or NULL
 * @param value Double value
 * @return Pointer to new XML RPC value
 */
xmlrpc_value_t * xmlrpc_create_double ( const char *name, double value );

/**
 * Create an array
 * @param name Value name or NULL
 * @param value Pointer to a list of unnamed values
 * @return Pointer to new XML RPC value
 */
xmlrpc_value_t * xmlrpc_create_array ( const char *name, xmlrpc_value_t *value );

/**
 * Create structure
 * Structure is basically an array with named values
 * @param name Value name or NULL
 * @param value Pointer to a list of named values
 * @return Pointer to new XML RPC value
 */
xmlrpc_value_t * xmlrpc_create_struct ( const char *name, xmlrpc_value_t *value );

/**
 * Create fault value
 * @param name Value name or NULL
 * @param fault_struct Pointer to { 'faultCode', 'faultString' } structure
 * @return Pointer to new XML RPC value
 */
xmlrpc_value_t * xmlrpc_create_fault ( const char *name, xmlrpc_value_t *fault_struct );

/**
 * Create an XML RPC value containint a fault code and error message
 * @param code Error code
 * @param text Error message
 * @return Pointer to new XML RPC value
 */
xmlrpc_value_t * xmlrpc_create_fault_code_text ( int code, const char *text );

/**
 * Append a value to a list of values
 * This function is used when creating arrays or structures
 * @param value XML RPC value to which another value will be appended
 * @param new_value Value to be appended
 */
void xmlrpc_append_value ( xmlrpc_value_t *value, xmlrpc_value_t *new_value );

/**
 * Free memory used by specified value and all child values
 * @param value Pointer to XMl RPC value
 */
void xmlrpc_free_value ( xmlrpc_value_t *value );

/**
 * Convert XML RPC value into XML structure <value>...</value>
 * @param value Pointer to XML RPC value
 * @return XML <value> node
 */
ezxml_t xmlrpc_xml_value ( xmlrpc_value_t *value );

/**
 * Convert XML RPC value into return-style XML structure <methodResponse>...</methodResponse>
 * @param value Pointer to XML RPC value
 * @return XML <methodResponse> node
 */
ezxml_t xmlrpc_get_return_xml ( xmlrpc_value_t *value );

#endif /* __XMLRPC_H__ */
