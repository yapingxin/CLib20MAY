/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

/*
    This example demonstrated a usage of XML RPC interface.
    It shows how to register an RPC routine and handle
    RPC requests.
*/

#include <vxWorks.h>
#include <logLib.h>

#include "httpd.h"
#include "xmlrpc.h"

/**
 * RPC 'add' routine forward declaration
 */
static xmlrpc_value_t *rpc_add ( xmlrpc_value_t * arguments );

/**
 * Entry point.
 * Here we start the web server and register an RPC routine
 */
void xmlrpc_example ( ) {
    /* Starting the server at port 80,
     * and activating XML RPC service.
     * XML RPC service will be available via
     * http://<target host>:80/xmlrpc URL.
     */
    xmlrpc_init(80);
    
    /* Registering RPC routine */
    xmlrpc_register_routine("add", rpc_add);
}

/* ------------------------------------------------------ */

/**
 * RPC routine 'add'
 * This routine accepts a list of integer arguments and returns
 * a sum of them.
 */
static xmlrpc_value_t *rpc_add ( xmlrpc_value_t * arguments ) {
    xmlrpc_value_t *arg;
    int sum = 0;
    
    if ( arguments == NULL ) {
        return xmlrpc_create_fault_code_text(1, "At least a single arguments should be given to 'add' routine.");
    }
    
    /* Iterate over the list of arguments to produce a sum of them */
    arg = arguments;
    while ( arg ) {
        if ( arg->type != XMLRPC_INTEGER )
            return xmlrpc_create_fault_code_text(2, "'add' routine accepts only integer arguments.");
            
        sum += arg->value.integer_value;
        
        /* Move to the next argument */
        arg = arg->next;
    }
    
    /* Seturn the sum */
    return xmlrpc_create_integer(NULL, sum);
}
 
/* ------------------------------------------------------ */
/* End of file */
