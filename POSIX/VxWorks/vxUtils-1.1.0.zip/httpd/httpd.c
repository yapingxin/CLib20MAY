/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

#include <vxWorks.h>
#include <ioLib.h>
#include <taskHookLib.h>
#include <selectLib.h>
#include <fioLib.h>
#include <logLib.h>
#include <taskLib.h>
#include <semLib.h>
#include <sockLib.h>
#include <inetLib.h>
#include <netinet/tcp.h>

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <socket.h>
#include <timers.h>


#include "cgi_ios.h"
#include "httpd.h"

/* Uncomment this to see debug stuff */
/* #define HTTPD_DEBUG 1 */

/* Some flags */
#define HTTPD_FLAG_NONE             0
#define HTTPD_FLAG_KEEP_ALIVE       1

/* Default registered resources (see below) */
static void www_index();

/**
 * Tasks asociated with sessions
 */
WIND_TCB *httpd_tasks[HTTPD_MAX_SESSIONS];
WIND_TCB *httpd_task;
int httpd_task_id;

/**
 * HTTP server semaphore
 */
SEM_ID httpd_sem = NULL;

/* Content type text equivalents */
const char *http_content_text[] = {
    "text/html",
	"text/xml",
	"text/plain",
    "image/gif",
    "image/jpg",
    "image/png"
};

/**
 * linked list of registered resources
 */
typedef
struct resource_s {
    char *url;
    httpd_func_t func;
    struct resource_s *next;
} httpd_resource_list_t;

httpd_resource_list_t *httpd_resource_list = NULL;

/**
 * Returns the system time in ms
 * @return system time in ms
 */
long long httpd_get_time() {
    /* Getting the time in ms under VxWorks */
    struct timespec tp;
    if ( 0 == clock_gettime(CLOCK_REALTIME, &tp) ) {
        return ((long long)tp.tv_sec) * 1000L + ((long long)tp.tv_nsec) / 1000000L;
    }
    return 0L;
}

/**
 * Search for the resource in the list of registered resources
 * @param url URL to look for
 * @return The pointer to the resource's structure or NULL if not found.
 */
struct resource_s *httpd_find_resource ( const char *url ) {
    struct resource_s *item;

    if ( NULL == httpd_resource_list ) {
#ifdef HTTPD_DEBUG
        logMsg("httpd_find_resource(): Resource list is not initialised\n");
#endif
        return NULL;
    }

    semTake(httpd_sem, WAIT_FOREVER);

    item = httpd_resource_list;
    while ( item ) {
        if ( strcmp(item->url, url) == 0 ) {
#ifdef HTTPD_DEBUG
            logMsg("httpd_find_resource(): resource found: '%s'\n", url);
#endif
            break;
        }
        item = item->next;
    }
    semGive(httpd_sem);
    return item;
}

/**
 * Registering resource.
 * If the resource is already registered, it will be replaced.
 * @param url URL to register
 * @param func Function that will be called to process this URL
 * @return Error status
 */
ret_t httpd_register_resource ( const char *url, httpd_func_t func ) {
    struct resource_s *resource;

    if ( NULL == httpd_sem ) /* Server is not ready */
        return HTTPD_ERROR;

    if ( NULL == url || NULL == func ) {
#ifdef HTTPD_DEBUG
        logMsg("HTTPD: Invalid resource cannot be registered\n");
#endif
        return HTTPD_ERROR;
    }

    resource = httpd_find_resource(url);
    if ( NULL != resource ) {
        /* Replace previous resource function */
#ifdef HTTPD_DEBUG
        logMsg("HTTPD: Resuorce '%s' is already registered and was replased\n");
#endif
        resource->func = func;
        return HTTPD_OK;
    }

    semTake(httpd_sem, WAIT_FOREVER);

    /* Add a new resource */
    resource = (struct resource_s *)malloc(sizeof(struct resource_s));
    if ( !resource ) {
        semGive(httpd_sem);
#ifdef HTTPD_DEBUG
        logMsg("HTTPD: Cannot allocate memory for new resource\n");
#endif
        return HTTPD_ERROR;
    }
    resource->url = (char*)malloc(strlen(url) + 1);
    if ( !(resource->url) ) {
        free(resource);
        semGive(httpd_sem);
#ifdef HTTPD_DEBUG
        logMsg("HTTPD: Cannot allocate memory for resource URL\n");
#endif
        return HTTPD_ERROR;
    }
    bzero(resource->url, strlen(url) + 1);
    strcpy(resource->url, url);
    resource->func = func;
    resource->next = httpd_resource_list;
    httpd_resource_list = resource;
    semGive(httpd_sem);

#ifdef HTTPD_DEBUG
    logMsg("HTTPD: Resourse '%s' registered\n", url);
#endif

    return HTTPD_OK;
}

/**
 * Delete specified resource from the resource list
 * @param url Resource URL
 * @return Error status
 */
ret_t httpd_unregister_resource ( const char *url ) {
    struct resource_s *item;

    if ( NULL == httpd_resource_list || httpd_sem == NULL )
        return HTTPD_ERROR;

    semTake(httpd_sem, WAIT_FOREVER);

    item = httpd_resource_list;
    while ( item->next ) {
        if ( strcmp(item->next->url, url) == 0 ) {
            /* resource is found */
            struct resource_s *tmp = item->next;
            item->next = tmp->next;
            free(tmp->url);
            free(tmp);
            semGive(httpd_sem);
            return HTTPD_OK;
        }
    }

    /* Check if it is a first item */
    if ( strcmp(httpd_resource_list->url, url) == 0 ) {
        item = httpd_resource_list;
        httpd_resource_list = item->next;
        free(item->url);
        free(item);
    }

    semGive(httpd_sem);
    return HTTPD_OK;
}

/**
 * Read a data stream of predified data length
 * (normally POST requests)
 * @param sock Socket fo I/O
 * @param buffer Pointer to buffer for data storage
 * @param length Number of bytes to read
 * @return Error code or HTTPD_OK
 */
ret_t httpd_read_buffer ( int sock, char *buffer, int length ) {
    int num; /* number of bytes available */
    int i;
    char ch;
    int count;
	int waitCounter;

	waitCounter = 30;
    for ( i = 0; ; ) {
        if ( ioctl(sock, FIONREAD, (int)&num) < 0 ) {
#ifdef HTTPD_DEBUG
            logMsg("HTTPD: ioctl() < 0\n");
#endif
            return HTTPD_READ_ERROR;
        }
        if ( num < 1 ) {
            taskDelay(10);
			waitCounter--;
			if ( waitCounter == 0 ) {
#ifdef HTTPD_DEBUG
				logMsg("HTTPD: httpd_read_buffer() timeout\n");
#endif
				return HTTPD_READ_ERROR;
			}
            continue;
        }

        count = read(sock, &ch, 1);
        if ( count < 1 ) {
#ifdef HTTPD_DEBUG
            logMsg("HTTPD: %d bytes read but %d available\n", count, num);
#endif
            return HTTPD_READ_ERROR;
        }


        buffer[i++] = ch;
        if ( i >= length )
            break;
    }
    return HTTPD_OK;
}

/**
 * Read a single string line from the socket
 * This function blocks for the HTTPD_REQUEST_TIMEOUT value
 * @param sock Socket for I/O
 * @param buffer String buffer to read the line in
 * @return Error code or the length of a string read
 */
ret_t httpd_read_line ( int sock, char *buffer ) {
    int num; /* number of bytes available */
    int i;
    char ch;
    int count;
	int waitCounter;

	waitCounter = 30;
    for ( i = 0; ; ) {
        if ( ioctl(sock, FIONREAD, (int)&num) < 0 ) {
#ifdef HTTPD_DEBUG
            logMsg("HTTPD: ioctl() < 0\n");
#endif
            return HTTPD_READ_ERROR;
        }
        if ( num < 1 ) {
            taskDelay(10);
			waitCounter--;
			if ( waitCounter == 0 ) {
#ifdef HTTPD_DEBUG
				logMsg("HTTPD: httpd_read_line() timeout\n");
#endif
				return HTTPD_READ_ERROR;
			}
            continue;
        }

        count = read(sock, &ch, 1);
        if ( count < 1 ) {
#ifdef HTTPD_DEBUG
            logMsg("HTTPD: %d bytes read but %d available\n", count, num);
#endif
            return HTTPD_READ_ERROR;
        }

        /* EOL */
        if ( ch == (char)0x0D ) {
            read(sock, &ch, 1);

            if ( ch != (char)0x0A ) {
#ifdef HTTPD_DEBUG
                logMsg("HTTPD: wanted 0x0A but got %d\n", (int)ch);
#endif
                return HTTPD_DATA_ERROR;
			}
            break;
        } else
            buffer[i++] = ch;
        if ( i >= (HTTPD_MAX_INPUT_BUFFER_SIZE-1) )
            break;
    }
    buffer[i] = '\0';
    return i;
}

/**
 * Write data to socket
 * @param sock Socket to be user for writing
 * @param data Array of bytes to send
 * @param len Length of data array
 * @return Error status value
 */
ret_t httpd_send ( int sock, char *data, int len ) {
    if ( len > 0 ) {
        int result = write(sock, data, len);
        if ( result != ERROR )
            return HTTPD_OK;
    }
    return HTTPD_WRITE_ERROR;
}

/**
 * Send a zero-terminated string to socket
 * @param sock Socket to use for I/O
 * @param str String to send
 * @return Error status value
 */
ret_t httpd_send_string ( int sock, char *str ) {
    return httpd_send(sock, str, strlen(str));
}

/**
 * This function returns a text string that corresponds to the
 * HTTP status code
 * @param status HTTP status code
 * @return Status string
 */
static char *_status[] = {
    "", "OK", "Not Found", "Server Error", "Not Implemented"
};
char *httpd_status ( int status ) {
   /* Getting the status text equivalent */
    switch ( status ) {
        case HTTP_OK:
            return _status[1];
            break;

        case HTTP_NOT_FOUND:
            return _status[2];
            break;

        case HTTP_SERVER_ERROR:
            return _status[3];
            break;

        case HTTP_NOT_IMPLEMENTED:
            return _status[4];
            break;

        default:
            break;
    }
    return _status[0];
}

/**
 * Send an HTTP/1.0 header
 * @param sock Socket to output
 * @param status HTTP status code
 * @param content Content type
 * @return Error code
 */
ret_t httpd_send_header ( int sock, int status, http_content_t content ) {
    char buffer[255];

    bzero(buffer, 255);

    sprintf(buffer, "HTTP/1.0 %d %s\nMIME-Version: 1.0\nContent-Type: %s\n\n",
		status,
		httpd_status(status),
		http_content_text[content]
	);

    return httpd_send_string(sock, buffer);
}

/**
 * Send HTTP/1.0 header with 'keep-alive' flag enabled
 * @param sock Socket
 * @param status HTTP status
 * @param content Content type
 * @param length Content length
 */
ret_t httpd_send_keep_alive_header ( int sock, int status, http_content_t content, int length ) {
    char buffer[255];
    bzero(buffer, 255);
    
    sprintf(buffer, "HTTP/1.0 %d %s\nMIME-Version: 1.0\nConnection: keep-alive\nContent-length: %d\nContent-Type: %s\n\n",
		status,
		httpd_status(status),
        length,
		http_content_text[content]
	);    
    
    return httpd_send_string(sock, buffer);
}

/**
 * Returns the TCB of currently runnning task
 * @return Task control block
 */
WIND_TCB *httpd_current_task() {
    return taskTcb(taskIdSelf());
}

/**
 * Prints data to current http output stream
 * @param format printf-style firmat
 * @param ... Other arguments
 * @return Error code
 */
ret_t httpd_printf ( const char *format, ... ) {
    va_list ap;
    int i;
    char buffer[HTTPD_MAX_OUTPUT_BUFFER_SIZE];
    WIND_TCB *task = httpd_current_task();


    /* Check if this function was called by httpd session task  */
    for ( i = 0; i < HTTPD_MAX_SESSIONS; i++ ) {
        if ( task == httpd_tasks[i] )
	    break;
    }

    if ( i < HTTPD_MAX_SESSIONS ) {
        bzero(buffer, HTTPD_MAX_OUTPUT_BUFFER_SIZE);
        va_start(ap, format);
        vsprintf(buffer, format, ap);
        va_end(ap);
        return httpd_send_string(task->spare4, buffer);
    }
    
    /* Since we've sent content of unknown length,
     * keep-alive flag should be disabled.
     */
    task->spare3 &= ~HTTPD_FLAG_KEEP_ALIVE;
    
    return HTTPD_ERROR;
}

/**
 * Output the HTTP header to the current http stream
 * @param status HTTP response status
 * @param content Content type
 */
ret_t httpd_header ( int status, http_content_t content ) {
    WIND_TCB *tcb = httpd_current_task();
    /* Content length is not specified ==> keep-alive is not possible */
    tcb->spare3 &= ~HTTPD_FLAG_KEEP_ALIVE;
    return httpd_send_header(tcb->spare4, status, content);
}

/**
 * Send HTTP response with keep-alive flag enabled
 */
ret_t httpd_keep_alive ( int status, http_content_t content, int length, void *data ) {
    WIND_TCB *tcb = httpd_current_task();
    ret_t ret = httpd_send_keep_alive_header(tcb->spare4, status, content, length);
    if ( (ret == HTTPD_OK) && (length > 0)) {
        ret = httpd_send(tcb->spare4, data, length);
    }
    /* Keep-alive flag is set by default, it should not be reenabled here */
    return ret;
}

/**
 * Process the incoming url request
 * @param socket Socket for I/O operations
 * @param url URL string
 * @param params String of passed parameters, e.g. 'id=123&name=test'
 * @return Error status value
 */
ret_t httpd_process_url ( char *url, char *params ) {
    struct resource_s *resource;
    WIND_TCB *task;

	if ( url[1] == ' ' )
		url[1] = '\0';

#ifdef HTTPD_DEBUG
    logMsg("HTTPD: Processing URL='%s | %s'\n", url, params);
#endif

    resource = httpd_find_resource(url);
    if ( NULL == resource ) {
#ifdef HTTPD_ALLOW_FILES
		/* Try to load the requested resource from file */
		char filename[255];
		char fbuffer[4096];
		FILE *f;
		int toread;
		http_content_t content;
		char *dot;

		/* Form the file name with a path */
		bzero(filename, 255);
		strcpy(filename, HTTPD_DOC_ROOT);
		strcat(filename, url);

		/* Try to open this file */
#ifdef HTTPD_DEBUG
		logMsg("HTTPD: Opening file '%s'\n", filename);
#endif
		f = fopen(filename, "rb");
		if ( !f ) {
			/* May be this is a directory? */
			if ( filename[strlen(filename)-1] != '/' )
			    strcat(filename, "/");
			strcat(filename, HTTPD_INDEX_FILE);
#ifdef HTTPD_DEBUG
			logMsg("HTTPD: Opening file '%s'\n", filename);
#endif
			f = fopen(filename, "rb");
			if ( !f ) {
				/* We do not browse directory without an index file */
#ifdef HTTPD_DEBUG
				logMsg("HTTPD: Resource '%s' cannot be processed\n", filename);
#endif
				return HTTPD_ERROR;
			}
		}

#ifdef HTTPD_DEBUG
		logMsg("Loading file: '%s'\n", filename);
#endif

		/* Ok. Here we need to determine the file type */
		content = CONTENT_TEXT_HTML; /* This is by default */
		dot = filename + strlen(filename) - 1;
		while ( dot > filename ) {
			if ( *dot == '.' )
				break;
			dot--;
		}

		if ( *dot == '.' ) {
			/* We have a file extention to guess the type */
			dot++;
			/*
			 * @TODO: Replace by look-up loop 
			 */
			if ( strcmp(dot, "txt") == 0 ) {
				content = CONTENT_TEXT_PLAIN;
			} else if ( strcmp(dot, "xml") == 0 ) {
				content = CONTENT_TEXT_XML;
			} else if ( strcmp(dot, "gif") == 0 ) {
				content = CONTENT_IMAGE_GIF;
			} else if ( strcmp(dot, "jpg") == 0 || strcmp(dot, "jpeg") == 0 ) {
				content = CONTENT_IMAGE_JPEG;
			} else if ( strcmp(dot, "png") == 0 ) {
				content = CONTENT_IMAGE_PNG;
			}
		}

		/* Sending file (with a HTTP header) to a client */
		task = httpd_current_task();
		httpd_header(HTTP_OK, content);
		while ( (toread = fread(fbuffer, 1, 4096, f)) > 0 ) {
			if ( HTTPD_OK != httpd_send(task->spare4, fbuffer, toread) )
				break;
		}

		fclose(f);
#else
		return HTTPD_ERROR;
#endif
        return HTTPD_OK;
    } else {
#ifdef HTTPD_DEBUG
        logMsg("HTTPD: Call to resource function\n");
#endif

#ifdef HTTPD_STDIO_REDIRECT
		/* Setting up std output for the task created.
		 * In this way we can use printf() for output to the http stream.
		 */
		task = httpd_current_task();
        ioTaskStdSet(0, 1, task->spare4);
#endif
        resource->func(params, strlen(params));
    }

    return HTTPD_OK;
}

/**
 * Process request sent via POST method
 * @param url Resourse to serve
 * @param data Pointer to data buffer received from a client
 * @param length Size of data buffer
 */
ret_t httpd_process_post ( char *url, char *data, int length ) {
    struct resource_s *resource;
    WIND_TCB *task;

	if ( url[1] == ' ' )
		url[1] = '\0';

#ifdef HTTPD_DEBUG
    logMsg("HTTPD: Processing POST request URL='%s | %s'\n", url, params);
#endif

    resource = httpd_find_resource(url);
    if ( NULL == resource ) {
		return HTTPD_ERROR;
    } else {
#ifdef HTTPD_DEBUG
        logMsg("HTTPD: Call to POST handling function\n");
#endif

#ifdef HTTPD_STDIO_REDIRECT
		/* Setting up std output for the task created.
		 * In this way we can use printf() for output to the http stream.
		 */
		task = httpd_current_task();
        ioTaskStdSet(0, 1, task->spare4);
#endif
        resource->func(data, length);
    }

    return HTTPD_OK;

}

/**
 * Single session task routine
 * @param sock Socket for I/O
 */
int httpd_session ( int sock ) {
    int selectres;
	struct timeval timeout;
    fd_set read_fdset;
    char buffer[HTTPD_MAX_INPUT_BUFFER_SIZE];
	char empty[HTTPD_MAX_INPUT_BUFFER_SIZE];
    char method[20];
    char url[255];
    char params[255];
	int keep_alive_counter;
    int http_content_length;
    WIND_TCB    *tcb;
    BOOL keep_alive = TRUE;

#ifdef HTTPD_DEBUG
    logMsg("HTTPD: Starting new session\n");
#endif

	/*
	 * @TODO: Use sinptr to filter/log access to the server
	 */

	timeout.tv_sec = HTTPD_REQUEST_TIMEOUT / 1000;
	timeout.tv_usec = (HTTPD_REQUEST_TIMEOUT % 1000) * 1000;

    tcb = httpd_current_task();
    
    keep_alive_counter = 0;
    while ( keep_alive && (keep_alive_counter <= HTTPD_KEEP_ALIVE_TIMEOUT) ) {

		FD_ZERO(&read_fdset);
		FD_SET(sock, &read_fdset);

#ifdef HTTPD_DEBUG
		logMsg("HTTPD: Waiting for data (%d / %d)...\n", keep_alive_counter, HTTPD_KEEP_ALIVE_TIMEOUT);
#endif
		selectres = select(sock + 1, &read_fdset, NULL, NULL, &timeout);
        if ( selectres < 0 ) {
#ifdef HTTPD_DEBUG
            logMsg("HTTPD: select() < 0\n");
#endif
            break;
        }
        if ( selectres == 0 ) {
#ifdef HTTPD_DEBUG
			logMsg("HTTPD: select() == 0\n");
#endif
            keep_alive_counter++;
            continue;
        }

        if ( FD_ISSET(sock, &read_fdset)) {
            int result;
            char *p1, *p2;

            http_content_length = -1; /* content length is undefined */
            
            bzero(buffer, HTTPD_MAX_INPUT_BUFFER_SIZE);
            result = httpd_read_line(sock, buffer);
#ifdef HTTPD_DEBUG
			logMsg("HTTPD: buffer='%s'\n", buffer);
#endif
            if ( result < 0 ) {
#ifdef HTTPD_DEBUG
                logMsg("HTTPD: httpd_read_line() returned %d\n", result);
#endif
				break;
            }

            if ( result == 0 ) {
#ifdef HTTPD_DEBUG
                logMsg("HTTPD: nothing was sent to server\n");
#endif
                break;      /* Nothing was send to the server */
            }

			/* Read till the empty line */
			while ( result ) {
                bzero(empty, HTTPD_MAX_INPUT_BUFFER_SIZE);
				result = httpd_read_line(sock, empty);
                if ( strlen(empty) == 0 ) {
                    /* Request terminates by an empty line */
                    break;
                } else if ( strncmp(empty, "Content-Length: ", 16) == 0 ) {
                    char len[12] = "";                   
                    bzero(len, 12);
                    strncpy(len, empty + 16, 12);
                    http_content_length = atoi(len);
                }
			}
			
            if ( result < 0 ) {
				break;
			}

            /* Since we have received a request, clear the
             * keep-alive timeout counter.
             */
            keep_alive_counter = 0;
            
            bzero(method, 20);
            bzero(url, 255);
            if ( strncmp(buffer, "GET", 3) == 0 || strncmp(buffer, "PUT", 3) == 0 ) {
                strncpy(method, buffer, 3);
                p2 = buffer + 4;
            } else if ( strncmp(buffer, "POST", 4) == 0 ) {
                strncpy(method, buffer, 4);
                p2 = buffer + 5;
            } else
                p2 = buffer;
            
            p1 = url;
            
            /* here we scan the read line till ' ' or '?' character */
            while ( *p2 && !isspace(*p2) ) {
                if (*p2 == '?') {
#ifdef HTTPD_DEBUG
                    logMsg("HTTPD: '?' parameter symbol detected\n");
#endif
                    break;
                }
                *p1++ = *p2++;
            }
            /* read the passed parameters line */
            bzero(params, 255);
			if ( *p2 == '?' ) {
                p1 = params;
				p2++;
                while ( *p2 && !isspace(*p2) ) {
                    *p1++ = *p2++;
                }
			}

#ifdef HTTPD_DEBUG
            logMsg("HTTPD: url='%s'\n", url);
            logMsg("HTTPD: method='%s'\n", method);
#endif

            /* Check the access method */
            if ( strcmp(method, "GET") == 0 || strcmp(method, "PUT") == 0 ) {
                /* GET & PUT methods */
                if ( HTTPD_OK != httpd_process_url(url, params) ) { /* Process URL */
                    httpd_send_header(sock, HTTP_NOT_FOUND, CONTENT_TEXT_HTML);
                    httpd_send_string(sock, "<html><head><title>Server Error</title></head><body style=\"font-family:verdana,tahoma,sans-serif\">\n");
                    httpd_send_string(sock, "<h1 style=\"color:#FF0000\">404</h1>\n");
                    httpd_send_string(sock, "The requested resource is not registered or cannot be served.<br>\n");
                    httpd_send_string(sock, "<hr>\n<address>Embedded HTTP server</address>\n");
                    httpd_send_string(sock, "</body></html>\n");
                    keep_alive = FALSE;
                }
            } else if ( (strcmp(method, "POST") == 0) && (http_content_length > 0) ) {
                /* POST method */
                char *data_buffer;
                data_buffer = (char*)malloc(http_content_length);
                if ( HTTPD_OK != httpd_read_buffer(sock, data_buffer, http_content_length) ) {
                    httpd_send_header(sock, HTTP_NOT_FOUND, CONTENT_TEXT_HTML);
                    httpd_send_string(sock, "<html><head><title>Server Error</title></head><body style=\"font-family:verdana,tahoma,sans-serif\">\n");
                    httpd_send_string(sock, "<h1 style=\"color:#FF0000\">501</h1>\n");
                    httpd_send_string(sock, "Invalid POST request received that cannot be handled.<br>\n");
                    httpd_send_string(sock, "<hr>\n<address>Embedded HTTP server</address>\n");
                    httpd_send_string(sock, "</body></html>\n");
                    keep_alive = FALSE;
                } else {
                    if ( HTTPD_OK != httpd_process_post(url, data_buffer, http_content_length) ) { /* Process URL */
                        httpd_send_header(sock, HTTP_NOT_FOUND, CONTENT_TEXT_HTML);
                        httpd_send_string(sock, "<html><head><title>Server Error</title></head><body style=\"font-family:verdana,tahoma,sans-serif\">\n");
                        httpd_send_string(sock, "<h1 style=\"color:#FF0000\">404</h1>\n");
                        httpd_send_string(sock, "The requested resource is not registered or cannot be served.<br>\n");
                        httpd_send_string(sock, "<hr>\n<address>Embedded HTTP server</address>\n");
                        httpd_send_string(sock, "</body></html>\n");
                        /* keep_alive = FALSE; */
                    }
                }
                free(data_buffer);
            } else {
                /* Other methods are not supported */
                httpd_send_header(sock, HTTP_NOT_IMPLEMENTED, CONTENT_TEXT_HTML);
				httpd_send_string(sock, "<html><head><title>Server Error</title></head><body style=\"font-family:verdana,tahoma,sans-serif\">\n");
				httpd_send_string(sock, "<h1 style=\"color:#FF0000\">501</h1>\n");
                httpd_send_string(sock, "Only GET and PUT methods are supported, sorry.<br>\n");
				httpd_send_string(sock, "<hr>\n<address>Embedded HTTP server</address>\n");
				httpd_send_string(sock, "</body></html>\n");
                keep_alive = FALSE;
            }
                        
            if ( keep_alive ) {
                keep_alive = (tcb->spare3 & HTTPD_FLAG_KEEP_ALIVE) ? TRUE : FALSE;
            }
            
            if ( !keep_alive ) {
                break; /* Terminate this session */
            }
        } else
            keep_alive_counter++;
        taskDelay(1);
    } /* while () */

#ifdef HTTPD_DEBUG
    logMsg("HTTPD: Close session\n");
#endif
	taskDelay(15); /* Give it some time to send all buffered data before closing */
	shutdown(sock, 2);
    close(sock);
    return OK;
}

/**
 * A hook routined called when the task terminates
 * @param tcb Task control block
 * @return vxWorks error status value
 */
int httpd_delete ( WIND_TCB *tcb ) {
    int i;

    if ( tcb == httpd_task ) {
#ifdef HTTPD_DEBUG
        logMsg("HTTPD: Delete main task\n");
#endif
		taskDelay(1);
        semFlush(httpd_sem);
        semDelete(httpd_sem);
    }  else {

        /* Close session task */
        for ( i = 0; i < HTTPD_MAX_SESSIONS; i++ ) {
            if ( tcb == httpd_tasks[i] ) {
#ifdef HTTPD_DEBUG
                logMsg("HTTPD: Delete session task\n");
#endif
                httpd_tasks[i] = 0;
                break;
            }
        }
    }
    return OK;
}


/**
 * Server task routine
 * @param sock Socket for I/O
 * @param sinptr Address binded
 * @return vxWorks error status value
 */
int httpd_main ( int port/*int sock, struct sockaddr_in *sinptr*/ ) {
    int sock;
    struct sockaddr_in sin_;
    int client;
    char task_name[25];
    int optionVal;
    struct linger   linger;
    int i;

#ifdef HTTPD_DEBUG
    logMsg("HTTPD: Starting httpd main task...\n");
#endif

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if ( sock == ERROR )
        return HTTPD_SOCKET_ERROR;

    /* Setting up socket options */
    optionVal = 1;
    if ( setsockopt(sock, SOL_SOCKET, SO_REUSEADDR,  (char *)&optionVal, sizeof(optionVal) ) == ERROR ) {
#ifdef HTTPD_DEBUG
        logMsg("SO_REUSEADDR failed\n");
#endif
        close(sock);
        return HTTPD_SOCKET_ERROR;
    }
    
    if ( setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE,  (char *)&optionVal, sizeof(optionVal) ) == ERROR ) {
#ifdef HTTPD_DEBUG
        logMsg("SO_KEEPALIVE failed\n");
#endif
        close(sock);
        return HTTPD_SOCKET_ERROR;
    }
/*    
    if ( setsockopt(sock, IPPROTO_TCP, TCP_NODELAY,  (char *)&optionVal, sizeof(optionVal) ) == ERROR ) {
#ifdef HTTPD_DEBUG
        logMsg("TCP_NODELAY failed\n");
#endif
        close(sock);
        return HTTPD_SOCKET_ERROR;
    }
*/
    linger.l_onoff = 1;
    linger.l_linger = 0;
    if ( setsockopt(sock, SOL_SOCKET, SO_LINGER,  (char *)&linger, sizeof(linger) ) == ERROR ) {
#ifdef HTTPD_DEBUG
        logMsg("SO_LINGER failed\n");
#endif
        close(sock);
        return HTTPD_SOCKET_ERROR;
    }
        
    bzero((char*)&sin_, sizeof(sin_));
    sin_.sin_family = AF_INET;
    sin_.sin_len = sizeof(sin_);
    sin_.sin_port = htons(port);
    sin_.sin_addr.s_addr = htonl(INADDR_ANY);

    if ( bind(sock, (struct sockaddr*)&sin_, sizeof(sin_)) == ERROR ) {
    	close(sock);
        return HTTPD_BIND_ERROR;
    }

    if ( listen(sock, 1) != OK ) {
    	close(sock);
        return HTTPD_LISTEN_ERROR;
    }

    httpd_task = httpd_current_task();
    httpd_task->spare4 = sock;

    if ( ERROR == taskDeleteHookAdd(httpd_delete) ) {
    	close(sock);
        return HTTPD_HOOK_ERROR;
   	}

    /* Initialising semaphore */
    httpd_sem = semBCreate(SEM_Q_FIFO, SEM_EMPTY);
    semGive(httpd_sem);

    for ( ; ; ) {
        int task_id;
        int size = sizeof(struct sockaddr_in);

        client = accept(sock, (struct sockaddr *)&sin_, &size);
        if ( client == ERROR ) {
        	close(sock);
            return ERROR;
        }

        /* Setting up socket options */
        optionVal = 1;
        if ( setsockopt(client, SOL_SOCKET, SO_REUSEADDR,  (char *)&optionVal, sizeof(optionVal) ) == ERROR ) {
#ifdef HTTPD_DEBUG
            logMsg("SO_REUSEADDR failed\n");
#endif
        }
    
        if ( setsockopt(client, SOL_SOCKET, SO_KEEPALIVE,  (char *)&optionVal, sizeof(optionVal) ) == ERROR ) {
#ifdef HTTPD_DEBUG
            logMsg("SO_KEEPALIVE failed\n");
#endif
        }
/*    
        if ( setsockopt(client, IPPROTO_TCP, TCP_NODELAY,  (char *)&optionVal, sizeof(optionVal) ) == ERROR ) {
#ifdef HTTPD_DEBUG
            logMsg("TCP_NODELAY failed\n");
#endif
        }
*/
        linger.l_onoff = 1;
        linger.l_linger = 0;
        if ( setsockopt(client, SOL_SOCKET, SO_LINGER,  (char *)&linger, sizeof(linger) ) == ERROR ) {
#ifdef HTTPD_DEBUG
            logMsg("SO_LINGER failed\n");
#endif
        }
        
        /* Looking for unused session */
        for ( i = 0; i < HTTPD_MAX_SESSIONS; i++ ) {
            if ( httpd_tasks[i] == 0 )
                break;
        }
        if ( i < HTTPD_MAX_SESSIONS ) {
            sprintf(task_name, "httpd%d", i);
            task_id = taskSpawn(task_name, HTTPD_SESSION_PRIORITY, 0,
                            HTTPD_SESSION_STACK_SIZE, httpd_session,
                            client, 0, 0, 0, 0, 0, 0, 0, 0, 0);
            httpd_tasks[i] = taskTcb(task_id);
			httpd_tasks[i]->spare4 = client;
            httpd_tasks[i]->spare3 = HTTPD_FLAG_KEEP_ALIVE; /* By default we force connection keep alive */
        } else {
            /* Too many sessions */
#ifdef HTTPD_DEBUG
		    logMsg("HTTPD: Too many sessions...\n");
#endif
            close(client);
        }
		/* taskDelay(60); */
    }
    return OK;
}


/**
 * Initialise the http server
 * @param port TCP port to listen
 * @return error code if not zero
 */
ret_t httpd_start ( unsigned int port ) {
    int i;

#ifdef HTTPD_DEBUG
    logMsg("HTTPD: Starting httpd...\n");
#endif

    if ( httpd_sem != NULL ) {
        return HTTPD_ALREADY_STARTED;
    }

    /* Initialising internal structures */
    httpd_sem = NULL;
    httpd_resource_list = NULL;
    for ( i = 0; i < HTTPD_MAX_SESSIONS; i++ )
        httpd_tasks[i] = (WIND_TCB*)NULL;


    /* Spwaning tasks */
    httpd_task_id = taskSpawn("uHTTPD", HTTPD_MAIN_PRIORITY, 0,
    			    HTTPD_MAIN_STACK_SIZE, httpd_main,
    			    port, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    /* Waiting for server to start */
    while ( NULL == httpd_sem )
        taskDelay(60);

#ifdef HTTPD_DEBUG
    logMsg("Httpd is started.\n");
#endif

    /* Register some resources */
    httpd_register_resource("", &www_index);
    httpd_register_resource("/", &www_index);
    httpd_register_resource("/index.html", &www_index);

    cgi_ios_init();

    return HTTPD_OK;
}

/**
 * Stop the http server
 * @return Error code
 */
ret_t httpd_stop ( ) {
    struct resource_s *item;

    taskDelete(httpd_task_id);

    /* Delete the list of resources */
    item = httpd_resource_list;
    while ( item ) {
        httpd_resource_list = httpd_resource_list->next;
        free(item->url);
        free(item);
        item = httpd_resource_list;
    }
	
	/* Delete httpd semaphore */
	semFlush(httpd_sem);
	semDelete(httpd_sem);
	httpd_sem = NULL;

    return HTTPD_OK;
}

/* -------------------------------------------------------------------------- */

ret_t httpd_get_param ( const char *paramstr, const char *param_name, char *value ) {
    int srcpos;
    int dstpos;
    int paramstr_len;
    int param_name_len;
    if ( paramstr == NULL || param_name == NULL || value == NULL )
        return HTTPD_ERROR;
    paramstr_len = strlen(paramstr);
    param_name_len = strlen(param_name);
    srcpos = 0;
    dstpos = 0;

    while ( srcpos <= (paramstr_len - param_name_len - 1) ) {
        do {
            if ( strncmp(&paramstr[srcpos], param_name, param_name_len) == 0 ) {
                /* We found parameter name, is it a parameter string? */
                if ( srcpos > 0 ) {
                    if (paramstr[srcpos-1] != '&')
                        break; /* no */
                }
                if ( paramstr[srcpos + param_name_len] != '=' )
                    break; /* no */
                /* Hey! We've found our parameter! */
                srcpos += param_name_len + 1;
                while ( srcpos < paramstr_len ) {
                    if ( paramstr[srcpos] == '&' )
                        break;
                    value[dstpos++] = paramstr[srcpos++];
                }
                value[dstpos] = 0; /* end of the string */
                return HTTPD_OK;
            }
        } while (0);
        srcpos++;
    }

    /* Required parameter was not found */
    return HTTPD_ERROR;
}

/* -------------------------------------------------------------------------- */
/* Some resources for test */

static int www_idx = 0;

/**
 * Default index page stub
 */
static void www_index( char *paramstr, int length ) {    
	struct resource_s *item;    
#define _MAX_TASKS  128
    int count;
    TASK_DESC tdesc;
    int tid;
    int task_id_list[_MAX_TASKS];
	
    (void) paramstr; /* Unused parameter */
    (void) length;
    
    httpd_header(HTTP_OK, CONTENT_TEXT_HTML);

    printf("<html><head><title>vxWorks embedded web server</title></head>");
	printf("<body style=\"font-family:verdana,tahoma,sans-serif;font-size:10pt\">\n");
	printf("<table width=100%%><tr><td style=\"background-color:#66FF66\">\n");
    printf("<h2>Control Unit Embedded Web Server</h2>\n");
	printf("</td></tr></table>\n");
    printf("<p>If you can see this message, this means that HTTP server is up and running.<br><br><br>\n");
	printf("<p>Use <i>httpd_unregister_resource()</i> function in order to remove this page\n");
	printf("<p>Use <i>httpd_register_resource()</i> function in order to replace this page by some other one\n");
    printf("<hr>\n");
	/* Print the list of all registered resources */
	printf("<h3>Registered resources:</h3>\n");
	item = httpd_resource_list;	
	while ( item ) {
		printf("<li><a href=\"%s\">/%s</a>\n", item->url, item->url);
		item = item->next;
	}
    printf("<hr>\n");
    printf("<table border><caption align=top>VxWorks Target Task List</caption><tr><th>Name<th>Priority<th>Options<th>Status\n");
    count = taskIdListGet(task_id_list, _MAX_TASKS);
    for ( tid = 0; tid < count; tid++ ) {
        if ( taskInfoGet(task_id_list[tid], &tdesc) != OK )
            break;
        printf("<tr><td>%.12s <td>%.10d <td>0x%.10x <td>0x%.10x<br>\n",
            tdesc.td_name, tdesc.td_priority, tdesc.td_options, tdesc.td_status);
    }
    printf("</table>\n");
	printf("<hr>\n");
    printf("<address>This page was served <b>%d</b> times.</address>\n", ++www_idx);
    printf("</body></html>\n");
}

/* -------------------------------------------------------------------------- */
/* End of file */
