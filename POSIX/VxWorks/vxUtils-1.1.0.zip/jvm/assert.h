/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_ASSERT_H__
#define __JVM_ASSERT_H__

/**
 * @file assert.h
 *
 * Assertions
 */

/** Stop everything */
#define HALT(c)     exit(c)

/** Pring a message and halt */
#define PANIC(fmt,args...)	\
	{	\
		printf("PANIC: file '%s', line %d, function '%s'\n", __FILE__, __LINE__, __PRETTY_FUNCTION__);	\
		printf("\t" fmt, ##args);	\
		HALT(-1);	\
	}

/** Print a debug message */
#define DEBUG(fmt,args...)	\
	{	\
		printf("DEBUG: file '%s', line %d, function '%s'\n", __FILE__, __LINE__, __PRETTY_FUNCTION__);	\
		printf("\t" fmt, ##args);	\
	}

/** Halt on false condition */
#define ASSERT(cond)	\
	{	\
		if(!(cond)) { \
			printf("ASSERT: file: '%s', line %d, function: '%s'\n\t%s\n",   \
				__FILE__, __LINE__, __FUNCTION__, # cond);   \
			HALT(-1);   \
		}	\
	}
												
#endif /* __JVM_ASSERT_H__ */

/* End of file */

