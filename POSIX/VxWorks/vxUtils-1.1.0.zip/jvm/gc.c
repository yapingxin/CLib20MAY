/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

#include "types.h"
#include "heap.h"
#include "class.h"
#include "hash.h"
#include "exec.h"
#include "thread.h"
#include "gc.h"

/**
 * Mark heap block with a specific GC flag
 */
#define GC_MARK(block,flag)		{	\
	if ( block ) {				\
		block->flags &= 0xFFFFFFF0;	\
		block->flags |= flag;		\
	}							\
}

/* ------------------------------------------------------ */

void gc_pass_object_block ( heap_t *heap, heap_block_t *object_block ) {
	object_t *object;
	heap_block_t *block;
	int i;
	
	ASSERT(object_block);
	if ( object_block->flags & HEAP_FLAG_GC_GREY )
		return;
	GC_MARK(object_block, HEAP_FLAG_GC_GREY);
	object = (object_t *)object_block->link;
	if ( !object->data )
		return;
	block = heap_find(heap, object->data);
	ASSERT(block);
		
	/* Mark object's data */
	GC_MARK(block, HEAP_FLAG_GC_GREY);
	
	/* If this object is an array of objects */
	if ( object->array_type == T_OBJECT ) {
		for ( i = 0; i < (int)object->array_length; i++ ) {
			object_t *array_item = (object_t *)(object->data + i * SIZE_ARRAY);
			if ( array_item ) {
				block = heap_find(heap, array_item);
				ASSERT(block);
				gc_pass_object_block(heap, block);
			}
		}
	} else if ( object->array_type == 0 ) {
		/* This object is not an array. Pass throught the fields */
		for ( i = 0; i < object->class->fields_count; i++ ) {
			field_t *field = &(object->class->fields[i]);
			if ( (field->signature[0] == SIG_ARRAY) || (field->signature[0] == SIG_OBJECT) ) {
				object_t *obj = (object_t *)*((int*)(object->data + field->offset));
				if ( obj ) {
					block = heap_find(heap, obj);
					ASSERT(block);
					gc_pass_object_block(heap, block);				
				}
			}
		}
	}
}

/* ------------------------------------------------------ */

void gc_pass_object ( heap_t *heap, object_t *object ) {
	if ( object ) {
		heap_block_t *block = heap_find(heap, object);
		ASSERT(block);
		gc_pass_object_block(heap, block);
		/* gc_pass_object_block(heap, (heap_block_t *)((int)object - sizeof(heap_block_t))); */
	}
}

/* ------------------------------------------------------ */

void gc_run ( exec_t *exec ) {
	int i;
	heap_block_t *block;
	java_thread_t *java_thread;
	heap_t *heap = exec->heap;

	/* Mark all grey objects as white (unused) except black objects */
	heap_mark(heap, HEAP_FLAG_GC_GREY, HEAP_FLAG_GC_WHITE, HEAP_FLAG_GC_BLACK);
	
	/* Browse all classes in the hash table and mark all static fields */
	hash_table_lock(exec->hash_table_class);
	for ( i = 0; i < (int)exec->hash_table_class->count; i++ ) {
		int f;
		hash_entry_t *entry = &(exec->hash_table_class->entries[i]);
		class_t *class = (class_t *)(entry->data);
		block = heap_find(heap, class);
		ASSERT(block);
		ASSERT(block->flags & HEAP_FLAG_GC_BLACK);
		/* for each field */
		for ( f = 0; f < class->fields_count; f++ ) {
			field_t *field = &(class->fields[f]);
			if ( field->access_flags & ACC_STATIC ) {
				if ( (field->signature[0] == SIG_ARRAY) ||
				     (field->signature[0] == SIG_OBJECT) ) {
					/* marking this object if it is not NULL */
					if ( field->static_value ) {
						block = heap_find(heap, (void *)(field->static_value));
						ASSERT(block);
						ASSERT(block->flags & HEAP_FLAG_GC_OBJECT);
						if ( !(block->flags & HEAP_FLAG_GC_BLACK) ) {
							gc_pass_object_block(heap, block);
						}
					}
				}
			}
		}
	}
	hash_table_unlock(exec->hash_table_class);
		
	/* Browse all java threads */
	java_thread = (java_thread_t *)java_thread_all();
	while ( java_thread ) {
		s4 *sp;
		frame_t *frame;
		
		exec = java_thread->exec;
		if ( java_thread->thread_object ) {
			gc_pass_object(heap, java_thread->thread_object);
		}
			
		if ( exec->exception ) {
			gc_pass_object(heap, exec->exception);
		}
			
		/* Browsing stack */
		/* sp = (int *)(exec->frame->locals + exec->frame->method->max_locals + exec->frame->method->max_stack + sizeof(frame_t));  */
		
		sp = exec->sp;
		/* The current stack pointer (exec->sp) points actually to the
		 * next available position in stack. Normally, this position is empty.
		 */
		sp--;		
		while ( (int)sp >= (int)exec->stack ) {
			block = heap_find(heap, (int *)*sp);
			if ( block ) {
				if ( !(block->flags & HEAP_FLAG_GC_BLACK) )
					if ( block->flags & HEAP_FLAG_GC_OBJECT )
						gc_pass_object_block(heap, block);
			}
			sp--;
		}
		
		/* We do not need to browse the frames, as far as they have
		 * been already browsed within the stack.
		 */
		
		
		/* Move to the next thread */
		java_thread = java_thread->next;
	}
	
    /* Mark all spotted objects as GREY */
    heap_mark(heap, HEAP_FLAG_SPOT, HEAP_FLAG_GC_GREY, HEAP_FLAG_GC_BLACK);
    
	/* Remove all objects that are white */
	heap_release(heap, HEAP_FLAG_GC_WHITE);
}

/* ------------------------------------------------------ */

void gc ( ) {
	heap_t *heap;
	exec_t *exec = exec_get();
	if ( !exec )
		return;
	heap = exec->heap;
	if ( !heap )
		return;
		
	heap_lock(heap);
	/* printf("BEFORE Allocated: %d bytes; Limit: %d bytes\n", heap->allocated, heap->limit); */
	gc_run(exec);
	/* printf("AFTER Allocated: %d bytes; Limit: %d bytes\n", heap->allocated, heap->limit); */
	heap_unlock(heap);
	/* PANIC("STOP"); */
}

/* ------------------------------------------------------ */

void *gc_alloc ( heap_t *heap, unsigned int size, unsigned int flags ) {
    void *ptr;
    heap_lock(heap);
    ptr = heap_alloc(heap, size, flags);
    heap_unlock(heap);
    return ptr;
}

/* ------------------------------------------------------ */

void gc_free ( heap_t *heap, void *ptr ) {
    heap_lock(heap);
    heap_free(heap, ptr);
    heap_unlock(heap);
}

/* ------------------------------------------------------ */

void gc_unref_ptr ( heap_t *heap, void *ptr ) {
    if ( ptr != NULL ) {
        heap_block_t *heap_block = heap_find(heap, ptr);
        if ( heap_block ) {
            heap_block->refcount--;
            ASSERT(heap_block->refcount >= 0);
            heap_free_block(heap, heap_block);
        }
    }
}

/* ------------------------------------------------------ */

void gc_unref ( heap_t *heap, ... ) {
    void *ptr;
    va_list ap;
    
    heap_lock(heap);
    va_start(ap, heap);
    do {
        ptr = va_arg(ap, void*);
        if ( ptr )
            gc_unref_ptr(heap, ptr);
    } while ( ptr != NULL );
    va_end(ap);
    
    heap_unlock(heap);
}

/* ------------------------------------------------------ */

void gc_set_ptr ( heap_t *heap, void **ptr, void *val ) {
    heap_lock(heap);
    gc_unref_ptr(heap, *ptr);
    if ( val != NULL ) {
        heap_block_t *heap_block = heap_find(heap, *ptr);
        if ( heap_block ) {
            heap_block->refcount++;
            ASSERT(heap_block->refcount >= 0);
        }
        
        /* We have to infort the GC that val pointer is still in use */
        heap_block = heap_find(heap, val);
        if ( heap_block ) {
            heap_block->flags |= HEAP_FLAG_SPOT;
        }
    }
    *ptr = val;
    heap_unlock(heap);
}

/* ------------------------------------------------------ */
/* End of file */

