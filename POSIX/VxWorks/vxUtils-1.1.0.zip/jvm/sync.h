/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_SYNC_H__
#define __JVM_SYNC_H__

/**
 * @file sync.h
 *
 * Threads synchronization primitives
 */

#ifdef VXWORKS
#	include <vxWorks.h>
#	include <semLib.h>
#else
#	include <pthread.h>
#endif

#include "types.h"

/** Mutual semaphore and waiting queue **/
#ifdef VXWORKS
typedef SEM_ID mutex_t;
typedef SEM_ID waitq_t;
#else
typedef pthread_mutex_t mutex_t;
typedef struct {
	pthread_mutex_t mutex;	/* mutex		*/
	pthread_cond_t cond;	/* condition	*/
} waitq_t;
#endif

/**
 * Initialize a mutex
 *
 * @param mutex Pointer to mutex to be initialized
 */
void mutex_init ( mutex_t *mutex );

/**
 * Delete mutex
 *
 * @param mutex Pointer to mutex to be released
 */
void mutex_release ( mutex_t *mutex );

/**
 * Lock a mutex
 * This function will block if the mutex is busy.
 *
 * @param mutex Pointer to mutex to be locked
 */
void mutex_lock ( mutex_t *mutex );

/**
 * Try to lock a mutex
 *
 * @param mutex Pointer to mutex to be locked
 * @return TRUE is mutex was locked, FALSE if mutex is busy
 */
bool_t mutex_try_lock ( mutex_t *mutex );

/**
 * Unlock a mutex
 *
 * @param mutex Pointer to mutex to be unlocked
 */
void mutex_unlock ( mutex_t *mutex );

/**
 * Initialize the waiting queue
 *
 * @param waitq Pointer to the waiting queue
 */
void waitq_init ( waitq_t *waitq );

/**
 * Delete the waiting queue
 *
 * @param waitq Pointer to the waiting queue
 */
void waitq_release ( waitq_t *waitq );

/**
 * Start waiting in the waiting queue
 *
 * @param waitq Pointer to the waiting queue
 * @param ticks Number of milliseconds to wait
 * @return non 0 if timeout occured, 0 if interrupted
 */
int waitq_wait ( waitq_t *waitq, int ticks );

/**
 * Unblock one task that waits in the waiting queu
 *
 * @param waitq Pointer to the waiting queue
 */
void waitq_unblock ( waitq_t *waitq );

/**
 * Unblock all tasks waiting in the queue
 *
 * @param waitq Pointer to the wating queue
 */
void waitq_unblock_all ( waitq_t *waitq );

#endif /* __JVM_SYNC_H__ */
