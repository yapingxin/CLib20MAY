/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_THREAD_H__
#define __JVM_THREAD_H__

/**
 * @file thread.h
 *
 * Handling threads based on system threads
 */

#ifdef VXWORKS
#	include <taskLib.h>
#else
#	include <pthread.h>
#endif

#include "types.h"
#include "class.h"
#include "exec.h"

typedef struct java_thread_s java_thread_t;
struct java_thread_s {
#ifdef VXWORKS
	WIND_TCB	*system_thread;	
#else
    pthread_t	system_thread;		/** Reference to system thread		*/
#endif	
    exec_t		*exec;				/** Execution environment			*/
    object_t	*thread_object;		/** Java Thread object				*/

	waitq_t		waitq;
	
    /* thread list */
    java_thread_t *parent;      /** Parent thread created this one  */
    java_thread_t *next;        /** Next thread in the list         */
};

/**
 * Initializing multithreading
 *
 * @param stack_size Stack size
 * @param heap_size Heap size
 */
void java_thread_init ( size_t stack_size, size_t heap_size );

/**
 * Return current Java thread
 *
 * @return Pointer to current Java thread
 */
java_thread_t *java_thread_self ( );

/**
 * Lock Java threads list
 */
void java_threads_lock ( );

/**
 * Unlock Java threads list
 */
void java_threads_unlock ( );

/**
 * Create a new Java thread
 * If parent thread is NULL, new heap will be created. If not,
 * parent thread's heap will be shared.
 *
 * @param parent Pointer to parent thread
 * @param thread_object Pointer to Java Thread object
 * @param stack_size Java stack size for a new thread
 * @param heap_size Heap size for threads with no parents
 * @return Pointer to created Java thread
 */
java_thread_t *java_thread_create ( java_thread_t *parent, object_t *thread_object, size_t stack_size, size_t heap_size );

/**
 * Return a pointer to the java threads linked list
 *
 * @return Pointer to the first java thread in the list
 */
java_thread_t *java_thread_all ( );

/**
 * Sleep for \a timeout milliseconds
 *
 * @param timeout Sleep timeout (ms)
 * @return TRUE if was interrupted during sleep
 */
bool_t java_thread_sleep ( int timeout );

/**
 * Wake up sleeping java thread
 *
 * @param java_thread Java thread to wake up
 */
void java_thread_wakeup ( java_thread_t *java_thread );

/**
 * Yield the execution of the current thread
 */
void java_thread_yield ( );

/**
 * Returns java thread by the Thread object reference
 *
 * @param thread_object Pointer to the Thread object
 * @return Pointer to the java thread structure
 */
java_thread_t *java_thread_get ( object_t *thread_object );

#endif /* __JVM_THREAD_H__ */

/* End of file */

