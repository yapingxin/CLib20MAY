/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __HEAP_H__
#define __HEAP_H__

/**
 * @file heap.h
 *
 * Custom heap memory allocation
 */


#ifndef NULL
#	define NULL	(0)
#endif

#include "sync.h"

/**
 * Heap block flags
 */
#define HEAP_BLOCK_ALLOCATED	0x80000000

#define HEAP_FLAG_PERMANENT		0x40000000
#define HEAP_FLAG_SPOT			0x20000000
#define HEAP_FLAG_TEST			0x10000000

/**
 * Garbage collector flags
 */
#define HEAP_FLAG_GC_WHITE		0x01000000
#define HEAP_FLAG_GC_GREY		0x02000000
#define HEAP_FLAG_GC_BLACK		0x04000000
#define HEAP_FLAG_GC_TEST		0x08000000

/**
 * Storage types
 */
#define HEAP_FLAG_GC_GENERIC	0x00000000
#define HEAP_FLAG_GC_CLASS		0x00800000
#define HEAP_FLAG_GC_OBJECT		0x00400000
#define HEAP_FLAG_GC_DATA		0x00200000

/**
 * Mask for the id field
 */
#define HEAP_ID_MASK			0x000FFFFF

/**
 * Memory block header
 */
typedef struct heap_block_s heap_block_t;
struct heap_block_s {
	unsigned int flags;	/* Memory block flags 				*/
	unsigned int size;	/* Size of data space (in bytes)	*/
    unsigned int refcount;  /* Reference counter            */
	heap_block_t *link;	/* Link to the next free block or to the beginning of the data	*/
};

/**
 * Heap header
 */
typedef struct heap_s {
	heap_block_t *first_block;	/* Where the heap begins 		*/
	unsigned int size;			/* Size of the heap (in bytes)	*/
	unsigned int granularity;	/* Minimal size of data block	*/
	unsigned int allocated;		/* Total allocated bytes		*/
	unsigned int limit;			/* allocation limit to run garbage collecting */
	unsigned int id;			/* id for allocation functions	*/
	mutex_t mutex;
} heap_t;

/**
 * Create heap based on continious memory pool.
 *
 * @param ptr Pointer to memory pool
 * @param size Size of memory pool in bytes
 * @param granularity Data allocation granularity (1, 2, 4, 8,.. bytes)
 * @return Pointer to heap structure
 */
heap_t *heap_create ( void *ptr, unsigned int size, unsigned int granularity );

/**
 * Allocate memory block from the heap using "first-fit" approach
 *
 * @param heap Pointer to heap
 * @param size Numer of bytes to allocate (> 0)
 * @param flags Memory block flags
 * @return Pointer to memory block of at least \a size bytes in size
 */
void *heap_alloc_first ( heap_t *heap, unsigned int size, unsigned int flags );

/**
 * Allocate memory block from the heap using "best-fit" approach
 * This methof is slower than "first-fit", but leads to less
 * memory fragmentation.
 *
 * @param heap Pointer to heap
 * @param size Number of bytes to allocate (>0)
 * @param flags Memory block flags
 * @return Pointer to memory block of at least \a size byte in size
 */
void *heap_alloc_best ( heap_t *heap, unsigned int size, unsigned int flags );

/**
 * Allocate memory block
 *
 * @param heap Pointer to heap
 * @param size Number f bytes to allocate (>0)
 * @param flags Memory block flags
 * @return Pointer to memory block of at least \a size bytes in size
 */
void *heap_alloc ( heap_t *heap, unsigned int size, unsigned int flags );

/**
 * Free memory block
 *
 * @param heap pointer to heap
 * @param block pointer to heap block
 * @return pointer to released memory block or to the memory block it was merged with
 */
heap_block_t *heap_free_block ( heap_t *heap, heap_block_t *block );

/**
 * Deallocate memory block from the heap
 *
 * @param heap Pointer to the heap
 * @param ptr Pointer to memory block to be deallocated
 */
void heap_free ( heap_t *heap, void *ptr );

/**
 * Mark allocated heap blocks that have flag \a from_flag
 * by flag \a to_flag except items having flag \a except_flag
 *
 * @param heap Pointer to heap
 * @param from_flag Flag to look for
 * @param to_flag Flag to set
 * @param except_flag Flag to be omitted
 */
void heap_mark ( heap_t *heap, unsigned int from_flag, unsigned int to_flag, unsigned int except_flag );

/**
 * Mark allocated heap blocks that have flag \a from_flag
 * by flag \a to_flag except items having flag \a except_flag
 * Treat only those blocks having specified \a id
 *
 * @param heap Pointer to heap
 * @param id Heap id to look for
 * @param from_flag Flag to look for
 * @param to_flag Flag to set
 * @param except_flag Flag to be omitted
 */
void heap_mark_id ( heap_t *heap, unsigned int id, unsigned int from_flag, unsigned int to_flag, unsigned int except_flag );

/**
 * Mark a single heap block that has flag \a from_flag
 * by setting flag \a to_flag, except if it has flag \a except_flag set
 *
 * @param heap Pointer to heap
 * @param ptr Data pointer (returned by \c heap_alloc())
 * @param from_flag Flag to look for
 * @param to_flag Flag to set
 * @param except_flag Flag to be ommited
 */
void heap_mark_block ( heap_t *heap, void *ptr, unsigned int from_flag, unsigned int to_flag, unsigned int except_flag );

/**
 * Generate a new heap identifier
 *
 * @param heap Pointer to heap
 * @return new identifier number
 */
unsigned int heap_new_id ( heap_t *heap );

/**
 * Release all block that have flag \a flag
 *
 * @param heap Pointer to heap
 * @param flag Flag
 */
void heap_release ( heap_t *heap, unsigned int flag );

/**
 * Lock the heap
 *
 * @param heap Pointer to heap
 */
void heap_lock ( heap_t *heap );

/**
 * Unlock the heap
 *
 * @param heap Pointer to heap
 */
void heap_unlock ( heap_t *heap );

/**
 * Find the data block that corresponds to the pointer
 *
 * @param heap Pointer to heap
 * @param data Pointer 
 * @return pointer to heap block or NULL if not found
 */
heap_block_t *heap_find ( heap_t *heap, void *data );

/**
 * Dump debug information on heap memory blocks
 *
 * @param heap Pointer to heap
 */
void heap_dump ( heap_t *heap );

int heap_is_allocated ( heap_t *heap, void *ptr );

#endif /* __HEAP_H__ */
