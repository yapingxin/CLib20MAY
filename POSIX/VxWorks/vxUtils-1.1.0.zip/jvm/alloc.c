/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <stdio.h>

#include "assert.h"
#include "sync.h"

#include "alloc.h"

/**
 * The following data structures are used for tracking the
 * memory allocation and memory leak detection.
 */

#define MAX_ALLOC	128		/** Maximal number of allocations that may exist at a time */

typedef
struct {
	void *ptr;
	size_t size;
} alloc_t;

/*
 * Every memory allocation is traced in the allocations[] array.
 * The total number of allocations (available at the same time)
 * is limitet by the lenght of this array (constant MAX_ALLOC).
 *
 * At the very end of the JVM execution, jvm_memory_cleanup() function
 * has to be called. It will go through the allocation array
 * and release all allocated memory chunks.
 */

static alloc_t allocations[MAX_ALLOC] = { NULL, 0 };

static mutex_t alloc_mutex;

static size_t allocated = 0;

/* ------------------------------------------------------ */

void jvm_alloc_init ( ) {
	allocated = 0;
	mutex_init(&alloc_mutex);
}

/* ------------------------------------------------------ */

void *jvm_alloc ( size_t size ) {
	void *ptr = NULL;
	int i;
	mutex_lock(&alloc_mutex);
	for ( i = 0; i < MAX_ALLOC; i++ ) {
		if ( !allocations[i].ptr ) {
			allocations[i].ptr = malloc(size);
			allocations[i].size = size;
			allocated += size;
			ptr = allocations[i].ptr;
			mutex_unlock(&alloc_mutex);
			return ptr;
		}
	}
	mutex_unlock(&alloc_mutex);
	PANIC("Not enough allocation blocks, probably there is a memory leak problem.\n");
	return NULL;
}

/* ------------------------------------------------------ */

void jvm_free ( void *ptr ) {
	int i;
    ASSERT(ptr != NULL);
	mutex_lock(&alloc_mutex);
    for ( i = 0; i < MAX_ALLOC; i++ ) {
		if ( allocations[i].ptr == ptr ) {
			free(ptr);
			allocations[i].ptr = NULL;
			allocated -= allocations[i].size;
			allocations[i].size = 0;
			mutex_unlock(&alloc_mutex);
			return;
		}
	}
	mutex_unlock(&alloc_mutex);
	PANIC("Freeing something that was never allocated.\n");
}

/* ------------------------------------------------------ */

void jvm_memory_cleanup ( ) {
	int i;
	int cntr = 0;
	mutex_lock(&alloc_mutex);
	for ( i = 0; i < MAX_ALLOC; i++ ) {
		if ( allocations[i].ptr ) {
			free(allocations[i].ptr);
			allocations[i].ptr = NULL;
			allocated -= allocations[i].size;
			allocations[i].size = 0;
			cntr++;
		}
	}
	mutex_unlock(&alloc_mutex);
	mutex_release(&alloc_mutex);
}

/* ------------------------------------------------------ */
/* End of file */

