/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "types.h"
#include "assert.h"
#include "alloc.h"
#include "jar.h"

#include "loader.h"

/**
 * Path to classpath :)
 */
static char classpath[1024];

static void *classpath_jar = NULL;
static zip_file_t *system_classpath_zip = NULL;

/* ------------------------------------------------------ */

void loader_init ( const char *path ) {
    FILE *f;
	
	ASSERT(path);
	
	classpath[0] = '\0';
    if ( path != NULL )
        strcpy(classpath, path);
		
	/* Check is it's a jar archive */
	f = fopen(classpath, "rb");
	if ( f ) {
		long file_size;
		
		fseek(f, 0, SEEK_END);
		file_size = ftell(f);
		classpath_jar = jvm_alloc(file_size);
		if ( classpath_jar ) {
			int read;
			fseek(f, 0, SEEK_SET);
			read = fread(classpath_jar, 1, file_size, f);
			if ( file_size == read ) {
				system_classpath_zip = zip_process((unsigned char *)classpath_jar, file_size);
				if ( !system_classpath_zip )
					printf("Cannot process the classpath archive\n");
			} else
				printf("Error reading classpath file. %d bytes read, while %d bytes requested\n", read, (int)file_size);
		} else
			printf("Not enough memory to load classpath archive\n");
		fclose(f);
	}
}

/* ------------------------------------------------------ */

void *load_class ( const char *class_name ) {
    int len;
	char path[1024];
    void *data = NULL;

	ASSERT(class_name);
	
    path[0] = '\0';
	if ( system_classpath_zip ) {
		/* Loading class from jar archive */
		strcat(path, class_name);
		strcat(path, ".class");
		data = zip_find_entry(path, system_classpath_zip, &len);
	} else {
		strcat(path, classpath);
		strcat(path, "/");
		strcat(path, class_name);
		strcat(path, ".class");
	}

	/* Loading class from file */
    if ( data == NULL ) {
        FILE *f;
		
		f = fopen(path, "rb");
		
		if ( f != NULL ) {
			size_t file_size;

			fseek(f, 0, SEEK_END);
            file_size = ftell(f);
            fseek(f, 0, SEEK_SET);
            data = (void *)jvm_alloc(file_size);
            if ( data )
                fread(data, 1, file_size, f);
            fclose(f);
        }
    }

    return data;
}

/* ------------------------------------------------------ */

void loader_release ( ) {
    if ( classpath_jar ) {
        jvm_free(classpath_jar);
        classpath_jar = NULL;
    }
}

/* ------------------------------------------------------ */
/* End of file */

