/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <stdio.h>

#include "assert.h"
#include "class.h"
#include "gc.h"
#include "heap.h"

heap_t *heap_create ( void *ptr, unsigned int size, unsigned int granularity ) {
	heap_t *heap = (heap_t*)ptr;
	heap_block_t *block = (heap_block_t*)(ptr + sizeof(heap_t));
	
	heap->first_block = block;
	heap->size = size;
	heap->granularity = granularity;
	heap->allocated = sizeof(heap_t) + sizeof(heap_block_t);
	heap->limit = size / 3;
	heap->id = 0;
	mutex_init(&heap->mutex);
	
	block->flags = 0; 	/* block is free */
	block->size = size - heap->allocated;
    block->refcount = 0;
	block->link = NULL;	/* This is the only one block */
	
	return heap;
}

/* ------------------------------------------------------ */

void *heap_alloc_first ( heap_t *heap, unsigned int size, unsigned int flags ) {		
	heap_block_t *block;
	heap_block_t *prev_block = NULL;

	if ( size == 0 )
		return NULL;
		
	if ( (heap->size - heap->allocated) < size )
		return NULL;
	
	if ( size % heap->granularity )
		size += heap->granularity - size % heap->granularity;

	/* looking for the first fit */
	block = heap->first_block;
	while ( block != NULL ) {
		if ( !(block->flags & HEAP_BLOCK_ALLOCATED) && (block->size >= size) ) {
			/* Allocating this block */
			if ( (unsigned int)(block->size - size) > (sizeof(heap_block_t) + heap->granularity) ) {
				/* Split the block */
				heap_block_t *next_block = (heap_block_t *)((unsigned int)(block) + sizeof(heap_block_t) + size);
				next_block->flags = 0;
				next_block->link = block->link;
				next_block->size = block->size - size - sizeof(heap_block_t);
				/* previous block should be linked here */
				if ( prev_block )
					prev_block->link = next_block;
				else
					heap->first_block = next_block;
				block->size = size;
				heap->allocated += sizeof(heap_block_t);
			} else {
				/* Take the whole block */
				if ( prev_block )
					prev_block->link = block->link;
				else
					heap->first_block = block->link;
			}
			block->flags = flags | HEAP_BLOCK_ALLOCATED;
			block->link = (heap_block_t*)((unsigned int)block + sizeof(heap_block_t));
            block->refcount = 0;
			heap->allocated += block->size;		
			return (void *)(block->link);
		}
		/* Moving to the next free memory block */
		prev_block = block;
		block = block->link;
	}
	return NULL;
}

/* ------------------------------------------------------ */

void *heap_alloc_best ( heap_t *heap, unsigned int size, unsigned int flags ) {
	heap_block_t *prev_block = NULL;
	heap_block_t *best_block;
	heap_block_t *best_prev_block;
	heap_block_t *block;

	if ( size == 0 )
		return NULL;
		
	if ( (heap->size - heap->allocated) < size )
		return NULL;
	
	if ( size % heap->granularity )
		size += heap->granularity - size % heap->granularity;
	
	/* Looking for the best fit */
	best_block = NULL;
	best_prev_block = NULL;
	block = heap->first_block;
	while ( block != NULL ) {
		if ( !(block->flags & HEAP_BLOCK_ALLOCATED) && (block->size >= size) ) {
			if ( !best_block ) {
				best_block = block;
				best_prev_block = prev_block;
			} else
				if ( block->size < best_block->size ) {
					best_block = block;
					best_prev_block = prev_block;
				}
		}
		prev_block = block;
		block = block->link;
	}
	if ( !best_block )
		return NULL;
		
	block = best_block;
	prev_block = best_prev_block;
	
	/* Allocating this block */
	if ( (unsigned int)(block->size - size) > (sizeof(heap_block_t) + heap->granularity) ) {
		/* Split the block */
		heap_block_t *next_block = (heap_block_t *)((unsigned int)(block) + sizeof(heap_block_t) + size);
		next_block->flags = 0;
		next_block->link = block->link;
		next_block->size = block->size - size - sizeof(heap_block_t);
		/* previous block should be linked here */
		if ( prev_block )
			prev_block->link = next_block;
		else
			heap->first_block = next_block;
		block->size = size;
		heap->allocated += sizeof(heap_block_t);
	} else {
		/* Take the whole block */
		if ( prev_block )
			prev_block->link = block->link;
		else
			heap->first_block = block->link;
	}
		
	block->flags = flags | HEAP_BLOCK_ALLOCATED;
	block->link = (heap_block_t*)((unsigned int)block + sizeof(heap_block_t));
    block->refcount = 0;
	heap->allocated += block->size;			
	return (void *)(block->link);
}

/* ------------------------------------------------------ */

void *heap_alloc ( heap_t *heap, unsigned int size, unsigned int flags ) {
	void *ptr = NULL;
	
	if ( !size )
		return NULL;
	
	if ( size > heap->size / 64 )
		ptr = heap_alloc_first(heap, size, flags);
	else 
		ptr = heap_alloc_best(heap, size, flags);
		
	if ( heap->allocated > heap->limit || !ptr ) {
		gc();
		heap->limit = heap->allocated * 3;
		ptr = heap_alloc_first(heap, size, flags);
	}

	return ptr;
}

/* ------------------------------------------------------ */

heap_block_t *heap_free_block ( heap_t *heap, heap_block_t *block ) {
	block->flags = 0;	/* This block is free now */

	if ( ((unsigned int)(heap->first_block) > (unsigned int)block) || (heap->first_block == NULL) ) {
		/* Make this block the first in the list */
		block->link = heap->first_block;
		heap->first_block = block;
		heap->allocated -= block->size;
	} else {
		heap_block_t *prev_block = heap->first_block;
		while ( (prev_block->link != NULL) && ((unsigned int)(prev_block->link) < (unsigned int)block) )
			prev_block = prev_block->link;
		if ( prev_block->link == NULL ) {
			/* This is a very last block */
			block->link = NULL;
		} else {
			block->link = prev_block->link;
		}
		prev_block->link = block;
		heap->allocated -= block->size;

		/* Check merge up */
		if ( ((unsigned int)prev_block + sizeof(heap_block_t) + prev_block->size) == (unsigned int)block ) {
			prev_block->link = block->link;
			prev_block->size += block->size + sizeof(heap_block_t);
			block=prev_block;
			heap->allocated -= sizeof(heap_block_t);
		}
	}
	
	/* Check merge down */
	if ( ((unsigned int)block + block->size + sizeof(heap_block_t)) == (unsigned int)(block->link) ) {
		block->size += sizeof(heap_block_t) + block->link->size;
		block->link = block->link->link;
		heap->allocated -= sizeof(heap_block_t);
	}
		
	return block;
}

/* ------------------------------------------------------ */

void heap_free ( heap_t *heap, void *ptr ) {
	heap_block_t *block = (heap_block_t*)((unsigned int)ptr - sizeof(heap_block_t));
	if ( !ptr ) {
		DEBUG("NULL free");
		return;
	}
	
	if ( block->link != ptr ) {	/* This is not a valid pointer */
		DEBUG("heap free corruption");
		return;
	}

	block->flags = 0;	/* This block is free now */

	heap_free_block(heap, block);
}

/* ------------------------------------------------------ */

void heap_mark ( heap_t *heap, unsigned int from_flag, unsigned int to_flag, unsigned int except_flag ) {
	heap_block_t *block;
	unsigned int limit;

	ASSERT(heap);
	limit = ((unsigned int)(heap) + heap->size);
	block = (heap_block_t *)((unsigned int)(heap) + sizeof(heap_t));
	while ( (unsigned int)(block) < limit ) {
		if ( (block->flags & HEAP_BLOCK_ALLOCATED) && 
			 (!(block->flags & except_flag)) &&
			 (block->flags & from_flag)
		) {
			block->flags &= ~from_flag;
			block->flags |= to_flag;
		}
		block = (heap_block_t *)((unsigned int)(block) + block->size + sizeof(heap_block_t));
	}
}

/* ------------------------------------------------------ */

void heap_mark_id ( heap_t *heap, unsigned int id, unsigned int from_flag, unsigned int to_flag, unsigned int except_flag ) {
	heap_block_t *block;
	unsigned int limit;

	ASSERT(heap);
	limit = ((unsigned int)(heap) + heap->size);
	block = (heap_block_t *)((unsigned int)(heap) + sizeof(heap_t));
	while ( (unsigned int)(block) < limit ) {
		if ( (block->flags & HEAP_BLOCK_ALLOCATED) && 
			 (!(block->flags & except_flag)) &&
			 (block->flags & from_flag)
		)
			if ( (block->flags & HEAP_ID_MASK) == (id & HEAP_ID_MASK) ) {
				block->flags &= ~from_flag;
				block->flags |= to_flag;
			}
		block = (heap_block_t *)((unsigned int)(block) + block->size + sizeof(heap_block_t));
	}
}

/* ------------------------------------------------------ */

void heap_mark_block ( heap_t *heap, void *ptr, unsigned int from_flag, unsigned int to_flag, unsigned int except_flag ) {
	heap_block_t *block;

	ASSERT(heap);
	if ( ptr == NULL )
		return;
	block = (heap_block_t*)((unsigned int)ptr - sizeof(heap_block_t));
	if ( block->link != ptr ) {	/* This is not a valid pointer */
		DEBUG("Memory was not allocated within this heap");
		return;
	}

	if ( (block->flags & HEAP_BLOCK_ALLOCATED) && 
		 (!(block->flags & except_flag)) &&
		 (block->flags & from_flag)
	) {
		block->flags &= ~from_flag;
		block->flags |= to_flag;
	}	
}

/* ------------------------------------------------------ */

unsigned int heap_new_id ( heap_t *heap ) {
	unsigned int id;
	ASSERT(heap != NULL);
	heap_lock(heap);
	id = heap->id++;
	heap_unlock(heap);
	return id & HEAP_ID_MASK;
}

/* ------------------------------------------------------ */

void heap_release ( heap_t *heap, unsigned int flag ) {
	heap_block_t *block;

	ASSERT(heap);
	block = (heap_block_t *)((unsigned int)(heap) + sizeof(heap_t));
	while ( (unsigned int)(block) < ((unsigned int)(heap) + heap->size) ) {
		if ( (block->flags & HEAP_BLOCK_ALLOCATED) && (block->flags & flag) ) {
			block = heap_free_block(heap, block);
		}
		block = (heap_block_t *)((unsigned int)(block) + block->size + sizeof(heap_block_t));
	}
}

/* ------------------------------------------------------ */

void heap_lock ( heap_t *heap ) {
	mutex_lock(&heap->mutex);
}

/* ------------------------------------------------------ */

void heap_unlock ( heap_t *heap ) {
	mutex_unlock(&heap->mutex);
}

/* ------------------------------------------------------ */

heap_block_t *heap_find ( heap_t *heap, void *data ) {
	heap_block_t *block = NULL;
	
	ASSERT(heap);
	if ( !data )
		return NULL;
	if ( (unsigned)data < (unsigned)heap + sizeof(heap_t) + sizeof(heap_block_t) )
		return NULL;
	if ( (unsigned)data >= (unsigned)heap + heap->size )
		return NULL;
	block = (heap_block_t *)((unsigned)data - sizeof(heap_block_t));
	if ( !(block->flags & HEAP_BLOCK_ALLOCATED) )
		return NULL;
	if ( block->link != data )
		return NULL;
	
	return block;
}

/* ------------------------------------------------------ */

void heap_dump ( heap_t *heap ) {
	heap_block_t *block;
	int i = 0;
	int j;
	char *c_ptr;
	unsigned int max_free = 0;
	unsigned int allocated = sizeof(heap_t);
	
	printf("\nheap=0x%08X\tallocated %d bytes\tfirst free block=0x%08X", heap, heap->allocated, heap->first_block);
	block = (heap_block_t *)((unsigned int)(heap) + sizeof(heap_t));
	while ( (unsigned int)(block) < ((unsigned int)(heap) + heap->size) ) {
		printf("%d:\t0x%08X\t%s\t0x%08X\t%d bytes", ++i, block, (block->flags & HEAP_BLOCK_ALLOCATED)?"ALLOCATED":"  FREE  ", block->flags, block->size);

		if ( block->flags & HEAP_BLOCK_ALLOCATED ) {
			printf("\t%08X\t", block->link);
			c_ptr = (char*)block->link;
			for ( j = 0; j < block->size; j++ ) {
				printf("%c", *c_ptr);
				c_ptr++;
			}
		}
		printf("\n");

		allocated += sizeof(heap_block_t);
		if ( block->flags & HEAP_BLOCK_ALLOCATED ) {
			printf("\n");
			allocated += block->size;
		} else {
			if ( block->size > max_free )
				max_free = block->size;
			if ( block->link )
				printf("\t--> 0x%08X\n", block->link);
			else
				printf("\t--|\n");
		}
		block = (heap_block_t *)((unsigned int)(block) + block->size + sizeof(heap_block_t));
	}
	printf("Free memory: %d bytes of %d (allocated %d)\nMaximal continious region: %d bytes\n",
		heap->size - heap->allocated, heap->size, heap->allocated, max_free);
		
	printf("Allocated = %d, error = %d\n", allocated, heap->allocated - allocated);
}

/* ------------------------------------------------------ */

int heap_is_allocated ( heap_t *heap, void *ptr ) {
	heap_block_t *block;
	
	ASSERT(heap);
	
	if ( !ptr )
		return 0;
	
	if ( (int)ptr < (int)heap + sizeof(heap_block_t) )
		return 0;
		
	if ( (int)ptr > (int)heap + heap->size )
		return 0;
	
	block = (heap_block_t *)((unsigned int)ptr - sizeof(heap_block_t));
	if ( block->link != ptr )
		return 0;
		
	return 1;
}

/* ------------------------------------------------------ */
/* End of file */

