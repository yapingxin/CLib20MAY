/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_UTF8_H__
#define __JVM_UTF8_H__

/**
 * @file utf8.h
 *
 * Handling UTF8 srings
 */

#include "hash.h"

/**
 * Return number of characters in the UTF8 string
 *
 * @param utf8 Pointer to UTF8 string
 * @return Number of characters
 */
unsigned int utf8_length ( char *utf8 );

/**
 * Calclate hash code of a UTF8 string
 *
 * @param utf8 Pointer to UTF8 string
 * @return Hash code
 */
hash_t utf8_hash ( char *utf8 );

/**
 * Convert UTF8 string to array of unsigned short values
 *
 * @param utf8 Pointer to UTF8 string
 * @param buff Pointer to unsigned short array
 */
void utf8_convert ( char *utf8, unsigned short *buff );

/**
 * Compare two UTF8 strings
 *
 * @param str1 UTF8 string
 * @param str2 UTF8 string
 * @return TRUE if strings are identical, FALSE if not
 */
bool_t utf8_compare ( char *str1, char *str2 );

/**
 * Add a UTF8 string to a hash table.
 * The string will not be added if element with the same
 * hash code is already in the table.
 * This function will return a string from a hash table if
 * it is already there or add and return a new one.
 *
 * @param hash_table Pointer to a hash table
 * @param utf8 Pointer to UTF8 string
 * @return String from the hash table
 */
char *utf8_hash_table_find_or_add ( hash_table_t *hash_table, char *utf8 );

#endif /* __JVM_UTF8_H__ */

/* End of file */

