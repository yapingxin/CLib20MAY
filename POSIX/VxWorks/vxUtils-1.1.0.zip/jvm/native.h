/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_NATIVE_H__
#define __JVM_NATIVE_H__

#include "types.h"
#include "hash.h"

/**
 * Native method function
 */
typedef void(*native_func_t)();

/**
 * Table of native methods
 */
typedef struct native_s native_t;
struct native_s {
    hash_t  hash_class;
    hash_t  hash_method;
    native_func_t native;
};

/**
 * Resolving native method function
 *
 * @param hashc Calss hash code
 * @param hashm Method hash code
 * @return Native function or NULL if cannot be resolved
 */
native_func_t native_resolve ( hash_t hashc, hash_t hashm );

#endif /* __JVM_NATIVE_H__ */
