/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <stdio.h>

#include "assert.h"
#include "types.h"
#include "hash.h"
#include "utf8.h"

/**
 * Fetch UTF8 character and convert it into 2-bytes value
 */
#define UTF8_GET_CHAR(ptr,c)    {                                       \
    int x = *ptr++;                                                     \
    if ( x & 0x80 ) {                                                   \
        int y = *ptr++;                                                 \
        if ( y & 0x20 ) {                                               \
            int z = *ptr++;                                             \
            c = ((x & 0x0F) << 12) + ((y & 0x3F) << 16) + (z & 0x3F);   \
        } else                                                          \
            c = ((x & 0x1F) << 6) + (y & 0x3F);                         \
    } else                                                              \
        c = x;                                                          \
}

/* ------------------------------------------------------ */

unsigned int utf8_length ( char *utf8 ) {
    unsigned int count;
    for ( count = 0; *utf8; count++ ) {
        int x = *utf8;
        utf8 += (x & 0x80) ? ((x & 0x20) ? 3 : 2) : 1;
    }
    return count;
}

/* ------------------------------------------------------ */

hash_t utf8_hash ( char *utf8 ) {
    hash_t hash = 0;
    while ( *utf8 ) {
        unsigned short c;
        UTF8_GET_CHAR(utf8, c);
        hash = hash * 37 + c;
    }
    return hash;
}

/* ------------------------------------------------------ */

void utf8_convert ( char *utf8, unsigned short *buff ) {
    while ( *utf8 )
        UTF8_GET_CHAR(utf8, *buff++);
}

/* ------------------------------------------------------ */

bool_t utf8_compare ( char *str1, char *str2 ) {
    while ( *str1 && *str2 ) {
        unsigned short c1, c2;
        UTF8_GET_CHAR(str1, c1);
        UTF8_GET_CHAR(str2, c2);
        if ( c1 != c2 )
            return FALSE;
    }
    /* Check the length */
    if ( *str1 || *str2 )
        return FALSE;

    return TRUE;
}

/* ------------------------------------------------------ */

char *utf8_hash_table_find_or_add ( hash_table_t *hash_table, char *utf8 ) {
    hash_t hash;
    hash_entry_t *hash_entry;

    ASSERT(hash_table != NULL);

    hash = utf8_hash(utf8);
    hash_table_lock(hash_table);
    hash_entry = hash_table_find_or_add(hash_table, hash, utf8);
    hash_table_unlock(hash_table);
    return (char*)hash_entry->data;
}

/* ------------------------------------------------------ */
/* End of file */

