/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdio.h>
#include <stdlib.h>

#include "assert.h"
#include "types.h"
#include "alloc.h"
#include "utf8.h"
#include "class.h"
#include "heap.h"
#include "class.h"
#include "method.h"
#include "loader.h"
#include "exec.h"
#include "thread.h"
#include "gc.h"

/* ------------------------------------------------------ */

void jvm_start ( ) {
	class_t *bootstrap;
	heap_t *heap;

	/* Initialize system memory allocator
	 */
	jvm_alloc_init();

	/* We pass the stack and heap sized here.
	 * The heap will be shared among all the child threads.
	 * However, the stack will be recreated (of the same size)
	 * for each new thread
	 */
	java_thread_init(64 * 1024, 32 * 1024);

    /* JIT compiler initialization. We have to do this _after_ java_thread_init()
     * in order to have an execution environment ready.
     */
    jit_opcode_init();
    
	/* Here we can specify either a jar archive or
	 * a folder with java classes like
 	 * loader_init("classpath/done");
	 */
	loader_init("classpath.jar");
	/* loader_init("./classpath/done"); */

	/* Application entry point is in sys/entry/Entry
	 * class, methos entry(). This method should be static.
	 */
	bootstrap = class_resolve("sys/entry/Entry");

	if ( bootstrap ) {
		method_t *entry = method_resolve(bootstrap, utf8_hash("entry") ^ utf8_hash("()V"));

		if ( entry ) {
			if ( entry->access_flags & ACC_STATIC ) {
				long long start_time = getTimeInMs();
				long long finish_time;
				method_invoke(bootstrap, NULL, entry);
				finish_time = getTimeInMs();
				printf("Program run: %d ms\n", finish_time - start_time);

				/* Normally, the application ends here and so do
				 * all created threads. In the embedded environment, however,
				 * the java threads may continue to run. So, we do not
				 * release the allocated resources here.
				 * It is recommended that java embedded application is
				 * designed in such way, that method entry() never
				 * returns.
				 */
			} else {
				PANIC("Method sys/entry/Entry.entry() must be static\n");
			}
		} else {
			PANIC("Method sys/entry/Entry.entry() was not found\n");
		}
	} else {
		PANIC("sys/entry/Entry class cannot be resolved\n");
	}

	/* Release all memory that was allocated.
	 * Once it is done, no pointer is valid in the JVM.
	 * Application must be terminated.
	 */
	jvm_memory_cleanup();
}

/* ------------------------------------------------------ */

#ifndef VXWORKS
int main ( int argc, char **argv ) {

	jvm_start();
	
    return 0;
}
#endif

/* ------------------------------------------------------ */
/* End of file */

