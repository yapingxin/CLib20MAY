/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "assert.h"
#include "alloc.h"
#include "sync.h"

#include "hash.h"

/**
 * @file hash.c
 *
 * Hash tables implementation
 */

hash_table_t *hash_table_create ( size_t initial_size ) {
    hash_table_t *hash_table;

    ASSERT(initial_size > 0);

    /* Allocate memory for table itself */
    hash_table = (hash_table_t *)jvm_alloc(sizeof(hash_table_t));
    if ( NULL == hash_table )
        return NULL;

    /* Allocate memory for entries */
    hash_table->entries = (hash_entry_t *)jvm_alloc(sizeof(hash_entry_t) * initial_size);
    if ( NULL == hash_table->entries ) {
        jvm_free(hash_table);
        return NULL;
    }

    hash_table->count = 0;  /* The table is initialy empty */
    hash_table->size = initial_size;

    /* Initialize mutex */
    mutex_init(&hash_table->mutex);

    return hash_table;
}

/* ------------------------------------------------------ */

void hash_table_release ( hash_table_t *hash_table ) {
    ASSERT(hash_table != NULL);
    ASSERT(hash_table->entries != NULL);
    jvm_free(hash_table->entries);
    mutex_release(&hash_table->mutex);
    jvm_free(hash_table);
}

/* ------------------------------------------------------ */

void hash_table_lock ( hash_table_t *hash_table ) {
    ASSERT(hash_table != NULL);
    mutex_lock(&hash_table->mutex);
}

/* ------------------------------------------------------ */

void hash_table_unlock ( hash_table_t *hash_table ) {
    ASSERT(hash_table != NULL);
    mutex_unlock(&hash_table->mutex);
}

/* ------------------------------------------------------ */

hash_entry_t *hash_table_find ( hash_table_t *hash_table, hash_t hash ) {
    unsigned int i;

    ASSERT(hash_table != NULL);
    ASSERT(hash_table->entries != NULL);

    for ( i = 0; i < hash_table->count; i++ ) {
        if ( hash_table->entries[i].hash == hash ) {
            return &hash_table->entries[i];
        }
    }

    return NULL; /* Nothing was found */
}

/* ------------------------------------------------------ */

void hash_table_resize ( hash_table_t *hash_table, size_t new_size ) {
    hash_entry_t *new_entries;
    hash_entry_t *old_entries;

    ASSERT(hash_table != NULL);
    ASSERT(hash_table->size < new_size);
    /* Allocate memory for new entries */
    new_entries = (hash_entry_t *)jvm_alloc(sizeof(hash_entry_t) * new_size);
    ASSERT(new_entries != NULL);
    old_entries = hash_table->entries;

    /* Copy previous entries */
    memcpy((void *)new_entries, (void *)old_entries, sizeof(hash_entry_t) * hash_table->size);
    hash_table->entries = new_entries;
    hash_table->size = new_size;

    /* Release memory from previous entries */
    jvm_free(old_entries);
}

/* ------------------------------------------------------ */

hash_entry_t *hash_table_find_or_add ( hash_table_t *hash_table, hash_t hash, void *data ) {
    unsigned int i;
    hash_entry_t *hash_entry;

    ASSERT(hash_table != NULL);
    ASSERT(data != NULL);

    hash_entry = hash_table_find(hash_table, hash);
    if ( NULL != hash_entry )
        return hash_entry; /* This entry is already in the table */

    /* Find an empty entry */
    for ( i = 0; i < hash_table->count; i++ ) {
        if ( NULL == hash_table->entries[i].data ) {
            hash_entry = &hash_table->entries[i];
            hash_entry->hash = hash;
            hash_entry->data = data;
            return hash_entry;
        }
    }

    if ( hash_table->count == hash_table->size ) {
        /* Double a size of a hash table */
        hash_table_resize(hash_table, hash_table->size * 2);
    }

    hash_entry = &hash_table->entries[hash_table->count];
    hash_entry->hash = hash;
    hash_entry->data = data;
    hash_table->count++;

    return hash_entry;
}

/* ------------------------------------------------------ */

void hash_table_delete ( hash_table_t *hash_table, hash_t hash ) {
    unsigned int i;

    ASSERT(hash_table != NULL);

    for ( i = 0; i < hash_table->count; i++ ) {
        if ( hash_table->entries[i].hash == hash ) {
            hash_table->entries[i].hash = 0;
            hash_table->entries[i].data = NULL;
            hash_table->count--;
            return;
        }
    }
}

/* ------------------------------------------------------ */
/* End of file */

