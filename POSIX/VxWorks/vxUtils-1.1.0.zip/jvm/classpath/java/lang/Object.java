/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */

package java.lang;

/**
 * The topmost class of all Java classes and objects.
 * @author Arthur Benilov
 * This implementation is not full and is a subject of revision.
 */
public class Object {
	
	/**
	 * Default constructor.
	 */
	public Object() {
	}
	
	/**
	 * @param obj The object to be tested.
	 * @return true for equal objects
	 */
	public boolean equals(Object obj) {
		return this == obj;
	}
	
	/**
	 * Calculate the hash code for this object.
	 * @return Hash code
	 */
	public int hashCode() {
		return System.identifyHashCode(this);
	}
	
	/**
	 * Any object should know how to be represented by string
	 * @return String representation of the object
	 */
	public String toString() {
		return new String("");
	}
	
	/**
	 * Clone this object
	 * @return A new reference to the object of the same class
	 */
	public final native Object clone();
	
	/**
	 * Waits to be notified by another thread of a change in this object.
	 * @param timeout The maximum time to wait in milliseconds
	 */
	/// TODO: move to long values (instead of int)
	public final native void wait(int timeout) throws InterruptedException;
	
	/**
	 * Wakes up a single thread that is waiting on this object's monitor
	 */
	public final native void notify();
	
	/**
	 * Wakes up all threads that are waiting for this object.
	 */
	public final native void notifyAll();
	
	/**
	 * Returns class object that corresponds to this object
	 */
	public final native Class getClass();
	
}
