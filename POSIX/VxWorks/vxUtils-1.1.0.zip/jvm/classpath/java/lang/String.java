/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */

package java.lang;

/**
 * Java String implementation
 * 
 * @author Arthur Benilov
 */
public class String {

	/**
	 * Array of characters wich make up the string.
	 * value.length gives the length of a string
	 */
	public char[] value;
	
	/**
	 * Default constructor creates an empty string
	 */
	public String() {
		value = new char[0];
	}

	/**
	 * Constructor duplicates string value passed
	 * @param str String object to be copied in this new object
	 */
	public String(String str) {
		value = new char[str.length()];
		System.arraycopy(str.value, 0, value, 0, value.length);
	}
	
	/**
	 * Create a new string using an array of characters
	 */
	
	/**
	 * Constructor of a String from array of characters
	 * @param data array of characters that will be copied to this new String object
	 */
	public String(char[] data) {
		value = new char[data.length];
		System.arraycopy(data, 0, value, 0, data.length);
	}

	/**
	 * Return the length of this string
	 * @return number of characters in the string
	 */
	public int length() {
		return value.length;
	}
	
	/**
	 * Converts an array of characters to the string object
	 * @param data array of characters to be copied in the new string
	 * @return String object constructed
	 */
	public static String valueOf(char data[]) {
		return new String(data);
	}
	
	/**
	 * Compares this string with another one by characters
	 * @param obj another string to compare
	 * @return true is strings are identical
	 */
	public boolean equals(Object obj) {
		if ((obj != null) && (obj instanceof String)) {
			String str = (String)obj;
			int n = value.length;
			if (n == str.length()) {
				while(n > 0) {
					if (value[n] != str.value[n])
						return false;
				}
				return true;
			}
			
		}
		return false;
	}
	
}