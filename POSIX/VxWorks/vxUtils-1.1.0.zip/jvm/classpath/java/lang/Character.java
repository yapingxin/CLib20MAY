/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */

package java.lang;

/**
 * @author Arthur Benilov
 * 
 * Class wrapper for the Java character base type.
 * This implementation is not full and is a subject of revision.
 */
public final class Character {
	
	public static final int MIN_RADIX = 2;
	public static final int MAX_RADIX = 36;
	public static final char MIN_VALUE = '\u0000';
	public static final char MAX_VALUE = '\uFFFF';
	public static final byte
		UNASSIGNED				= 0,
		UPPERCASE_LETTER		= 1,
		LOWERCASE_LETTER		= 2,
		TITLECASE_LETTER		= 3,
		MODIFIER_LETTER			= 4;
	
	/**
	 * Character (char) value stored in the Character object
	 */
	private char value;
	
	/**
	 * Constructor
	 * @param value	Character value to be stored in the Character object
	 */
	public Character(char value) {
		this.value = value;
	}
	
	/**
	 * @return char value stored in the Character object
	 */
	public char charValue() {
		return this.value;
	}
	
	/**
	 * @return hash code of the character
	 * Currently, the hash code is just a character value.
	 */
	public int hashCode() {
		return (int)value;
	}
	
	/**
	 * @param obj 
	 * @return true if objects are equal, else returns false
	 */
	public boolean equals(Object obj) {
		if ((obj != null) && (obj instanceof Character)) {
			return value == ((Character)obj).charValue();
		}
		return false;
	}
	
	/**
	 * @return String representation of the character
	 */
	public String toString() {
		char buf[] = {value};
		return String.valueOf(buf);
	}
	
	/**
	 * Converts the digit to the corresponding character using
	 * the particular number system.
	 * @param digit The digit to be converted
	 * @param radix The number system basis
	 * @return the character for the digit passed
	 */
	public static char forDigit(int digit, int radix) {
		if ((digit >= radix) || (digit < 0))
			return '\0';
		if ((radix < MIN_RADIX) || (radix > MAX_RADIX))
			return '\0';
		if (digit < 10)
			return (char)('0' + digit);
		return (char)('a' - 10 + digit);
	}
	
}