/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */

package java.lang;

/**
 * Native calls to the host system of kernel
 * 
 * @author Arthur Benilov
 *
 */
public class System {

	/**
	 * Default constructor
	 */
	private System() {
	}
	
	/**
	 * Copy an array part to another one
	 * @param src Array object to be copied
	 * @param srcStart Element index from which this array will be copied
	 * @param dest Destination array
	 * @param destStart Element in the destination array starting of which the data will be copied
	 * @param len Number of elements to be copied
	 */
	public static native void arraycopy(Object src, int srcStart, Object dest, int destStart, int len);
	
	/**
	 * Run garbage collection forcedly.
	 * However this call does not garantee that garbage will be
	 * actually collected. If the heap is locked by some other thread
	 * this method will just return with nothing done.
	 * 
	 * This trick allows avoiding of blocking calls to the kernel (e.g. while it is
	 * waiting for the heap release or whatever).
	 */
	public static native void gc();
	
	/**
	 * Return a hash code for some object
	 * @param o Object
	 * @return Hash code of the object passed
	 */
	public static native int identifyHashCode(Object o);

}
