/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */

package java.lang;

import sys.console.*;

/**
 * StringBuilder class is used indirectly by Java comiler to
 * provide basic string operations (concatinations with other objects).
 * 
 * This class is the analog of StringBuilder class.
 * 
 * @author Archie
 */
public class StringBuilder {

	/**
	 * Internal buffer for character chains manipulations
	 */
	private char value[];
	
	/**
	 * Number of characters already placed in value[] buffer
	 */
	private int count;

	/**
	 * Default constructor.
	 * Allocates buffer value for 16 characters.
	 */
	public StringBuilder() {
		this(16);
	}

	/**
	 * Constructor that allocates the internal buffer to hold
	 * the specified number of characters.
	 * @param length Numer of characters in the internal buffer
	 */
	public StringBuilder(int length) {
		value = new char[length];
	}

	/**
	 * Constructor that allocates internal buffer from a string value.
	 * The buffer length is allocated to be a little bigger that the length
	 * of the string passed.
	 * 
	 * @param str String value to be copied into the internal buffer
	 */
	public StringBuilder(String str) {
		this(str.length() + 16);
		append(str);
	}

	/**
	 * Construct the class using the array of characters
	 * 
	 * @param data The array of characters to be copied into the internal buffer
	 */
	public StringBuilder(char data[]) {
		value = new char[data.length];
		count = data.length;
		System.arraycopy(data, 0, value, 0, count);
	}

	/**
	 * Return the number of characters in the internal buffer
	 * @return Number of characters in the buffer
	 */
	public int length() {
		return count;
	}

	/**
	 * Converts this object to String
	 * @return String representation of the internal buffer of characters
	 */
	public String toString() {
		char tmp[] = new char[count];
		System.arraycopy(value, 0, tmp, 0, count);
		return new String(tmp);
	}

	/**
	 * Return the number of characters that can be stored in the internal
	 * buffer without reallocation.
	 * 
	 * @return Maximal number of characters that can be stored in the buffer
	 */
	public int capacity() {
		return value.length;
	}

	/**
	 * Check the capacity of the internal buffer and reallocate it
	 * to hold the required number of characters
	 * 
	 * @param minimumCapacity Maximal number of characters that the buffer should be
	 * capable to store
	 */
	public synchronized void ensureCapacity(int minimumCapacity) {
		int currentCapacity = value.length;

		if ( minimumCapacity > currentCapacity ) {
			int newCapacity = minimumCapacity;
			char newValue[] = new char[newCapacity];
			System.arraycopy(value, 0, newValue, 0, count);
			value = newValue;
		}
	}

	/**
	 * Append array of characters to the internal buffer
	 * 
	 * @param str array of characters
	 * @param offset offset in the array of characters
	 * @param len number of characters (starting from the offset) that should
	 * be copied to the internal buffer
	 * @return New StringBuilder object holding the required part of array
	 */
	public synchronized StringBuilder append(char str[], int offset, int len) {
		ensureCapacity(count + len);
		System.arraycopy(str, offset, value, count, len);
		count += len;
		return this;
	}

	/**
	 * Append a string to this buffer
	 * 
	 * @param str String object to append
	 * @return New StringBuilder object with the string appended
	 */
	public StringBuilder append(String str) {
		return append(str.value, 0, str.length());
	}

	/**
	 * Append and object to the buffer. Object will be converted to
	 * a string by toString() method call.
	 * @param obj object to append
	 * @return new StringBuilder object
	 */
	public StringBuilder append(Object obj) {
		return append(obj.toString());
	}
	
	/**
	 * Append a single character to the buffer
	 * 
	 * @param chr Character to append
	 * @return New StringBuilder objecy with the character appended
	 */
	public StringBuilder append(char chr) {
		char arr[] = { chr };
		return append(arr, 0, 1);
	}

	/**
	 * Append an integer value to the buffer.
	 * The integer is converted to string using the decimal notation.
	 * 
	 * @param i int value to be appended
	 * @return new StringBuilder with integer value appended
	 */
	public StringBuilder append(int i) {
		String istr = Integer.toString(i);
		return append(istr);
	}

	/**
	 * Append a long value to the buffer
	 * The long number is converted to string using the decimal notation.
	 * 
	 * @param i long value to be appended
	 * @return new StringBuilder object with the value appended
	 */
	public StringBuilder append(long i) {
		String istr = Long.toString(i);
		return append(istr);
	}
	
	/**
	 * Reverse the characters order in the internal buffer
	 * @return the new StringBuilder object with characters order reversed
	 */
	public StringBuilder reverse() {
		char rvalue[] = new char[count];
		for ( int i = 0; i < count; i++ )
			rvalue[i] = value[count-i-1];
		return new StringBuilder(rvalue);
	}
}
