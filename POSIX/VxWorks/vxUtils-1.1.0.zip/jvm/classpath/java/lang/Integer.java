/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */

package java.lang;

/**
 * This is a class wrapper for Java integers. This class is final,
 * so, can not be inherited.
 * 
 * @author Arthur Benilov
 */
public final class Integer extends Number {
	
	/**
	 * The most negative and most positive values
	 */
	public static final int MIN_VALUE = 0x80000000;
	public static final int MAX_VALUE = 0x7FFFFFFF;
	
	/**
	 * Low level representation of integer value
	 */
	private int value;
	
	/**
	 * Convert some integer number to the string using specific
	 * number system.
	 * @param i Integer value to be converted
	 * @param radix The base of number system
	 * @return String representation of integer value
	 */
	public static String toString(int i, int radix) {
		if (radix < Character.MIN_RADIX || radix > Character.MAX_RADIX)
			radix = 10;
		StringBuilder buf = new StringBuilder(radix >= 8 ? 12 : 33);
		boolean negative = (i < 0);
		if (!negative)
			i = -i;
		while (i <= -radix ) {
			buf.append(Character.forDigit(-(i % radix), radix));
			i = i / radix;
		}
		buf.append(Character.forDigit(-i, radix));
		if (negative)
			buf.append('-');
		return buf.reverse().toString();
	}

	/**
	 * Convert integer value to the string using decimal notation
	 * @param i Integer value to be converted
	 * @return String representation of the integer value
	 */
	public static String toString(int i) {
		return toString(i, 10);
	}

	/**
	 * Convert this Integer object to double value
	 * @return fouble value corresponding to this integer
	 */
	public double doubleValue() {
		return (double)value;
	}
	
	/**
	 * Convert this Integer object to float value
	 * @return float value corresponding to this integer
	 */
	public float floatValue() {
		return (float)value;
	}
	
	/**
	 * Convert this Integer object to long value
	 * @return long value corresponding to this integer
	 */
	public long longValue() {
		return (long)value;
	}
	
	/**
	 * Return int value of this object
	 * @return integer representation of this Integer object
	 */
	public int intValue() {
		return value;
	}
}