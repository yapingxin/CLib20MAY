/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */

package java.lang;

public class Long extends Number {

	public static final long MIN_VALUE = 0x8000000000000000L;
	public static final long MAX_VALUE = 0x7FFFFFFFFFFFFFFFL;
	
	private long value;
	
	public Long() {
		value = 0;
	}
	
	public Long(long v) {
		value = v;
	}
	
	public static String toString(long i, int radix) {
		if (radix < Character.MIN_RADIX || radix > Character.MAX_RADIX)
			radix = 10;
		StringBuilder buf = new StringBuilder(radix >= 8 ? 23 : 65);
		boolean negative = (i < 0);
		if (!negative)
			i = -i;
		while (i <= -radix) {
			buf.append(Character.forDigit((int)(-(i % radix)), radix));
			i = i / radix;
		}
		buf.append(Character.forDigit((int)(-i), radix));
		if (negative)
			buf.append('-');
		return buf.reverse().toString();
	}
	
	public static String toHexString(long i) {
		return toUnsignedString(i, 4);
	}
	
	public static String toOctalString(long i) {
		return toUnsignedString(i, 3);
	}
	
	public static String toBinaryString(long i) {
		return toUnsignedString(i, 1);
	}
	
	public static String toUnsignedString(long i, int shift) {
		StringBuilder buf = new StringBuilder(shift >= 3 ? 22 : 64);
		int radix = 1 << shift;
		long mask = radix - 1;
		do {
			buf.append(Character.forDigit((int)(i & mask), radix));
			i >>>= shift;
		} while (i != 0);
		return buf.reverse().toString();
	}
	
	public static String toString(long i) {
		return toString(i, 10);
	}
	
	public double doubleValue() {
		return (double)value;
	}

	public float floatValue() {
		return (float)value;
	}

	public int intValue() {
		return (int)value;
	}

	public long longValue() {
		return value;
	}

}
