/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */

package java.lang;

/**
 * Java threads base class.
 * 
 * @author Arthur Benilov
 */
public class Thread implements Runnable {
	
	/**
	 * Thread priorities.
	 * Thread priority has different values for different host systems
	 */
	public final static int MIN_PRIORITY = 1;
	public final static int NORM_PRIORITY = 5;
	public final static int MAX_PRIORITY = 10;
	
	/**
	 * Returns the referrence to the currently executing Thread object
	 * 
	 * @return Current running thread
	 */
	public static native Thread currentThread();

	/**
	 * Switch to another thread
	 */
	public static native void yield();
	
	/**
	 * Make this thread to sleep for some time. This methos
	 * throws InterruptedException if been interrupted by some event.
	 * 
	 * @param millis Number of milliseconds to sleep
	 */
	public static native void sleep(int millis) throws InterruptedException;

	/**
	 * Interrupt the thread
	 * This method is not static!!!
	 */
	public native void interrupt();
	
	/**
	 * Default constructor
	 */
	public Thread() {
	}
	
	/**
	 * Starting this thread execution.
	 * Calling this method will create a new native thread corresponding
	 * to the Java thread. Parent thread will continue its execution after
	 * the call to this method is finished.
	 */
	public synchronized native void start();
	
	/**
	 * Actual thread routine.
	 * Exit from this method make the thread to terminate.
	 */
	public void run() {
	}
		
}