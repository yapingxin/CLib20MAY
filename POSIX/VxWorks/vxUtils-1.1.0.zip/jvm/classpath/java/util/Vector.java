/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */

package java.util;

/**
 * Vector is a growable array
 * 
 * @author Arthur Benilov
 *
 */
public class Vector {

	/**
	 * The buffer for elements starage
	 */
	protected Object elementData[];
	
	/**
	 * Number of elements in the buffer
	 */
	protected int elementCount;
	
	/**
	 * The size of the increment. If zero, the buffer length
	 * will be doubled everytime it needs to grow.
	 */
	protected int capacityIncrement;
	
	/**
	 * Constructs an empty vector
	 * @param initialCapacity the initial storage capacity
	 * @param capacityIncrement increase of the capacity
	 */
	public Vector(int initialCapacity, int capacityIncrement) {
		super();
		this.elementData = new Object[initialCapacity];
		this.capacityIncrement = capacityIncrement;
	}
	
	/**
	 * Constructs an empty vector with the specified storage capacity
	 * @param initialCapacity
	 */
	public Vector(int initialCapacity) {
		this(initialCapacity, 0);
	}
	
	/**
	 * Constructs an empty vector.
	 */
	public Vector() {
		this(10);
	}
	
	/**
	 * Copies the elements of this vector into the specified array
	 * @param anArray
	 */
	public final synchronized void copyInto(Object anArray[]) {
		System.arraycopy(elementData, 0, anArray, 0, elementCount);
		/*
		int i = elementCount;
		while (i-- > 0)
			anArray[i] = elementData[i];
		*/
	}

	/**
	 * Trims the vector's capacity down to size.
	 */
	public final synchronized void trimToSize() {
		int oldCapacity = elementData.length;
		if (elementCount < oldCapacity) {
			Object oldData[] = elementData;
			elementData = new Object[elementCount];
			System.arraycopy(oldData, 0, elementData, 0, elementCount);
		}
	}
	
	/**
	 * Ensures that the vector has at least the specified capacity
	 * @param minCapacity the desired minimum capacity
	 */
	public final synchronized void ensureCapacity(int minCapacity) {
		int oldCapacity = elementData.length;
		if (minCapacity > oldCapacity) {
			Object oldData[] = elementData;
			int newCapacity = (capacityIncrement > 0) ?
					(oldCapacity + capacityIncrement) : (oldCapacity * 2);
			if (newCapacity < minCapacity)
				newCapacity = minCapacity;
			elementData = new Object[newCapacity];
			System.arraycopy(oldData, 0, elementData, 0, elementCount);
		}
	}
	
	/**
	 * Set the size of the vector. If the size is smaller the number
	 * of elements, the extra elements will be lost. The new elements
	 * are set to null.
	 * @param newSize the new size of the vector
	 */
	public final synchronized void setSize(int newSize) {
		if (newSize > elementCount)
			ensureCapacity(newSize);
		else
			for (int i = newSize; i < elementCount; i++)
				elementData[i] = null;
		elementCount = newSize;
	}
	
	/**
	 * Returns the current capacity of the vector
	 * @return the current capacity
	 */
	public final int capacity() {
		return elementData.length;
	}
	
	/**
	 * Returns the number of elements in the vector
	 * @return the number of elements
	 */
	public final int size() {
		return elementCount;
	}
	
	/**
	 * Returns true if the vector is empty
	 * @return true for the empty vector
	 */
	public final boolean isEmpty() {
		return elementCount == 0;
	}

	/**
	 * Returns the enumeration of the vector's elements.
	 * @return the enumerator of the elements
	 */
	public final synchronized Enumeration elements() {
		return new VectorEnumerator(this);
	}
	
	/**
	 * Returns true if the specified object is a part of the vector
	 * @param elem the desired element
	 * @return true if element is in the vector
	 */
	public final boolean contains(Object elem) {
		return indexOf(elem, 0) >= 0;
	}
	
	/**
	 * Searches for the specified object in this vector
	 * @param elem object to find
	 * @return the index of the element, or -1 if not found
	 */
	public final int indexOf(Object elem) {
		return indexOf(elem, 0);
	}
	
	/**
	 * Searches for the specified object starting from the
	 * specified index.
	 * @param elem object to find
	 * @param index index to start from
	 * @return the index of the element, or -1 if not found
	 */
	public final synchronized int indexOf(Object elem, int index) {
		for (int i = index; i < elementCount; i++) {
			if (elem.equals(elementData[i]))
				return i;
		}
		return -1;
	}
	
	/**
	 * Searches backward for the specified object starting from the
	 * specified index
	 * @param elem object to find
	 * @param index index to start from
	 * @return the index of the element, or -1 if not found
	 */
	public final synchronized int lastIndexOf(Object elem, int index) {
		for (int i = index; i >= 0; i--) {
			if (elem.equals(elementData[i]))
				return i;
		}
		return -1;
	}
	
	/**
	 * Returns the element at the specified position.
	 * @param index position of the element
	 * @return the element
	 */
	public final synchronized Object elementAt(int index) {
		if (index >= elementCount)
			throw new ArrayIndexOutOfBoundsException(index + " >= " + elementCount);
		try {
			return elementData[index];
		} catch (ArrayIndexOutOfBoundsException e) {
			throw new ArrayIndexOutOfBoundsException(index + " < 0");
		}
	}
	
	/**
	 * Returns the first element of the vector
	 * @exception NoSuchElementException if the vector is empty
	 * @return the first element
	 */
	public final synchronized Object firstElement() {
		if (elementCount == 0)
			throw new NoSuchElementException();
		return elementData[0];
	}
	
	/**
	 * Returns the last element of the vector
	 * @exception NoSuchElementException if the vector is empty
	 * @return the last element
	 */
	public final synchronized Object lastElement() {
		if (elementCount == 0)
			throw new NoSuchElementException();
		return elementData[elementCount - 1];
	}
	
	/**
	 * Sets the elements at the specified position
	 * @param obj new value for the element
	 * @param index position index
	 * @exception ArrayIndexOutOfBounds if the index is invalid
	 */
	public final synchronized void setElementAt(Object obj, int index) {
		if (index >= elementCount)
			throw new ArrayIndexOutOfBoundsException(index + " >= " + elementCount);
		elementData[index] = obj;
	}
	
	/**
	 * Deletes element at the specified position
	 * @param index position index
	 * @exception ArrayIndexOutOfBoundsException if the index is invalid
	 */
	public final synchronized void removeElementAt(int index) {
		if (index >= elementCount)
			throw new ArrayIndexOutOfBoundsException(index + " >= " + elementCount);
		else if (index < 0)
			throw new ArrayIndexOutOfBoundsException(Integer.toString(index));
		int j = elementCount - index - 1;
		if (j > 0)
			System.arraycopy(elementData, index + 1, elementData, index, j);
		elementCount--;
		elementData[elementCount] = null; /* for GC to remove the deleted object */
	}
	
	/**
	 * Inserts the object to the specified position
	 * @param obj Object to insert
	 * @param index position index
	 * @exception ArrayIndexOutOfBoundsException is index is invalid
	 */
	public final synchronized void insertElementAt(Object obj, int index) {
		if (index >= elementCount + 1)
			throw new ArrayIndexOutOfBoundsException(index + " > " + elementCount);
		ensureCapacity(elementCount + 1);
		System.arraycopy(elementData, index, elementData, index + 1, elementCount - index);
		elementData[index] = obj;
		elementCount++;
	}
	
	/**
	 * Add the specified object to this vector
	 * @param obj Object reference to be added
	 */
	public final synchronized void addElement(Object obj) {
		ensureCapacity(elementCount + 1);
		elementData[elementCount++] = obj;
	}
	
	/**
	 * Remove the first occurence of the object from the vector
	 * @param obj Object to be removed
	 * @return true if object was removed, else false is returned
	 *  (specified object was not found in this vector)
	 */
	public final synchronized boolean removeElement(Object obj) {
		int i = indexOf(obj);
		if (i >= 0) {
			removeElementAt(i);
			return true;
		}
		return false;
	}
	
	/**
	 * Removes all elements of this vector
	 */
	public final synchronized void removeAllElements() {
		for (int i = 0; i < elementCount; i++)
			elementData[i] = null;
		elementCount = 0;
	}

	/**
	 * Converts this vector to a string by calling
	 * toString() method of all elements
	 */
	public final synchronized String toString() {
		int max = size() - 1;
		StringBuilder buf = new StringBuilder();
		Enumeration e = elements();
		buf.append("[");

		for (int i = 0; i <= max; i++) {
			String s = e.nextElement().toString();
			buf.append(s);
			if (i < max)
				buf.append(", ");
		}
		buf.append("]");
		return buf.toString();
	}
	
}
