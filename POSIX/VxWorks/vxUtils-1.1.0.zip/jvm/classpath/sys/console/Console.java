/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */
 
package sys.console;

/**
 * Very simple console implementation.
 * Currently this class is used for debug purposes only.
 * 
 * @author Arthur Benilov
 */ 
public class Console {
	
	/**
	 * Native method for string output
	 * @param str String to be prined in system console
	 */
	public static native synchronized void print(String str);
	
	/**
	 * Move the cursor to the new line
	 */
	public static native synchronized void newLine();
		
	/**
	 * Print a sting and move to the new line
	 * @param str String to be printed
	 */
	public static synchronized void println(String str) {
		print(str);
		newLine();
	}
	
}