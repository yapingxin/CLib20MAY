/**
 * Copyright (C) 2007, Arthur Benilov.
 * 
 * This file is a part of Artix classpath project. Please refer
 * to the project documentation for the detailed information.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
 * USA.
 */

package sys.entry;

import java.lang.*;
import sys.console.*;

/**
 * Java Kernel loader class
 * 
 * @author Arthur Benilov
 */
public class Entry {
	
	/**
	 * Starting Java kernel.
	 * This method is statically called by the native kernel.
	 */
	public static void entry() {		
		int i;
		float a = 1234.5678F;
		Console.println("Starting test, please wait...");
		Console.println("This will allocate objects and do some floating point math.");
		for (i = 0; i < 100000; i++) {
			float b = (float)i % 10;
			a = a * b / (float)i;
			Entry e = new Entry();
		}
		Console.println("Done.");
	
		Console.println("Testing reflection...");
		Entry obj = new Entry();
		Class c = obj.getClass();
		
		Console.println("Class name is: " + c.getName());
		Console.println("Superclass name is: " + c.getSuper().getName());
	
	}

	
}

