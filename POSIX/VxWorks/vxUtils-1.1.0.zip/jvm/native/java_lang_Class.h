/**
 * @class java.lang.Class
 */

/* ------------------------------------------------------ */
/* public native Class getSuper() */
static void native_class_get_super ( ) {
	object_t *class_obj;
    class_t *this_class;
    class_t *super_class;
    exec_t *exec = exec_get();
	
    heap_lock(exec->heap);
	
	class_obj = POP_OBJECT();
	if ( !class_obj ) {
		EXCEPTION("java/lang/NullPointerException", "Object is null");
		heap_unlock(exec->heap);
		return;
	}
	this_class = (class_t *)(*(int*)(class_obj->data));
	super_class = this_class->super;
	if ( super_class )
		class_obj = object_new_class(super_class);
	else
		class_obj = NULL;
	PUSH_OBJECT(class_obj);

	heap_unlock(exec->heap);
}

/* ------------------------------------------------------ */
/* private native String getName0() */
static void native_class_get_name ( ) {
	object_t *class_obj;
    class_t *class_class;
    object_t *str;
    exec_t *exec = exec_get();
    
	heap_lock(exec->heap);
	
    class_obj = POP_OBJECT();
	if ( !class_obj ) {
		EXCEPTION("java/lang/NullPointerException", "Cannot fetch name of a (null) class object");
		heap_unlock(exec->heap);
		return;
	}
	class_class = (class_t *)(*(int*)(class_obj->data));
	ASSERT(class_class);
	str = object_new_string(class_class->name);
	PUSH_OBJECT(str);

	heap_unlock(exec->heap);
}

/* ------------------------------------------------------ */
/* End of file */
