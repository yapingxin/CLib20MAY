/**
 * @class java.lang.Object
 */

/* ------------------------------------------------------ */
/* public final native Object clone() */
static void native_object_clone ( ) {
	object_t *object;
	object_t *clone;
	exec_t *exec = exec_get();
	heap_lock(exec->heap);
	object = POP_OBJECT();
	clone = object_clone(object);
	PUSH_OBJECT(clone);

	heap_unlock(exec->heap);
}

/* ------------------------------------------------------ */
/* public final native void wait(int timeout) throws InterruptedException */
static void native_object_wait ( ) {
	exec_t *exec = exec_get();
	int timeout = POP_INT();
	object_t *object = POP_OBJECT();
	
	if ( !object ) {
		EXCEPTION("java/lang/NullPointerException", "Cannot wait on null object");
		return;
	}
	
	if ( 0 == waitq_wait(&object->waitq, timeout) ) {
		EXCEPTION("java/lang/InterruptedException", "Waiting was interrupted");
	}
}

/* ------------------------------------------------------ */
/* public final native void notify() */
static void native_object_notify ( ) {
	exec_t *exec = exec_get();
	object_t *object = POP_OBJECT();
	/* Unblock one thread waiting for this object */
	waitq_unblock(&object->waitq);
}

/* ------------------------------------------------------ */
/* public final native void notifyAll() */
static void native_object_notify_all ( ) {
	exec_t *exec = exec_get();
	object_t *object = POP_OBJECT();
	/* Unblock all waiting threads */
	waitq_unblock_all(&object->waitq);
}

/* ------------------------------------------------------ */
/* public final native Class getClass() */
static void native_object_get_class ( ) {
	object_t *object;
    class_t *class;
    object_t *class_obj;
    exec_t *exec = exec_get();
	
	heap_lock(exec->heap);

	object = POP_OBJECT();
	if ( !object ) {
		EXCEPTION("java/lang/NullPointerException", "(null) object's class is undefined");
		heap_unlock(exec->heap);
		return;
	}
	class = object->class;
	class_obj = object_new_class(class);
	PUSH_OBJECT(class_obj);
	
	heap_unlock(exec->heap);
}

/* ------------------------------------------------------ */
/* End of file */
