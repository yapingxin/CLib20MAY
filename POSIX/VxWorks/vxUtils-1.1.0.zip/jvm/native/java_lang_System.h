/**
 * @class java.lang.System
 */

/* ------------------------------------------------------ */
/* public static native void arraycopy(Object src, int strStart, Object dest, int destStart, int len) */
static void native_arraycopy ( ) {
	exec_t *exec = exec_get();
	
	int len = POP_INT();
	int destStart = POP_INT();
	object_t *dest = POP_OBJECT();
	int srcStart = POP_INT();
	object_t *src = POP_OBJECT();
	int src_size;
	int dest_size;
	
	if ( len == 0 )
		return;
		
	if ( !src || !dest ) {
		EXCEPTION("java/lang/NullPointerException", "Object is null");
		return;
	}

	if ( len <= 0 ) {
		EXCEPTION("java/lang/ArrayIndexOutOfBoundsException", "Array length is negative or zero");
		return;
	}
	
	if ( !(src->array_type && dest->array_type) ) {
		EXCEPTION("java/lang/RuntimeException", "Object is not an array");
		return;
	}
	
	/* Computing size of a single element of src and dest arrays */
	src_size = src->array_length ? src->data_size / src->array_length : 0;
	dest_size = dest->array_length ? dest->data_size / dest->array_length : 0;

	if ( (srcStart + len <= (int)src->array_length) && (destStart + len <= (int)dest->array_length) )
		memcpy(dest->data + destStart*dest_size, src->data + srcStart*src_size, len*src_size);
	else {
		EXCEPTION("java/lang/ArrayIndexOutOfBoundsException", "Array index is out of bounds");
	}

}

/* ------------------------------------------------------ */
/* public static native void gc() */
static void native_gc ( ) {
	exec_t *exec = exec_get();
	if ( !exec )
		return;
	if ( mutex_try_lock(&exec->heap->mutex) ) {
		gc_run(exec);
		mutex_unlock(&exec->heap->mutex);
	}
}

/* ------------------------------------------------------ */
/* public static native int identifyHashCode(Object o) */
static void native_hash ( ) {
	/* Object's hash code is actually its address in memory.
	 * So, we have nothing to do here, the object is
	 * already on stack.
	 */
}

/* ------------------------------------------------------ */
/* End of file */
