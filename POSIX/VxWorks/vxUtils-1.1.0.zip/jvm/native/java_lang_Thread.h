/**
 * @class java.lang.Thread
 */

/* ------------------------------------------------------ */
/* public native void start() */
static void native_thread_start ( ) {
	exec_t *exec = exec_get();
	object_t *thread_object;
	java_thread_t *current_thread;
	
	heap_lock(exec->heap);
	thread_object = POP_OBJECT();
	current_thread = java_thread_self();
	java_thread_create(current_thread, thread_object, exec->stack_size, exec->heap->size);
	heap_unlock(exec->heap);
}

/* ------------------------------------------------------ */
/* public native Thread currentThread() */
static void native_thread_current ( ) {
	exec_t *exec = exec_get();
	java_thread_t *java_thread = java_thread_self();
	if ( java_thread ) {
		PUSH_OBJECT(java_thread->thread_object);
	} else {
		PUSH_OBJECT(NULL);
	}
}

/* ------------------------------------------------------ */
/* public static native void yield() */
static void native_thread_yield ( ) {
	java_thread_yield();
}


/* ------------------------------------------------------ */
/* public static native void sleep(int) */
static void native_thread_sleep ( ) {
	exec_t *exec = exec_get();
	int s = POP_INT();
	
	if ( TRUE == java_thread_sleep(s) ) {
		EXCEPTION("java/lang/InterruptedException", "Sleeping thread was interrupted");
	}
}

/* ------------------------------------------------------ */
/* public native void interrupt() */
static void native_thread_interrupt ( ) {
	exec_t *exec = exec_get();
	object_t *object = POP_OBJECT();
	java_thread_t *java_thread = java_thread_get(object);
	if ( java_thread )
		java_thread_wakeup(java_thread);
}

/* ------------------------------------------------------ */
/* End of file */
