/**
 * @class sys.console.Console
 */

/* ------------------------------------------------------ */
/* public static native void print(String str) */
static void native_print ( ) {
	exec_t *exec;
	field_t *field;
	object_t *str_array;
	unsigned short *unistr;
	object_t *string;
	int i;
	
	exec = exec_get();
	string = POP_OBJECT();
	if ( !string ) {
                printf("(null)");
		return;
	}
	
	field = field_resolve(string->class, "value");
	str_array = (object_t *)*((int *)((int)(string->data) + (int)(field->offset)));
	unistr = (unsigned short *)(str_array->data);
	i = 0;
	while ( i < (int)str_array->array_length ) {
		printf("%c", (char)*unistr);
		unistr++;
		i++;
	}
}

/* ------------------------------------------------------ */
/* public static native void newline() */
static void native_newline ( ) {
	printf("\n");
}

/* ------------------------------------------------------ */
/* End of file */
