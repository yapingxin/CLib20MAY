/* Copyright (C) 2007, Arthur Benilov
   Copyright (C) 2003, 2004, 2005, 2006 Robert Lougher <rob@lougher.org.uk>
   (A part of JamVM project)


   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_JAR_H__
#define __JVM_JAR_H__

#include "hash.h"

typedef
struct zip_file_s {
    int length;
    unsigned char *data;
    hash_table_t *dir_hash;
} zip_file_t;

zip_file_t *zip_process ( unsigned char *data, unsigned int len );

char *zip_find_dir_entry ( char *pathname, zip_file_t *zip );

char *zip_find_entry ( char *pathname, zip_file_t *zip, int *uncomp_len );

#endif /* __JVM_JAR_H__ */

/* End of file */

