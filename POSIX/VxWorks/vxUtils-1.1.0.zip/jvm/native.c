/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "assert.h"
#include "heap.h"
#include "sync.h"
#include "class.h"
#include "exec.h"
#include "thread.h"
#include "gc.h"
#include "native.h"

/*
 * All native finctions are implemented in the following includes.
 * Here we keep only a hash table linking these functions
 * and hash codes of correspondinf Java methods.
 */

#include "native/java_lang_Object.h"

#include "native/java_lang_Class.h"

#include "native/java_lang_System.h"

#include "native/sys_console_Console.h"

#include "native/java_lang_Thread.h"


/**
 * The table of all native routines
 */
static const native_t natives[] = {
/*   Class hash  |  Method hash  |  Native routine  */
/*   ---------------------------------------------  */

	/*	java.lang.Object	*/
	{0x4091EA9D,	0x9F2B1A20,	&native_object_clone},		/* clone()			*/
	{0x4091EA9D,	0x007E6739,	&native_object_wait},		/* wait()			*/
	{0x4091EA9D,	0xD3691CCA,	&native_object_notify},		/* notify()			*/
	{0x4091EA9D,	0xE3BACEF5,	&native_object_notify_all},	/* notifyAll()		*/
	{0x4091EA9D,	0x7949B83A,	&native_object_get_class},	/* getClass()		*/
	
	/*	java.lang.Class		*/
	{0xC229F200,	0x7F38EA37,	&native_class_get_super},	/* getSuper()		*/
	{0xC229F200,	0x98D89798, &native_class_get_name},	/* getName0()		*/
	
	/*	java.lang.System	*/
	{0x53B358D7,	0xE92F9750,	&native_arraycopy},			/* arraycopy()		*/
	{0x53B358D7,	0x0000D36D,	&native_gc},				/* gc()				*/
	{0x53B358D7,	0xF5CD2CFD,	&native_hash},				/* identifyHashCode()	*/

	/*	java.lang.Thread	*/
	{0x55EE34FA,	0x94D55299,	&native_thread_current},	/* currentThread()	*/
	{0x55EE34FA,	0x0DD74180,	&native_thread_yield},		/* yield()			*/
	{0x55EE34FA,	0x0D0E2F89,	&native_thread_sleep},		/* sleep()			*/
	{0x55EE34FA,	0xA9AF7922,	&native_thread_interrupt},	/* interrupt()		*/
	{0x55EE34FA,	0x0D34A825,	&native_thread_start},		/* start()			*/
	
	/*	sys.console.Console	*/
	{0x800F6A17,	0x0193E30A,	&native_print},				/* print()			*/
	{0x800F6A17,	0x65339FFD,	&native_newline},			/* newLine()		*/
	
    /* End of the native methods list */
    {0, 0, NULL}
};

/* ------------------------------------------------------ */

native_func_t native_resolve ( hash_t hashc, hash_t hashm ) {
    int i = 0;
    while (natives[i].native != NULL ) {
        if ( (natives[i].hash_class == hashc) &&
             (natives[i].hash_method == hashm) ) {
            return natives[i].native;
        }
        i++;
    }
    return NULL;
}

/* ------------------------------------------------------ */
/* End of file */

