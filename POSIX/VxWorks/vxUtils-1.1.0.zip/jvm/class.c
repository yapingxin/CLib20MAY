/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "assert.h"
#include "types.h"
#include "utf8.h"
#include "heap.h"
#include "hash.h"
#include "exec.h"
#include "method.h"
#include "loader.h"
#include "gc.h"

#include "class.h"


class_t *class_define ( const char *name, void *data ) {
    unsigned char *ptr;	/* data parsing pointer	*/
    u4 magic;			/* magic class signature	*/
    u2 major_version;		/* class version			*/
    u2 minor_version;
    u2 cp_count;			/* constant_pool count		*/
    constant_pool_t *cp;	/* Constant Pool			*/
    int c;				/* Constant pool iterator	*/
    exec_t *exec;			/* Execution environment	*/
    heap_t *heap;			/* Heap					*/
    class_t *class;		/* Class					*/
    s4  value_i;			/* Some integer value		*/
    s8  value_l;			/* Some long value		*/
    u2  index;			/* Some index				*/
    int i;
	unsigned int heap_id;

    exec = exec_get();
    ASSERT(exec != NULL);
    heap = exec->heap;
    ASSERT(heap != NULL);


    ASSERT(data != NULL);

    /* Start parsing at this point */
    ptr = (unsigned char *)data;

    /* Magic signature check */
    READ_U4(magic, ptr);
    if ( CLASS_MAGIC != magic ) {
        /** @todo Throw exception here */
        PANIC("Magic value is invalid");
        return NULL;
    }

    /* JVM version */
    READ_U2(minor_version, ptr);
    READ_U2(major_version, ptr);

    /* Number of constant pool entries */
    READ_U2(cp_count, ptr);

	/* Generating fresh heap id */
	heap_id = heap_new_id(heap);

    /* Allocate memory for constant pool */
    cp = (constant_pool_t *)heap_alloc(heap, sizeof(constant_pool_t), HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
    cp->tag = (u1 *)heap_alloc(heap, sizeof(u1) * cp_count, HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
    cp->info = (void**)heap_alloc(heap, sizeof(void*) * cp_count, HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
    cp->count = cp_count;

    /* Constant pool entries */
    for ( c = 1; c < cp_count; c++ ) {
        u1 tag; /* Constant tag */

        READ_U1(tag, ptr);
        cp->tag[c] = tag;

        /* Switch over different constants */
        switch ( tag ) {

            case CONSTANT_Utf8: {
                u2 length;
                char *buffer;
                char *utf8;

                cp->info[c] = (void *)heap_alloc(heap, sizeof(utf8_info_t), HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
                READ_U2(length, ptr);
                ((utf8_info_t *)cp->info[c])->length = length;
                /* Read string to z-terminated buffer */
                buffer = (char *)heap_alloc(heap, length + 1, HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
                memcpy(buffer, ptr, length);
                buffer[length] = '\0';
                ptr += length;
                utf8 = utf8_hash_table_find_or_add(exec->hash_table_utf8, buffer);
                if ( utf8 != buffer ) /* This string is already hashed */
                    heap_free(heap, buffer);
                ((utf8_info_t *)cp->info[c])->string = utf8;
                break;
            }

            case CONSTANT_Integer:
            case CONSTANT_Float:
                cp->info[c] = heap_alloc(heap, sizeof(integer_info_t), HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
                READ_U4(value_i, ptr);
                ((integer_info_t *)cp->info[c])->value = value_i;
                break;

            case CONSTANT_Long:
            case CONSTANT_Double:
                cp->info[c] = heap_alloc(heap, sizeof(long_info_t), HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
                READ_U8(value_l, ptr);
                ((long_info_t *)cp->info[c])->value = value_l;
                c++; /* 8-bytes values take two slots in constant pool */
                cp->tag[c] = 0;
                cp->info[0] = NULL;
                break;

            case CONSTANT_Class:
            case CONSTANT_String:
                cp->info[c] = heap_alloc(heap, sizeof(class_info_t), HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
                READ_U2(index, ptr);
                ((class_info_t*)cp->info[c])->name_index = index;
                break;

            case CONSTANT_FieldRef:
            case CONSTANT_MethodRef:
            case CONSTANT_InterfaceMethodRef:
            case CONSTANT_NameAndType:
                cp->info[c] = heap_alloc(heap, sizeof(fieldref_info_t), HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
                READ_U2(index, ptr);
                ((fieldref_info_t*)cp->info[c])->class_index = index;
                READ_U2(index, ptr);
                ((fieldref_info_t*)cp->info[c])->name_type_index = index;
                break;

            default:
                /** @todo Throw exception */
                PANIC("Unknown constant pool entry");
                return NULL;

        } /* switch ( tag ) */

    } /* for ( c = 1; c < cp_count; c++ ) */

    class = (class_t *)heap_alloc(heap, sizeof(class_t), HEAP_FLAG_GC_CLASS | HEAP_FLAG_GC_TEST | heap_id);
    class->state = CLASS_STATE_LOADING;
    class->constant_pool = cp;

    /* Read class access flags */
    READ_U2(class->access_flags, ptr);

    /* This class */
    READ_U2(index, ptr);
    index = ((class_info_t *)cp->info[index])->name_index;
    class->name = ((utf8_info_t *)cp->info[index])->string;

    if ( name && (strcmp(name, class->name)) != 0 ) {
        /** @todo Throw exception */
        PANIC("Class names do not match.");
        class->state = CLASS_STATE_INVALID;
        return NULL;
    }

    /* Super class */
    READ_U2(index, ptr);
    if ( strcmp(class->name, "java/lang/Object") == 0 ) {
        /* java.lang.Object class does not have a superclass */
        if ( index ) {
            /* But someone tries to assign a superclass to it */
            /** @todo Throw exception */
			PANIC("java.lang.Object cannot have a superclass.");
            class->state = CLASS_STATE_INVALID;
            return NULL;
        }
        class->super = NULL;
    } else {
        char *super_name;
        index = ((class_info_t *)cp->info[index])->name_index;
        super_name = ((utf8_info_t *)cp->info[index])->string;
        class->super = class_resolve(super_name);
    }

    /* Interfaces */
    READ_U2(class->interfaces_count, ptr);
	class->interfaces = NULL;
    if ( class->interfaces_count > 0 ) {
		class->interfaces = (class_t**)heap_alloc(heap, sizeof(class_t*) * class->interfaces_count,
			HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
        for ( i = 0; i < class->interfaces_count; i++ ) {
            char *interface_name;
            READ_U2(index, ptr);
            index = ((class_info_t *)cp->info[index])->name_index;
            interface_name = ((utf8_info_t *)cp->info[index])->string;
            class->interfaces[i] = class_resolve(interface_name);
            if ( NULL == class->interfaces[i] ) {
                /** @todo Throw exception */
                PANIC("Class implements interface that cannot be resolved");
                class->state = CLASS_STATE_INVALID;
                return NULL;
            }
        }
    } else
        class->interfaces = NULL;

    /* Fields */
    READ_U2(class->fields_count, ptr);
	class->fields = NULL;
    if ( class->fields_count > 0 ) {
        class->fields = (field_t *)heap_alloc(heap, sizeof(field_t) * class->fields_count, HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
        for ( i = 0; i < class->fields_count; i++ ) {
            u2 attr_count;
            int attr;

            READ_U2(class->fields[i].access_flags, ptr);
            READ_U2(index, ptr);    /* name index */
            class->fields[i].name = ((utf8_info_t *)cp->info[index])->string;
            READ_U2(index, ptr);    /* signature index */
            class->fields[i].signature = ((utf8_info_t *)cp->info[index])->string;
            READ_U2(attr_count, ptr);
            for ( attr = 0; attr < attr_count; attr++ ) {
                u2 attr_length;

                READ_U2(index, ptr);
                READ_U4(attr_length, ptr);
                if ( (cp->tag[index] == CONSTANT_Utf8) &&
                     (strcmp(((utf8_info_t *)cp->info[index])->string, "ConstantValue") == 0) ) {
                    READ_U2(class->fields[i].constant, ptr);
                } else {
                    class->fields[i].constant = 0;
                    ptr += attr_length;
                }
            }
        } /* for ( i = 0; i < class_fields_count; i++ ) */
    } else
        class->fields = NULL;

    /* Methods */
    READ_U2(class->methods_count, ptr);
	class->methods = NULL;
    if ( class->methods_count > 0 ) {
        class->methods = (method_t *)heap_alloc(heap, sizeof(method_t) * class->methods_count, HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
        for ( i = 0; i < class->methods_count; i++ ) {
            u2 attr_count;
            int attr;

            READ_U2(class->methods[i].access_flags, ptr);
            READ_U2(index, ptr); /* Method name */
            ASSERT(index < cp->count);
            ASSERT(cp->tag[index] == CONSTANT_Utf8);
            class->methods[i].name = ((utf8_info_t *)cp->info[index])->string;
			READ_U2(index, ptr); /* Method signature */
            class->methods[i].signature = ((utf8_info_t *)cp->info[index])->string;
            class->methods[i].class = class;
            /* attributes */
            READ_U2(attr_count, ptr);
            for ( attr = 0; attr < attr_count; attr++ ) {
                u4 attr_length;
                char *attr_name;

                READ_U2(index, ptr);
                READ_U4(attr_length, ptr);
                attr_name = ((utf8_info_t *)cp->info[index])->string;
                /* Olny two attributes are handled: code & exceptions */
                if ( strcmp(attr_name, "Code") == 0 ) {
                    int subattr_count;
                    u4 subattr_length;
                    int j;

                    READ_U2(class->methods[i].max_stack, ptr);
                    READ_U2(class->methods[i].max_locals, ptr);
                    READ_U4(class->methods[i].code_length, ptr);
                    class->methods[i].code = (u1*)ptr;
                    ptr += class->methods[i].code_length;
                    READ_U2(class->methods[i].exception_table_size, ptr);
                    /** @todo Check allocation flags */
                    if ( class->methods[i].exception_table_size > 0 ) {
                        class->methods[i].exception_table = (exception_t *)
                            heap_alloc(heap, sizeof(exception_t) * class->methods[i].exception_table_size, HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
                        for ( c = 0; c < class->methods[i].exception_table_size; c++ ) {
                            READ_U2(class->methods[i].exception_table[c].begin_pc, ptr);
                            READ_U2(class->methods[i].exception_table[c].end_pc, ptr);
                            READ_U2(class->methods[i].exception_table[c].handler_pc, ptr);
                            READ_U2(class->methods[i].exception_table[c].catch_type, ptr);
                        }
                    } else
                        class->methods[i].exception_table = NULL;

                    /* skip all code internal attributes */
                    READ_U2(subattr_count, ptr);
                    for ( j = 0; j < subattr_count; j++ ) {
                        READ_U2(index, ptr);
						ASSERT(index < cp->count);
						ASSERT(cp->tag[index] == CONSTANT_Utf8);
                        READ_U4(subattr_length, ptr);
						ASSERT(subattr_length > 0);
                        ptr += subattr_length;
                    }
                } else if ( strcmp(attr_name, "Exceptions") == 0 ) {
                    int j;

                    READ_U2(class->methods[i].throw_table_size, ptr);
                    class->methods[i].throw_table = (u2*)heap_alloc(heap, sizeof(u2) * class->methods[i].throw_table_size,
						HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
                    for ( j = 0; j < class->methods[i].throw_table_size; j++ )
                        READ_U2(class->methods[i].throw_table[j], ptr);
                } else {
                    ptr += attr_length; /* do not care about other atributes */
				}

            } /* for ( attr = 0; attr < attr_count; attr++ ) */
        } /* for ( i = 0; i < class->methods_count; i++ ) */
    } else
        class->methods = NULL;

	heap_mark_id(heap, heap_id, HEAP_FLAG_GC_TEST, HEAP_FLAG_GC_BLACK, 0);

    class->state = CLASS_STATE_LOADED;
    return class;
}

/* ------------------------------------------------------ */

void class_link ( class_t *class ) {
    class_t *super;
    field_t *field;
    int field_offset = 0;
    int field_size = 0;
    int new_methods_count = 0;
    int i, j;
    int super_method_table_size;
    method_t *method;
	unsigned int heap_id;    constant_pool_t *cp;
    exec_t *exec = exec_get();

    ASSERT(class != NULL);
    ASSERT(class->state == CLASS_STATE_LOADED);
    cp = class->constant_pool;
    class->state = CLASS_STATE_LINKING;

    class->hash = utf8_hash(class->name);

    super = (class->access_flags & ACC_INTERFACE) ? NULL : class->super;
    if ( super ) {
        /* Check if superclass is already linked */
        if ( super->state != CLASS_STATE_LINKED )
            class_link(super);
        field_offset = super->object_size;
    }

    /* Preparing fields */
    for ( field = class->fields, i = 0; i < class->fields_count; field++, i++ ) {
        if ( field->access_flags & ACC_STATIC ) {
            /* Clear static fields */
            field->static_value = 0;
            /* Check the first character of signature */
            if ( (SIG_LONG == *field->signature) || (SIG_DOUBLE == *field->signature) )
                field->offset = 0;
        } else {
            /* Non-static fields */
            field->offset = field_offset;
            switch ( *field->signature ) {  /* Estimate field size */
                case SIG_BYTE:
                    field_size = SIZE_BYTE;
                    break;
                case SIG_CHAR:
                    field_size = SIZE_CHAR;
                    break;
                case SIG_FLOAT:
                    field_size = SIZE_FLOAT;
                    break;
                case SIG_INT:
                    field_size = SIZE_INT;
                    break;
                case SIG_LONG:
                    field_size = SIZE_LONG;
                    break;
                case SIG_OBJECT:
                    field_size = SIZE_OBJECT;
                    break;
                case SIG_SHORT:
                    field_size = SIZE_SHORT;
                    break;
                case SIG_BOOLEAN:
                    field_size = SIZE_BOOLEAN;
                    break;
                case SIG_ARRAY:
                    field_size = SIZE_ARRAY;
                    break;
                default:
                    PANIC("Unknown field signature");
                    break;
            } /* switch ( *field->signature ) */
            field_offset += field_size;
        }
    }

    class->object_size = field_offset;

    /* Prepare methods */
    super_method_table_size = ( super ) ? super->method_table_size : 0;

    for ( method = class->methods, i = 0; i < class->methods_count; method++, i++ ) {
        int count = 0; /* counting arguments */
        char *sig = method->signature;

        /* counting U4 slots for local variables */
        SCAN_SIG(sig, count+=2, count++);
        if ( method->access_flags & ACC_STATIC )
            method->args_count = count;
        else /* For non-static methods an object reference is pushed on stack
              * and considered as first local variable
              */
            method->args_count = count + 1;

        method->hash = utf8_hash(method->name) ^ utf8_hash(method->signature);

        /* Resolving native calls */
        if ( method->access_flags & ACC_NATIVE ) {
            method->native = native_resolve(class->hash, method->hash);
            if ( !method->native ) {
				printf("%s.%s: class hash=0x%08X method hash=0x%08X\n", class->name, method->name, class->hash, method->hash);
                PANIC("Native method is not implemented.\n");
            }
        }

        /* Overriding inherited methods */
        for ( j = 0; j < super_method_table_size; j++ ) {
            if ( method->hash == super->method_table[j]->hash ) {
                method->index = super->method_table[j]->index;
                break;
            }
        }

        if ( j == super_method_table_size ) /* this is a new method */
            method->index = super_method_table_size + new_methods_count++;

        /* initialize method mutex */
        mutex_init(&method->mutex);
    }

    /* Constructing methods table */

    class->method_table = NULL;
    class->method_table_size = super_method_table_size + new_methods_count;

	heap_lock(exec->heap);

	heap_id = heap_new_id(exec->heap);

    /* skip interfaces */
    if ( !(class->access_flags & ACC_INTERFACE) ) {
        class->method_table = (method_t **)heap_alloc(exec->heap, sizeof(method_t *) * class->method_table_size,
			HEAP_FLAG_GC_GENERIC | HEAP_FLAG_GC_TEST | heap_id);
        /* copy method table of a superclass */
        if ( super )
            memcpy(class->method_table, super->method_table, super_method_table_size * sizeof(method_t *));

        /* filling in methods table */
        for ( j = 0; j < class->methods_count; j++ )
            class->method_table[class->methods[j].index] = &(class->methods[j]);
    }

	/* Make all allocated blocks permanent */
	heap_mark_id(exec->heap, heap_id, HEAP_FLAG_GC_TEST, HEAP_FLAG_GC_BLACK, 0);    /* Ok. Class is ready to be used */
    class->state = CLASS_STATE_LINKED;
    
    heap_unlock(exec->heap);
}

/* ------------------------------------------------------ */

method_t *method_resolve ( class_t *class, hash_t hash ) {
    int i;
	heap_t *heap = exec_get()->heap;

    ASSERT(class != NULL);
	ASSERT(class->state == CLASS_STATE_LINKED);
	if ( !class->method_table )
		return NULL; /* Interfaces do not have this table */

    for ( i = 0; i < class->method_table_size; i++ ) {
        method_t *method = class->method_table[i];
		ASSERT(method != NULL);
		ASSERT((int)method > (int)heap);
		ASSERT((int)method < (int)heap + heap->size);
		if ( method->hash == hash ) {
			return method;
		}
    }

    return NULL;
}

/* ------------------------------------------------------ */

class_t *class_load_system ( char *name, void *data ) {
    class_t *class = NULL;
	exec_t *exec = exec_get();
	hash_t hash;
    hash_entry_t *hash_entry;

	ASSERT(data != NULL);
	ASSERT(name);

	hash = utf8_hash(name);
	hash_table_lock(exec->hash_table_class);
	hash_entry = hash_table_find(exec->hash_table_class, hash);
	hash_table_unlock(exec->hash_table_class);
	if ( hash_entry ) {
		return (class_t*)hash_entry->data;
	} else {
		class = class_define(name, data);
		if ( class ) {
			method_t *method;

			hash_table_lock(exec->hash_table_class);
			hash_entry = hash_table_find_or_add(exec->hash_table_class, hash, (void *)class);
			hash_table_unlock(exec->hash_table_class);
			class = (class_t *)hash_entry->data;
			class_link(class);

			/* running <clinit> method */			/* utf8_hash("<clinit>") ^ utf8_hash("()V"); */
			method = (method_t *)method_resolve(class, 0x1D4C4CDE);			if ( NULL != method )
				method_invoke(class, NULL, method);
		}
    }
    return class;
}

/* ------------------------------------------------------ */

class_t *class_resolve ( char *name ) {
    hash_t hash = utf8_hash(name);
    hash_entry_t *entry;
    exec_t *exec = exec_get();

    hash_table_lock(exec->hash_table_class);
    entry = hash_table_find(exec->hash_table_class, hash);
    hash_table_unlock(exec->hash_table_class);
    if ( entry )
        return (class_t *)entry->data;
    else {
        /* Class is not loaded yet */
        void *data = (void *)load_class(name);
        if ( data ) {
            class_t *class = class_load_system(name, data);
            return class;
        }
    }

	DEBUG ("Class '%s' cannot be resolved\n", name);
    return NULL;
}

/* ------------------------------------------------------ */

field_t *field_resolve ( class_t *class, char *name ) {
    int i;

    ASSERT(class != NULL);
    for ( i = 0; i < class->fields_count; i++ ) {
        field_t *field = &class->fields[i];
        if ( strcmp(name, field->name) == 0 )
            return field;
    }
	if ( NULL != class->super )
		return field_resolve(class->super, name);

    return NULL;
}

/* ------------------------------------------------------ */

bool_t class_is_super ( class_t *class, class_t *parent ) {

    ASSERT(class != NULL);
    ASSERT(parent != NULL);

    while ( class != NULL ) {
        if ( class == parent )
            return TRUE;
        class = class->super;
    }

    return FALSE;
}

/* ------------------------------------------------------ */

bool_t class_implements ( class_t *class, class_t *interface ) {
    int i;

    ASSERT(class != NULL);
    ASSERT(interface != NULL);

    for ( i = 0; i < class->interfaces_count; i++ )
        if ( class->interfaces[i] == interface )
            return TRUE;

    return FALSE;
}

/* ------------------------------------------------------ */

object_t *object_new ( class_t *class ) {
    exec_t *exec;
    object_t *object;

    ASSERT(class != NULL);

    exec = exec_get();
	object = heap_alloc(exec->heap, sizeof(object_t), HEAP_FLAG_GC_GREY | HEAP_FLAG_GC_OBJECT);
    
    object->class = class;

    /* allocating object data section */
    object->data = NULL;
    object->array_type = 0; /* not an array by default */
    if ( class->object_size > 0 ) {
		object->data = heap_alloc(exec->heap, class->object_size, HEAP_FLAG_GC_GREY | HEAP_FLAG_GC_DATA);
		memset(object->data, 0, class->object_size);
	}
    object->data_size = class->object_size;

    mutex_init(&object->mutex);
	waitq_init(&object->waitq);

    return object;
}

/* ------------------------------------------------------ */

object_t *object_new_array ( u1 type, count_t length ) {
	unsigned int type_size = 0;
	exec_t *exec = exec_get();
	static class_t *class = NULL;
	object_t *object;
	method_t *constructor;


	if ( class == NULL ) {
	    class = class_resolve("java/lang/Object");
	}

	ASSERT(class);
	object = heap_alloc(exec->heap, sizeof(object_t), HEAP_FLAG_GC_GREY | HEAP_FLAG_GC_OBJECT);
	ASSERT(object != NULL);
	object->class = class;
        mutex_init(&object->mutex);
	waitq_init(&object->waitq);

	/*
	constructor = method_resolve(object->class, utf8_hash("<init>") ^ utf8_hash("()V"));
	PUSH_OBJECT(object);
	method_invoke(object->class, object, constructor);
	*/

	object->array_type = type;
	/* Estimating single element size */
	switch ( type ) {
		case T_BOOLEAN:
			type_size = SIZE_BOOLEAN;
			break;
		case T_CHAR:
			type_size = SIZE_CHAR;
			break;
		case T_FLOAT:
			type_size = SIZE_FLOAT;
			break;
		case T_DOUBLE:
			type_size = SIZE_DOUBLE;
			break;
		case T_BYTE:
			type_size = SIZE_BYTE;
			break;
		case T_SHORT:
			type_size = SIZE_SHORT;
			break;
		case T_INT:
			type_size = SIZE_INT;
			break;
		case T_OBJECT:
			type_size = SIZE_OBJECT;
			break;
		case T_LONG:
			type_size = SIZE_LONG;
			break;
		default:
			PANIC("Unknown array element type");
			break;
	}
	object->data_size = length * type_size;
	if ( object->data_size ) {
		object->data = heap_alloc(exec->heap, object->data_size, HEAP_FLAG_GC_GREY | HEAP_FLAG_GC_DATA);
		/* In Java newly created array elements are set to zero */
		memset(object->data, 0, object->data_size);
	} else
		object->data = NULL;
	object->array_length = length;

	return object;
}

/* ------------------------------------------------------ */

object_t *object_new_string ( char *str ) {
	static class_t *class = NULL;
	object_t *string;
	method_t *constructor;
	exec_t *exec;
    object_t *array;
    
    exec = exec_get();

	/* Create an array of characters */
	array = object_new_array(T_CHAR, strlen(str));

	/* Copy string into this array */
	utf8_convert(str, (unsigned short*)array->data);

	/* Put java.lang.String object on the stack */
	if ( class == NULL ) {
		class = class_resolve("java/lang/String");
	}
	ASSERT(class != NULL);
	string = object_new(class);
	PUSH_OBJECT(string);

	/* Put the array of characters on the stack */
	PUSH_OBJECT(array);

	/* Call constructor String(char[]) */    /* utf8_hash("<init>") ^ utf8_hash("([C)V") */
	constructor = method_resolve(class, 0x00AFEBFB);
	ASSERT(constructor != NULL);
	method_invoke(class, string, constructor);

	return string;
}

/* ------------------------------------------------------ */

object_t *object_new_class ( class_t *class ) {
	
    exec_t *exec;
	object_t *class_obj;
    class_t *class_class;
	method_t *constructor;
	
    if ( !class )
		return NULL;
			
    exec = exec_get();
    
    class_class = class_resolve("java/lang/Class");
	
    ASSERT(class_class);
	
	class_obj = object_new(class_class);	
	PUSH_OBJECT(class_obj);
	PUSH_INT((int)class);
	
	/* Executing constructor */        
	constructor = method_resolve(class_class, 0x04303B12); /* utf8_hash("<init>") ^ utf8_hash("(I)V") */
    
	ASSERT(constructor);
	method_invoke(class_class, class_obj, constructor);
    
	return class_obj;
}

/* ------------------------------------------------------ */

object_t *object_new_exception ( class_t *class, char *str ) {
	method_t *constructor;
	exec_t *exec;
	object_t *message;
	object_t *exception;

	ASSERT(class != NULL);

	exec = exec_get();
	message = object_new_string(str);
	exception = object_new(class);
	/* Call constructor Exception(String) */
	PUSH_OBJECT(exception);
	PUSH_OBJECT(message);    /* utf8_hash("<init>") ^ utf8_hash("(Ljava/lang/String;)V") */
	constructor = method_resolve(exception->class, 0x095EE881);	method_invoke(class, exception, constructor);
	return exception;
}

/* ------------------------------------------------------ */

object_t *object_clone ( object_t *object ) {
	exec_t *exec;
	object_t *clone;

	ASSERT(object != NULL);

	exec = exec_get();
	clone = heap_alloc(exec->heap, sizeof(object_t), HEAP_FLAG_GC_GREY | HEAP_FLAG_GC_OBJECT);
	clone->class = object->class;
	if ( object->data_size ) {
		/* Copy object data (if any) */
		clone->data = heap_alloc(exec->heap, object->class->object_size, HEAP_FLAG_GC_GREY | HEAP_FLAG_GC_DATA);
		memcpy(clone->data, object->data, object->class->object_size);
	}
	clone->array_type = object->array_type;
	clone->data_size = object->data_size;
	clone->array_length = object->array_length;

	/* prepare mutex */
	mutex_init(&clone->mutex);
	waitq_init(&clone->waitq);
	return clone;
}

/* ------------------------------------------------------ */
/* End of file */

