#ifndef _Z_ALLOC_H_
#define _Z_ALLOC_H_

#include <stdlib.h>


#endif
