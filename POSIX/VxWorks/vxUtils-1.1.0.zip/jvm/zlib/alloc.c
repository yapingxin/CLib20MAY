/*
	Memory allocation routines for zLib in uOS kernel
*/

#include <lib/types.h>
#include <kernel/kmalloc.h>

void *malloc(size_t size) {
	return (void*)kmalloc(size, 0);
}

void *calloc(count_t items, size_t size) {
	return (void*)kmalloc(items*size, 0);
}

void free(void *ptr) {
	kfree((vaddr_t)ptr);
}
