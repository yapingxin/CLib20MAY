/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <stdio.h>

#include "alloc.h"
#include "types.h"
#include "assert.h"
#include "class.h"
#include "thread.h"

#include "exec.h"

/** @todo remove this when threads are in place */
exec_t *last_created;

frame_t *frame_create ( method_t *method ) {
    frame_t *frame;
    exec_t *exec = exec_get();

    ASSERT(method != NULL);
    ASSERT(exec != NULL);

	/* Stack has the following structure (after the frame creation):
	
	   |-------------------------------|-------|---------->
	   ^                               ^       ^
	   arguments + local variables     frame   SP
	*/
	
	frame = (frame_t *)(exec->sp - method->args_count + method->max_locals);
	frame->method = method;
	frame->cp = method->code;
	frame->locals = exec->sp - method->args_count;
	frame->prev = exec->frame;
	exec->sp = (s4 *)((int)frame + sizeof(frame_t));
	exec->frame = frame;
	
    return frame;
}

/* ------------------------------------------------------ */

void frame_release ( ) {
    frame_t *prev_frame;
    exec_t *exec = exec_get();

    ASSERT(exec);
    ASSERT(exec->frame);

	exec->sp = exec->frame->locals;
	prev_frame = exec->frame->prev;
	exec->frame = prev_frame;
}

/* ------------------------------------------------------ */

exec_t *exec_create ( size_t heap_size ) {
    exec_t *exec;
	void *heap_ptr;

    ASSERT(heap_size > 0);
    exec = (exec_t *)jvm_alloc(sizeof(exec_t));
	ASSERT(exec != NULL);
    exec->hash_table_utf8 = hash_table_create(HASH_UTF8_SIZE);
    exec->hash_table_class = hash_table_create(HASH_CLASS_SIZE);
	heap_ptr = (void *)jvm_alloc(heap_size);
	ASSERT(heap_ptr != NULL);
    exec->heap = heap_create(heap_ptr, heap_size, 4);
    exec->frame = NULL;
    exec->exception = NULL;
	exec->stack = NULL;
	exec->sp = NULL;
	exec->stack_size = 0;
	
    last_created = exec;
    return exec;
}

/* ------------------------------------------------------ */

void exec_release ( exec_t *exec ) {
    ASSERT(exec != NULL);
    ASSERT(exec->frame == NULL);		/* No methods running   */
    ASSERT(exec->exception == NULL);	/* No exceptions        */

    hash_table_release(exec->hash_table_class);
    hash_table_release(exec->hash_table_utf8);
	jvm_free(exec->heap);
    jvm_free(exec);
}

/* ------------------------------------------------------ */

exec_t *exec_get ( ) {
	java_thread_t *thread = java_thread_self();
	if ( thread ) {
		ASSERT(thread->exec);
		return thread->exec;
	}

	ASSERT(last_created);
    return last_created;
}

/* ------------------------------------------------------ */

void exec_throw_exception ( object_t *exception ) {
    exec_t *exec = exec_get();

    ASSERT(exception != NULL);
    /* Double exception */
    ASSERT(exec->exception == NULL);
    exec->exception = exception;
	heap_mark(exec->heap, HEAP_FLAG_GC_TEST, HEAP_FLAG_GC_GREY, HEAP_FLAG_GC_BLACK);
}

/* ------------------------------------------------------ */
/* End of file */

