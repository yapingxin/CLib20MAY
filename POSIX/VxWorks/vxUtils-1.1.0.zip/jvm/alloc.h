/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_ALLOC_H__
#define __JVM_ALLOC_H__

/**
 * @file alloc.h
 *
 * Memory allocations
 */

#include "types.h"

/**
 * Initialize JVM allocator
 */
void jvm_alloc_init ( );

/**
 * Allocate memory
 *
 * @param size Number of bytes to allocate
 * @return Pointer to allocated memory region or NULL
 */
void *jvm_alloc ( size_t size );

/**
 * Release allocated memory
 *
 * @param prt Pointer to memory region to be released
 */
void jvm_free ( void *ptr );

/**
 * Free all allocated memory blocks
 */
void jvm_memory_cleanup ( );

#endif /* __JVM_ALLOC_H__ */

/* End of file */

