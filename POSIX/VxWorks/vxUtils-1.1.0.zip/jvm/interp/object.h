_OPC_NEW: {
	s2 index2;
	int class_name_index;
	char *class_name;
	class_t *inv_class;
	object_t *object;
	
	READ_U2(index2, frame->cp);
	ASSERT(cp->tag[index2] == CONSTANT_Class);
	class_name_index = ((class_info_t *)(cp->info[index2]))->name_index;
	ASSERT(cp->tag[class_name_index] == CONSTANT_Utf8);
	class_name = ((utf8_info_t *)(cp->info[class_name_index]))->string;
	heap_lock(exec->heap);
	inv_class = class_resolve(class_name);
	ASSERT(inv_class);
	object = object_new(inv_class);
	PUSH_OBJECT(object);
	heap_unlock(exec->heap);
	
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_NEW_ARRAY: {
	int length;
	u1 index1;
	object_t *object;

	READ_U1(index1, frame->cp);
	length = POP_INT();
	heap_lock(exec->heap);
	object = object_new_array(index1, length);
	ASSERT(object);
	PUSH_OBJECT(object);
	heap_unlock(exec->heap);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ARRAY_LENGTH: {
	object_t *object;

	object = POP_OBJECT();
	
	if ( !object ) {
		EXCEPTION("java/lang/NullPointerException", "Cannot get length of a null array object");
		INTERP_NEXT();
	}
	if ( !object->array_type ) {
		EXCEPTION("java/lang/RuntimeException", "Cannot get length of an object which is not an array");
		INTERP_NEXT();
	}

	PUSH_INT(object->array_length);				
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ATHROW: {
	object_t *object = POP_OBJECT();
	
	if ( !object ) {
		EXCEPTION("java/lang/NullPointerException", "Cannot throw a null object");
		INTERP_NEXT();
	}

	/**
	 * @todo
	 * Here we suppose that java.lang.Throwable is already loaded,
	 * and will be taken from the hash table. So we don't lock
	 * the heap here before calling class_resolve().
	 */
	if ( class_is_super(object->class, class_resolve("java/lang/Throwable")) ) {
		THROW(object);
	} else {
		EXCEPTION("java/lang/Runnable", "Object is not throwable");
	}
	
	INTERP_NEXT();
}
