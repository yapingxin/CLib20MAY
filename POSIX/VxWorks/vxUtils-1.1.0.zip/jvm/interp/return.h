_OPC_IRETURN:
_OPC_FRETURN:
	frame->locals[0] = *(exec->sp-1);
	frame->locals++;
	running = FALSE;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_ARETURN: {
	object_t *object;

	heap_lock(exec->heap);
	object = POP_OBJECT();
	frame->locals[0] = (int)object;
	frame->locals++;
	running = FALSE;
	heap_unlock(exec->heap);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_LRETURN:
_OPC_DRETURN:
	frame->locals[0] = *(exec->sp-1);
	frame->locals[1] = *(exec->sp-2);
	frame->locals += 2;
	running = FALSE;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_RETURN:
	running = FALSE;
	INTERP_NEXT();

