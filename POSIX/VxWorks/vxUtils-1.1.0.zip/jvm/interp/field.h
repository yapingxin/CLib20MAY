_OPC_GET_STATIC: {
	s2 index2;
	fieldref_info_t *fieldref;
	int name_index;
	char *field_name;
	field_t *inv_field;

	READ_U2(index2, frame->cp);
	ASSERT(cp->tag[index2] == CONSTANT_FieldRef);
	fieldref = (fieldref_info_t *)cp->info[index2];
	name_index = ((name_type_info_t *)(cp->info[fieldref->name_type_index]))->name_index;
	field_name = ((utf8_info_t *)(cp->info[name_index]))->string;
	inv_field = field_resolve(class, field_name);

	if ( inv_field->signature[0] == SIG_LONG || inv_field->signature[0] == SIG_DOUBLE )
		PUSH_INT(inv_field->offset);	/* High 4 bytes */
	PUSH_INT(inv_field->static_value);

	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_PUT_STATIC: {
	s2 index2;
	fieldref_info_t *fieldref;
	int name_index;
	char *field_name;
	field_t *inv_field;

	READ_U2(index2, frame->cp);
	ASSERT(cp->tag[index2] == CONSTANT_FieldRef);
	fieldref = (fieldref_info_t *)cp->info[index2];
	name_index = ((name_type_info_t *)(cp->info[fieldref->name_type_index]))->name_index;
	field_name = ((utf8_info_t *)(cp->info[name_index]))->string;
	inv_field = field_resolve(class, field_name);

	inv_field->static_value = POP_INT();
	if ( inv_field->signature[0] == SIG_LONG || inv_field->signature[0] == SIG_DOUBLE )
		inv_field->offset = POP_INT();

	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_PUT_FIELD: {
	/* pop value from stack and put it to object's field */
	u2 index2;
	fieldref_info_t *fieldref;
	int class_name_index;
	char *class_name;
	int name_index;
	char *field_name;
	class_t *inv_class;
	field_t *inv_field;

	READ_U2(index2, frame->cp);
	fieldref = (fieldref_info_t *)cp->info[index2];

	/* resolve field */	class_name_index = ((class_info_t *)(cp->info[fieldref->class_index]))->name_index;
	class_name = ((utf8_info_t *)(cp->info[class_name_index]))->string;
	name_index = ((name_type_info_t *)(cp->info[fieldref->name_type_index]))->name_index;
	field_name = ((utf8_info_t *)(cp->info[name_index]))->string;
	heap_lock(heap);
	inv_class = (void*)class_resolve(class_name);
	heap_unlock(heap);
	ASSERT(inv_class);
	inv_field = (void*)field_resolve(inv_class, field_name);
	ASSERT(inv_field);

	/* Replace bytecode by 'quick' version */
	if ( inv_field->offset < 256 ) {
		mutex_lock(&method->mutex);
		*(frame->cp-3) = OPC_PUT_FIELD_QUICK;
		*(frame->cp-2) = (unsigned char)(inv_field->offset);
		*(frame->cp-1) = inv_field->signature[0];
		mutex_unlock(&method->mutex);
	}

	switch ( inv_field->signature[0] ) {
		case SIG_BYTE:
		case SIG_CHAR:
		case SIG_SHORT:
		case SIG_FLOAT:
		case SIG_INT:
		case SIG_OBJECT:
		case SIG_ARRAY: {
			int value = POP_INT();
			object_t *object = POP_OBJECT();
			/** @todo Throw exception instead of assertion */
			ASSERT(object);
			*((int*)(object->data + inv_field->offset)) = value;
			break;
		}
		case SIG_LONG:
		case SIG_DOUBLE: {
			long long int value = POP_LONG();
			object_t *object = POP_OBJECT();
			/** @todo Throw exception instead of assertion */
			ASSERT(object);
			*((long long int*)(object->data + inv_field->offset)) = value;
			break;
		}
		default:
			PANIC("Unknown signature");
			break;
	}

	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_PUT_FIELD_QUICK: {
	u1 offset;
	unsigned char signature;

	READ_U1(offset, frame->cp);
	READ_U1(signature, frame->cp);
	switch ( signature ) {
		case SIG_BYTE:
		case SIG_CHAR:
		case SIG_SHORT:
		case SIG_FLOAT:
		case SIG_INT:
		case SIG_OBJECT:
		case SIG_ARRAY: {
			int value = POP_INT();
			object_t *object = POP_OBJECT();
			/** @todo Throw exception instead of assertion */
			ASSERT(object);
			*((int*)(object->data + offset)) = value;
			break;
		}
		case SIG_LONG:
		case SIG_DOUBLE: {
			long long int value = POP_LONG();
			object_t *object = POP_OBJECT();
			/** @todo Throw exception instead of assertion */
			ASSERT(object);
			*((long long int*)(object->data + offset)) = value;
			break;
		}
		default:
			PANIC("Unknown signature");
			break;
	}

	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_GET_FIELD: {
	u2 index2;
	object_t *object;
	fieldref_info_t *fieldref;
	int class_name_index;
	char *class_name;
	int name_index;
	char *field_name;
	class_t *inv_class;
	field_t *inv_field;

	READ_U2(index2, frame->cp);
	object = POP_OBJECT();
	/** @todo Throw exception instead of assertion */
	ASSERT(object);

	fieldref = (fieldref_info_t *)cp->info[index2];

	/* resolving field */
	class_name_index = ((class_info_t *)(cp->info[fieldref->class_index]))->name_index;
	class_name = ((utf8_info_t *)(cp->info[class_name_index]))->string;
	name_index = ((name_type_info_t *)(cp->info[fieldref->name_type_index]))->name_index;
	field_name = ((utf8_info_t *)(cp->info[name_index]))->string;
	heap_lock(heap);
	inv_class = class_resolve(class_name);
	heap_unlock(heap);
	ASSERT(inv_class);
	inv_field = field_resolve(object->class, field_name);
	ASSERT(inv_field);

	/* Replace bytecode by its 'quick' version */
	if ( inv_field->offset < 256 ) {
		mutex_lock(&method->mutex);
		*(frame->cp-3) = OPC_GET_FIELD_QUICK;
		*(frame->cp-2) = (unsigned char)(inv_field->offset);
		*(frame->cp-1) = inv_field->signature[0];
		mutex_unlock(&method->mutex);
	}

	switch ( inv_field->signature[0] ) {
		case SIG_BYTE:
			PUSH_INT(*(char *)(object->data + inv_field->offset));
			break;
		case SIG_CHAR:
		case SIG_SHORT:
			PUSH_INT(*(short int *)(object->data + inv_field->offset));
			break;
		case SIG_FLOAT:
		case SIG_INT:
		case SIG_OBJECT:
		case SIG_ARRAY:
			PUSH_INT(*(int *)(object->data + inv_field->offset));
			break;
		case SIG_LONG:
		case SIG_DOUBLE:
			PUSH_LONG(*(long long int *)(object->data + inv_field->offset));
			break;
		default:
			PANIC("Unknown field signature");
			break;
	}

	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_GET_FIELD_QUICK: {
	u1 offset;
	char signature;
	object_t *object;

	READ_U1(offset, frame->cp);
	READ_U1(signature, frame->cp);

	object = POP_OBJECT();

	if ( !object ) {
		EXCEPTION("java/lang/NullPointerException", "Cannot get field of a null object");
		INTERP_NEXT();
	}

	switch ( signature ) {
		case SIG_BYTE:
			PUSH_INT(*(char *)(object->data + offset));
			break;
		case SIG_CHAR:
		case SIG_SHORT:
			PUSH_INT(*(short int *)(object->data + offset));
			break;
		case SIG_FLOAT:
		case SIG_INT:
		case SIG_OBJECT:
		case SIG_ARRAY:
			PUSH_INT(*(int *)(object->data + offset));
			break;
		case SIG_LONG:
		case SIG_DOUBLE:
			PUSH_LONG(*(long long int *)(object->data + offset));
			break;
		default:
			PANIC("Unknown field signature");
			break;
	}

	INTERP_NEXT();
}
