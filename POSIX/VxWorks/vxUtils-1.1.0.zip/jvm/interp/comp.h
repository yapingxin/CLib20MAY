#define BRANCH(ptr)	frame->cp = frame->cp + ptr - 3

_OPC_DCMPL:
_OPC_DCMPG:
_OPC_JSR:
_OPC_RET:
_OPC_TABLESWITCH:
	goto _OPC_INVALID;

/* ------------------------------------------------------ */

_OPC_LCMP: {
	s8 b = POP_LONG();
	s8 a = POP_LONG();
	if ( a > b )
		PUSH_INT(1);
	else if ( a < b )
		PUSH_INT(-1);
	else
		PUSH_INT(0);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */
#define NAN (0x7fc00000)

_OPC_FCMPL: {
	float b = POP_FLOAT();
	float a = POP_FLOAT();
	if ( *((int*)&a) == NAN || *((int*)&b) == NAN )
		PUSH_INT(-1);
	else if ( a > b )
		PUSH_INT(1);
	else if ( a < b )
		PUSH_INT(-1);
	else
		PUSH_INT(0);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_FCMPG: {
	float b = POP_FLOAT();
	float a = POP_FLOAT();
	if ( *((int*)&a) == NAN || *((int*)&b) == NAN )
		PUSH_INT(1);
	else if ( a > b )
		PUSH_INT(1);
	else if ( a < b )
		PUSH_INT(-1);
	else
		PUSH_INT(0);
	INTERP_NEXT();
}

#undef NAN
/* ------------------------------------------------------ */

_OPC_IFEQ: {
	s2 index2;
	READ_U2(index2, frame->cp);
	if ( 0 == POP_INT() )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IFNE: {
	s2 index2;
	READ_U2(index2, frame->cp);
	if ( 0 != POP_INT() )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IFLT: {
	s2 index2;
	READ_U2(index2, frame->cp);
	if ( POP_INT() < 0 )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IFGE: {
	s2 index2;
	READ_U2(index2, frame->cp);
	if ( POP_INT() >= 0 )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IFGT: {
	s2 index2;
	READ_U2(index2, frame->cp);
	if ( POP_INT() > 0 )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IFLE: {
	s2 index2;
	READ_U2(index2, frame->cp);
	if ( POP_INT() <= 0 )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IF_ICMPEQ:
_OPC_IF_ACMPEQ: {
	s2 index2;
	s4 a, b;
	READ_U2(index2, frame->cp);
	b = POP_INT();
	a = POP_INT();
	if ( a == b )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IF_ICMPNE:
_OPC_IF_ACMPNE: {
	s2 index2;
	s4 a, b;
	READ_U2(index2, frame->cp);
	b = POP_INT();
	a = POP_INT();
	if ( a != b )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IF_ICMPLT: {
	s2 index2;
	s4 a, b;
	READ_U2(index2, frame->cp);
	b = POP_INT();
	a = POP_INT();
	if ( a < b )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IF_ICMPGE: {
	s2 index2;
	s4 a, b;
	READ_U2(index2, frame->cp);
	b = POP_INT();
	a = POP_INT();
	if ( a >= b )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IF_ICMPGT: {
	s2 index2;
	s4 a, b;
	READ_U2(index2, frame->cp);
	b = POP_INT();
	a = POP_INT();
	if ( a > b )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IF_ICMPLE: {
	s2 index2;
	s4 a, b;
	READ_U2(index2, frame->cp);
	b = POP_INT();
	a = POP_INT();
	if ( a <= b )
		BRANCH(index2);
	
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_GOTO: {
	s2 index2;
	READ_U2(index2, frame->cp);
	BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_LOOKUP_SWITCH: {
	int def;
	int ncases;
	int key;
	int old_cp = (int)frame->cp - 1;
	int padding = 4 - (old_cp - (int)(method->code) + 1) % 4;
	frame->cp = frame->cp + padding % 4;
	key = POP_INT();
	READ_U4(def, frame->cp);
	READ_U4(ncases, frame->cp);
	while ( ncases > 0 ) {
		int match;
		int offset;
		READ_U4(match, frame->cp);
		READ_U4(offset, frame->cp);
		if ( key == match ) {
			frame->cp = (u1 *)(old_cp + offset);
			break;
		}
		ncases--;
	}
	if ( ncases == 0 ) {
		frame->cp = (u1 *)(old_cp + def);
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IF_NULL: {
	s2 index2;
	READ_U2(index2, frame->cp);
	if ( NULL == POP_OBJECT() )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IF_NOT_NULL: {
	s2 index2;
	READ_U2(index2, frame->cp);
	if ( NULL != POP_OBJECT() )
		BRANCH(index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

#undef BRANCH
