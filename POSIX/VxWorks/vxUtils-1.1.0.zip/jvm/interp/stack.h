_OPC_NOP:
	INTERP_NEXT();

/* ------------------------------------------------------ */				
	
_OPC_ACONST_NULL:
	PUSH_OBJECT(NULL);
	INTERP_NEXT();

/* ------------------------------------------------------ */				

_OPC_ICONST_M1:
	PUSH_INT(-1);
	INTERP_NEXT();

/* ------------------------------------------------------ */				

_OPC_ICONST_0:
_OPC_ICONST_1:
_OPC_ICONST_2:
_OPC_ICONST_3:
_OPC_ICONST_4:
_OPC_ICONST_5:
	PUSH_INT(opcode - OPC_ICONST_0);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_LCONST_0:
	PUSH_LONG((long long int)0L);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_LCONST_1:
	PUSH_LONG((long long int)1L);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_FCONST_0:
	PUSH_FLOAT(0.0F);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_FCONST_1:
	PUSH_FLOAT(1.0F);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_FCONST_2:
	PUSH_FLOAT(2.0F);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_DCONST_0: {
	double d = 0.0;
	PUSH_LONG(*((long long int *)&d));
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_DCONST_1: {
	double d = 1.0;
	PUSH_LONG(*((long long int *)&d));
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_BIPUSH: {
	u1 index1;
	READ_U1(index1, frame->cp);
	PUSH_INT((int)index1);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_SIPUSH: {
	u2 index2;
	READ_U2(index2, frame->cp);
	PUSH_INT((int)index2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */				

_OPC_LDC:
_OPC_LDC_W: {
	u1 index1;
	u2 index2;

	READ_U1(index1, frame->cp);
	if ( OPC_LDC == opcode )
		index2 = (u2)index1;
	else {
		READ_U2(index2, frame->cp);
	}

	switch ( cp->tag[index2] ) {
		case CONSTANT_Integer:
		case CONSTANT_Float:
			PUSH_INT(((integer_info_t *)(cp->info[index2]))->value);
			break;

		case CONSTANT_Long:
		case CONSTANT_Double:
			PUSH_LONG(((long_info_t *)(cp->info[index2]))->value);
			break;
	
		case CONSTANT_String: {
			object_t *object;
			index2 = ((string_info_t *)(cp->info[index2]))->string_index;
			heap_lock(heap);
			object = object_new_string(((utf8_info_t *)(cp->info[index2]))->string);
			PUSH_OBJECT(object);
			heap_unlock(heap);
			break;
		}

		default:
			PANIC("Unknown constant type");
			break;
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */		

_OPC_LDC2_W : {
	s2 index2;

	READ_U2(index2, frame->cp);
	ASSERT(cp->tag[index2] == CONSTANT_Long || cp->tag[index2] == CONSTANT_Double);
	PUSH_LONG(((long_info_t *)(cp->info[index2]))->value);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ILOAD:
_OPC_FLOAD:
_OPC_ALOAD: {
	u1 index1;
	READ_U1(index1, frame->cp);
	PUSH_INT(frame->locals[index1]);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_LLOAD:
_OPC_DLOAD: {
	u1 index1;
	READ_U1(index1, frame->cp);
	/** @todo Here the long/double (64 bits) constat is decomposed
	 * in two indegers (32 bits). Mind the order of decomposition
	 */
	PUSH_INT(frame->locals[index1+1]);
	PUSH_INT(frame->locals[index1]);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ILOAD_0:
_OPC_ILOAD_1:
_OPC_ILOAD_2:
_OPC_ILOAD_3:
	PUSH_INT(frame->locals[opcode - OPC_ILOAD_0]);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_LLOAD_0:
_OPC_LLOAD_1:
_OPC_LLOAD_2:
_OPC_LLOAD_3:
	PUSH_INT(frame->locals[opcode - OPC_LLOAD_0 + 1]);
	PUSH_INT(frame->locals[opcode - OPC_LLOAD_0]);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_FLOAD_0:
_OPC_FLOAD_1:
_OPC_FLOAD_2:
_OPC_FLOAD_3:
	PUSH_INT(frame->locals[opcode - OPC_FLOAD_0]);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_DLOAD_0:
_OPC_DLOAD_1:
_OPC_DLOAD_2:
_OPC_DLOAD_3:
	PUSH_INT(frame->locals[opcode - OPC_DLOAD_0 + 1]);
	PUSH_INT(frame->locals[opcode - OPC_DLOAD_0]);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_ALOAD_0:
_OPC_ALOAD_1:
_OPC_ALOAD_2:
_OPC_ALOAD_3: {
	PUSH_INT(frame->locals[opcode - OPC_ALOAD_0]);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IALOAD:
_OPC_FALOAD:
_OPC_AALOAD: {
	int index = POP_INT();
	object_t *object = POP_OBJECT();
	if ( (index < 0) || (index >= (int)object->array_length) ) {
		EXCEPTION("java/lang/ArrayIndeOutOfBoundsException", "Array index is out of bounds");
	} else {
		PUSH_INT(((unsigned int *)(object->data))[index]);
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_LALOAD:
_OPC_DALOAD: {
	int index = POP_INT();
	object_t *object = POP_OBJECT();
	if ( (index < 0) || (index >= (int)object->array_length) ) {
		EXCEPTION("java/lang/ArrayIndeOutOfBoundsException", "Array index is out of bounds");
	} else {
		PUSH_LONG(((u8 *)(object->data))[index]);
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_SALOAD:
_OPC_CALOAD: {
	int index = POP_INT();
	object_t *object = POP_OBJECT();
	if ( (index < 0) || (index >= (int)object->array_length) ) {
		EXCEPTION("java/lang/ArrayIndeOutOfBoundsException", "Array index is out of bounds");
	} else {	
		PUSH_INT(((u2 *)(object->data))[index]);
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_BALOAD: {
	int index = POP_INT();
	object_t *object = POP_OBJECT();
	if ( (index < 0) || (index >= (int)object->array_length) ) {
		EXCEPTION("java/lang/ArrayIndeOutOfBoundsException", "Array index is out of bounds");
	} else {	
		PUSH_INT(((u1 *)(object->data))[index]);
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ISTORE:
_OPC_FSTORE: {
	u1 index1;
	READ_U1(index1, frame->cp);
	frame->locals[index1] = POP_INT();
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ASTORE: {
	u1 index1;
	heap_lock(heap);
	READ_U1(index1, frame->cp);
	frame->locals[index1] = POP_INT();
	heap_unlock(heap);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_LSTORE:
_OPC_DSTORE: {
	u1 index1;
	READ_U1(index1, frame->cp);
	frame->locals[index1] = POP_INT();
	frame->locals[index1+1] = POP_INT();
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ISTORE_0:
_OPC_ISTORE_1:
_OPC_ISTORE_2:
_OPC_ISTORE_3:
	frame->locals[opcode - OPC_ISTORE_0] = POP_INT();
	INTERP_NEXT();
	
/* ------------------------------------------------------ */

_OPC_LSTORE_0:
_OPC_LSTORE_1:
_OPC_LSTORE_2:
_OPC_LSTORE_3: {
	frame->locals[opcode - OPC_LSTORE_0] = POP_INT();
	frame->locals[opcode - OPC_LSTORE_0 + 1] = POP_INT();
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_FSTORE_0:
_OPC_FSTORE_1:
_OPC_FSTORE_2:
_OPC_FSTORE_3: {
	frame->locals[opcode - OPC_FSTORE_0] = POP_INT();
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_DSTORE_0:
_OPC_DSTORE_1:
_OPC_DSTORE_2:
_OPC_DSTORE_3: {
	frame->locals[opcode - OPC_DSTORE_0] = POP_INT();
	frame->locals[opcode - OPC_DSTORE_0 + 1] = POP_INT();
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ASTORE_0:
_OPC_ASTORE_1:
_OPC_ASTORE_2:
_OPC_ASTORE_3: {
	heap_lock(heap);
	frame->locals[opcode - OPC_ASTORE_0] = POP_INT();
	heap_unlock(heap);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IASTORE:
_OPC_FASTORE:
_OPC_AASTORE: {
	int value = POP_INT();
	int index = POP_INT();
	object_t *object = POP_OBJECT();
	if ( (index < 0) || (index >= (int)object->array_length) ) {
		EXCEPTION("java/lang/ArrayIndexOutOfBoundsException", "Array index is out of bounds");
	} else {
		((int *)(object->data))[index] = value;
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_DASTORE:
_OPC_LASTORE: {
	s8 value = POP_LONG();
	int index = POP_INT();
	object_t *object = POP_OBJECT();
	if ( (index < 0) || (index >= (int)object->array_length) ) {
		EXCEPTION("java/lang/ArrayIndexOutOfBoundsException", "Array index is out of bounds");
	} else {
		((u8 *)(object->data))[index] = value;
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_BASTORE: {
	int value = POP_INT();
	int index = POP_INT();
	object_t *object = POP_OBJECT();
	if ( (index < 0) || (index >= (int)object->array_length) ) {
		EXCEPTION("java/lang/ArrayIndexOutOfBoundsException", "Array index is out of bounds");
	} else {
		((char *)(object->data))[index] = value;
	}
	INTERP_NEXT();	
}

/* ------------------------------------------------------ */

_OPC_SASTORE:
_OPC_CASTORE: {
	int value = POP_INT();
	int index = POP_INT();
	object_t *object = POP_OBJECT();
	if ( (index < 0) || (index >= (int)object->array_length) ) {
		EXCEPTION("java/lang/ArrayIndexOutOfBoundsException", "Array index is out of bounds");
	} else {
		((u2 *)(object->data))[index] = (u2)value;
	}
	INTERP_NEXT();	
}

/* ------------------------------------------------------ */

_OPC_POP:
	exec->sp--;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_POP2:
	exec->sp -= 2;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_DUP:
	*(exec->sp++) = *(exec->sp-1);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_DUP_X1: {
	int v1, v2;
	/* We have to lock the heap here
	 * as far as we pop some values from stack.
	 * The popped values can be collected by the garbage
	 * collector if we don't lock the heap here.
	 */
	heap_lock(heap);
	v1 = POP_INT();
	v2 = POP_INT();
	PUSH_INT(v1);
	PUSH_INT(v2);
	PUSH_INT(v1);
	heap_unlock(heap);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_DUP_X2: {
	int v1, v2, v3;
	heap_lock(heap);
	v1 = POP_INT();
	v2 = POP_INT();
	v3 = POP_INT();
	PUSH_INT(v1);
	PUSH_INT(v3);
	PUSH_INT(v2);
	PUSH_INT(v1);
	heap_unlock(heap);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_DUP2: {
	int v1 = *(exec->sp-1);
	int v2 = *(exec->sp-2);
	PUSH_INT(v2);
	PUSH_INT(v1);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_DUP2_X1: {
	int v1, v2, v3;
	heap_lock(heap);
	v1 = POP_INT();
	v2 = POP_INT();
	v3 = POP_INT();
	PUSH_INT(v2);
	PUSH_INT(v1);
	PUSH_INT(v3);
	PUSH_INT(v2);
	PUSH_INT(v1);
	heap_unlock(heap);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_DUP2_X2: {
	int v1, v2, v3, v4;
	heap_lock(heap);
	v1 = POP_INT();
	v2 = POP_INT();
	v3 = POP_INT();
	v4 = POP_INT();
	PUSH_INT(v2);
	PUSH_INT(v1);
	PUSH_INT(v4);
	PUSH_INT(v3);
	PUSH_INT(v2);
	PUSH_INT(v1);
	heap_unlock(heap);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_SWAP: {
	int v1, v2;
	heap_lock(heap);
	v1 = POP_INT();
	v2 = POP_INT();
	PUSH_INT(v1);
	PUSH_INT(v2);
	heap_unlock(heap);
	INTERP_NEXT();
}
