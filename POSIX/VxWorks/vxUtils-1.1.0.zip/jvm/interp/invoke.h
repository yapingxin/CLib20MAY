_OPC_INVOKE_VIRTUAL: {
	s2 index2;
	methodref_info_t *methodref;
	int name_index;
	char *class_name;
	char *method_name;
	int type_index;
	char *signature;
	class_t *inv_class;
	hash_t hash;
	method_t *inv_method;
	object_t *object;
	
	READ_U2(index2, frame->cp);
	ASSERT(cp->tag[index2] == CONSTANT_MethodRef);
	methodref = (methodref_info_t *)cp->info[index2];
	ASSERT(cp->tag[methodref->class_index] == CONSTANT_Class);
	name_index = ((class_info_t *)(cp->info[methodref->class_index]))->name_index;
	ASSERT(cp->tag[name_index] == CONSTANT_Utf8);
	class_name = ((utf8_info_t *)(cp->info[name_index]))->string;
	ASSERT(cp->tag[methodref->name_type_index] == CONSTANT_NameAndType);
	name_index = ((name_type_info_t *)(cp->info[methodref->name_type_index]))->name_index;
	ASSERT(cp->tag[name_index] == CONSTANT_Utf8);
	method_name = ((utf8_info_t *)(cp->info[name_index]))->string;
	type_index = ((name_type_info_t *)(cp->info[methodref->name_type_index]))->signature_index;
	ASSERT(cp->tag[type_index] == CONSTANT_Utf8);
	signature = ((utf8_info_t *)(cp->info[type_index]))->string;
	heap_lock(heap);
	inv_class = class_resolve(class_name);
	heap_unlock(heap);
	ASSERT(inv_class);
	hash = utf8_hash(method_name) ^ utf8_hash(signature);
	inv_method = method_resolve(inv_class, hash);
	ASSERT(inv_method);
	object = (object_t*)*(exec->sp - inv_method->args_count);
	if ( !object ) {
		EXCEPTION("java/lang/NullPointerException", "Cannot invoke a virtual method of a null object");
	} else {
		method_t *inv_method1 = method_resolve(object->class, hash);
		if ( inv_method1 == NULL ) {
			printf("-- method name = %s\n", method_name);
			printf("-- hash = %08X\n", hash);
			printf("-- object.class = %s\n", (object)? object->class->name : "NULL");
			printf("-- inv_class = %s\n", (inv_class) ? inv_class->name : "NULL");
			printf("-- exec->sp = %08X\n", (unsigned int)exec->sp);
			printf("-- nargs = %d\n", inv_method->args_count);
			printf("-- ptr = %08X\n", (unsigned int)(exec->sp - inv_method->args_count));
			printf("-- frame->cp = %d\n", (int)(frame->cp - method->code));
			printf("-- locals[1] = %08X\n", (unsigned int)frame->locals[1]);
			printf("-- locals[2] = %08X\n", (unsigned int)frame->locals[2]);
			printf("-- locals[3] = %08X\n", (unsigned int)frame->locals[3]);
			printf("-- object = %08X\n", (unsigned int)object);
		}
		ASSERT(inv_method1);
		/*
		if ( inv_class != inv_method->class ) {
			printf("Virtual mismatch: %s / %s\n", inv_class->name, inv_method->class->name);
		}
		*/
		inv_class = inv_method->class;
		if ( inv_method->index < 256 ) {
			/* Replace bytecode by its 'quick' version */
			mutex_lock(&method->mutex);
			*(frame->cp-3) = OPC_INVOKE_VIRTUAL_QUICK;
			*(frame->cp-2) = (unsigned char)(inv_method->index);
			*(frame->cp-1) = (unsigned char)(inv_method->args_count);
			mutex_unlock(&method->mutex);
		}
		method_invoke(inv_class, object, inv_method);
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_INVOKE_VIRTUAL_QUICK: {
	u1 offset;
	u2 nargs;
	object_t *object;
	
	READ_U1(offset, frame->cp);
	READ_U1(nargs, frame->cp);
	object = (object_t *)*(exec->sp - nargs);
	if ( !object ) {
		EXCEPTION("java/lang/NullPointerException", "Cannot invoke a virtual method of a null object");
	} else {
		ASSERT(object->class);
		ASSERT(heap_find(heap, object->class->method_table));
		ASSERT(object->class->method_table[offset]);
		ASSERT(object->class->method_table[offset]->class);
		method_invoke(object->class->method_table[offset]->class, object, object->class->method_table[offset]);
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_INVOKE_SPECIAL:
_OPC_INVOKE_STATIC: {
	methodref_info_t *methodref;
	s2 index2;
	s2 name_index;
	char *class_name;
	char *method_name;
	char *signature;
	int type_index;
	class_t *inv_class;
	method_t *inv_method;
	constant_pool_t *cp;

	if ( opcode == OPC_INVOKE_STATIC )
		cp = method->class->constant_pool;
	else
		cp = class->constant_pool;
	
	READ_U2(index2, frame->cp);
	ASSERT(cp->tag[index2] == CONSTANT_MethodRef);
	methodref = (methodref_info_t*)cp->info[index2];
	ASSERT(cp->tag[methodref->class_index] == CONSTANT_Class);
	name_index = ((class_info_t*)(cp->info[methodref->class_index]))->name_index;
	ASSERT(cp->tag[name_index] == CONSTANT_Utf8);
	class_name = ((utf8_info_t*)(cp->info[name_index]))->string;
	ASSERT(cp->tag[methodref->name_type_index] == CONSTANT_NameAndType);
	name_index = ((name_type_info_t *)(cp->info[methodref->name_type_index]))->name_index;
	ASSERT(cp->tag[name_index] == CONSTANT_Utf8);
	method_name = ((utf8_info_t*)(cp->info[name_index]))->string;
	ASSERT(cp->tag[methodref->name_type_index] == CONSTANT_NameAndType);
	type_index = ((name_type_info_t *)(cp->info[methodref->name_type_index]))->signature_index;
	ASSERT(cp->tag[type_index] == CONSTANT_Utf8);
	signature = ((utf8_info_t *)(cp->info[type_index]))->string;
	heap_lock(heap);
	inv_class = class_resolve(class_name);
	heap_unlock(heap);
	ASSERT(inv_class);
	inv_method = method_resolve(inv_class, utf8_hash(method_name) ^ utf8_hash(signature));;
	if ( opcode == OPC_INVOKE_STATIC )
		inv_class = method->class;
	ASSERT(inv_method);
	method_invoke(inv_class, NULL, inv_method);

	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ABSTRACT_METHOD_ERROR:
	EXCEPTION("java/lang/RuntimeException", "Abstract method cannot be invoked");
	INTERP_NEXT();
