/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __INTERP_SWITCH_H__
#define __INTERP_SWITCH_H__

/**
 * @file switch.h
 *
 * Switching the interpreted opcodes in 'old-fashion' goto manner,
 * which seems to be faster
 *
 */

/**
 * Jump to the begining of the interpretation loop if active
 */
#define INTERP_NEXT()		{ goto INTERP_LOOP_BEGIN; }

/**
 * Case switch for all interpreded opcodes
 */
#define INTERP_SWITCH() 	{ goto *opcode_ptr[opcode]; }
 
void *opcode_ptr[256] = {
	&&_OPC_NOP,			&&_OPC_ACONST_NULL,		&&_OPC_ICONST_M1,		&&_OPC_ICONST_0,
	&&_OPC_ICONST_1,	&&_OPC_ICONST_2,		&&_OPC_ICONST_3,		&&_OPC_ICONST_4,
	&&_OPC_ICONST_5,	&&_OPC_LCONST_0,		&&_OPC_LCONST_1,		&&_OPC_FCONST_0,
	&&_OPC_FCONST_1,	&&_OPC_FCONST_2,		&&_OPC_DCONST_0,		&&_OPC_DCONST_1,
	&&_OPC_BIPUSH,		&&_OPC_SIPUSH,			&&_OPC_LDC,				&&_OPC_LDC_W,
	&&_OPC_LDC2_W,		&&_OPC_ILOAD,			&&_OPC_LLOAD,			&&_OPC_FLOAD,
	&&_OPC_DLOAD,		&&_OPC_ALOAD,			&&_OPC_ILOAD_0,			&&_OPC_ILOAD_1,
	&&_OPC_ILOAD_2,		&&_OPC_ILOAD_3,			&&_OPC_LLOAD_0,			&&_OPC_LLOAD_1,
	&&_OPC_LLOAD_2,		&&_OPC_LLOAD_3,			&&_OPC_FLOAD_0,			&&_OPC_FLOAD_1,
	&&_OPC_FLOAD_2,		&&_OPC_FLOAD_3,			&&_OPC_DLOAD_0,			&&_OPC_DLOAD_1,
	&&_OPC_DLOAD_2,		&&_OPC_DLOAD_3,			&&_OPC_ALOAD_0,			&&_OPC_ALOAD_1,
	&&_OPC_ALOAD_2,		&&_OPC_ALOAD_3,			&&_OPC_IALOAD,			&&_OPC_LALOAD,
	&&_OPC_FALOAD,		&&_OPC_DALOAD,			&&_OPC_AALOAD,			&&_OPC_BALOAD,
	&&_OPC_CALOAD,		&&_OPC_SALOAD,			&&_OPC_ISTORE,			&&_OPC_LSTORE,
	&&_OPC_FSTORE,		&&_OPC_DSTORE,			&&_OPC_ASTORE,			&&_OPC_ISTORE_0,
	&&_OPC_ISTORE_1,	&&_OPC_ISTORE_2,		&&_OPC_ISTORE_3,		&&_OPC_LSTORE_0,
	&&_OPC_LSTORE_1,	&&_OPC_LSTORE_2,		&&_OPC_LSTORE_3,		&&_OPC_FSTORE_0,
	&&_OPC_FSTORE_1,	&&_OPC_FSTORE_2,		&&_OPC_FSTORE_3,		&&_OPC_DSTORE_0,
	&&_OPC_DSTORE_1,	&&_OPC_DSTORE_2,		&&_OPC_DSTORE_3,		&&_OPC_ASTORE_0,
	&&_OPC_ASTORE_1,	&&_OPC_ASTORE_2,		&&_OPC_ASTORE_3,		&&_OPC_IASTORE,
	&&_OPC_LASTORE,		&&_OPC_FASTORE,			&&_OPC_DASTORE,			&&_OPC_AASTORE,
	&&_OPC_BASTORE,		&&_OPC_CASTORE,			&&_OPC_SASTORE,			&&_OPC_POP,
	&&_OPC_POP2,		&&_OPC_DUP,				&&_OPC_DUP_X1,			&&_OPC_DUP_X2,
	&&_OPC_DUP2,		&&_OPC_DUP2_X1,			&&_OPC_DUP2_X2,			&&_OPC_SWAP,
	&&_OPC_IADD,		&&_OPC_LADD,			&&_OPC_FADD,			&&_OPC_DADD,
	&&_OPC_ISUB,		&&_OPC_LSUB,			&&_OPC_FSUB,			&&_OPC_DSUB,
	&&_OPC_IMUL,		&&_OPC_LMUL,			&&_OPC_FMUL,			&&_OPC_DMUL,
	&&_OPC_IDIV,		&&_OPC_LDIV,			&&_OPC_FDIV,			&&_OPC_DDIV,
	&&_OPC_IREM,		&&_OPC_LREM,			&&_OPC_FREM,			&&_OPC_DREM,
	&&_OPC_INEG,		&&_OPC_LNEG,			&&_OPC_FNEG,			&&_OPC_DNEG,
	&&_OPC_ISHL,		&&_OPC_LSHL,			&&_OPC_ISHR,			&&_OPC_LSHR,
	&&_OPC_IUSHR,		&&_OPC_LUSHR,			&&_OPC_IAND,			&&_OPC_LAND,
	&&_OPC_IOR,			&&_OPC_LOR,				&&_OPC_IXOR,			&&_OPC_LXOR,
	&&_OPC_IINC,		&&_OPC_I2L,				&&_OPC_I2F,				&&_OPC_I2D,
	&&_OPC_L2I,			&&_OPC_L2F,				&&_OPC_L2D,				&&_OPC_F2I,
	&&_OPC_F2L,			&&_OPC_F2D,				&&_OPC_D2I,				&&_OPC_D2L,
	&&_OPC_D2F,			&&_OPC_I2B,				&&_OPC_I2C,				&&_OPC_I2S,
	&&_OPC_LCMP,		&&_OPC_FCMPL,			&&_OPC_FCMPG,			&&_OPC_DCMPL,
	&&_OPC_DCMPG,		&&_OPC_IFEQ,			&&_OPC_IFNE,			&&_OPC_IFLT,
	&&_OPC_IFGE,		&&_OPC_IFGT,			&&_OPC_IFLE,			&&_OPC_IF_ICMPEQ,
	&&_OPC_IF_ICMPNE,	&&_OPC_IF_ICMPLT,		&&_OPC_IF_ICMPGE,		&&_OPC_IF_ICMPGT,
	&&_OPC_IF_ICMPLE,	&&_OPC_IF_ACMPEQ,		&&_OPC_IF_ACMPNE,		&&_OPC_GOTO,
	&&_OPC_JSR,			&&_OPC_RET,				&&_OPC_TABLESWITCH,		&&_OPC_LOOKUP_SWITCH,
	&&_OPC_IRETURN,		&&_OPC_LRETURN,			&&_OPC_FRETURN,			&&_OPC_DRETURN,
	&&_OPC_ARETURN,		&&_OPC_RETURN,			&&_OPC_GET_STATIC,		&&_OPC_PUT_STATIC,
	&&_OPC_GET_FIELD,	&&_OPC_PUT_FIELD,		&&_OPC_INVOKE_VIRTUAL,	&&_OPC_INVOKE_SPECIAL,
	&&_OPC_INVOKE_STATIC,	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_NEW,
	&&_OPC_NEW_ARRAY,	&&_OPC_INVALID,			&&_OPC_ARRAY_LENGTH,	&&_OPC_ATHROW,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_IF_NULL,			&&_OPC_IF_NOT_NULL,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_GET_FIELD_QUICK,	&&_OPC_PUT_FIELD_QUICK,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVOKE_VIRTUAL_QUICK,	&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_ABSTRACT_METHOD_ERROR,	&&_OPC_INVALID,	&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID,
	&&_OPC_INVALID,		&&_OPC_INVALID,			&&_OPC_INVALID,			&&_OPC_INVALID
};

 
#endif /* __INTERP_SWITCH_H__ */
