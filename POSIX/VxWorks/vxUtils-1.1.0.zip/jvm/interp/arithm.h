_OPC_IADD:
	*(exec->sp-2) += *(exec->sp-1);
	exec->sp--;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_LADD: {
	s8 v1 = POP_LONG();
	s8 v2 = POP_LONG();
	PUSH_LONG(v1 + v2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_FADD:
	*(float *)(exec->sp-2) += *(float *)(exec->sp-1);
	exec->sp--;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_DADD: {
	s8 v1 = POP_LONG();
	s8 v2 = POP_LONG();
	double d = *(double *)&v1 + *(double *)&v2;
	PUSH_LONG(*(s8 *)&d);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ISUB:
	*(exec->sp-2) -= *(exec->sp-1);
	exec->sp--;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_LSUB: {
	s8 v1 = POP_LONG();
	s8 v2 = POP_LONG();
	PUSH_LONG(v2 - v1);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_FSUB:
	*(float *)(exec->sp-2) -= *(float *)(exec->sp-1);
	exec->sp--;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_DSUB: {
	s8 v1 = POP_LONG();
	s8 v2 = POP_LONG();
	double d = *(double *)&v2 - *(double *)&v1;
	PUSH_LONG(*(s8 *)&d);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IMUL:
	*(exec->sp-2) *= *(exec->sp-1);
	exec->sp--;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_LMUL: {
	s8 v1 = POP_LONG();
	s8 v2 = POP_LONG();
	PUSH_LONG(v2 * v1);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_FMUL:
	*(float *)(exec->sp-2) *= *(float *)(exec->sp-1);
	exec->sp--;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_DMUL: {
	s8 v1 = POP_LONG();
	s8 v2 = POP_LONG();
	double d = (*(double *)&v1) * (*(double *)&v2);
	PUSH_LONG(*(s8 *)&d);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IDIV:
	if ( 0 == *(exec->sp - 1) ) {
		EXCEPTION("java/lang/Exception", "Division by zero");
	} else
		*(exec->sp - 2) /= *(exec->sp-1);
	exec->sp--;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_LDIV: {
	EXCEPTION("java/lang/RuntimeException", "Division of longs is not implemented");
}

/* ------------------------------------------------------ */

_OPC_FDIV:
	*(float *)(exec->sp-2) /= *(float *)(exec->sp-1);
	exec->sp--;
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_DDIV: {
	s8 v1 = POP_LONG();
	s8 v2 = POP_LONG();
	double d = *(double *)&v2 / *(double *)&v1;
	PUSH_LONG(*(s8 *)&d);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IREM: {
	int a, b;
	b = POP_INT();
	a = POP_INT();
	if ( b == 0 ) {
		EXCEPTION("java/lang/Exception", "Division by zero");
	} else
		PUSH_INT(a % b);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_LREM: {
	EXCEPTION("java/lang/RuntimeException", "Division of longs by module is not implemented");
}

/* ------------------------------------------------------ */

_OPC_FREM: {
	float v1, v2, r;
	v1 = POP_FLOAT();
	v2 = POP_FLOAT();
	r = v2 - ((int)(v2/v1)) * v1;
	PUSH_FLOAT(r);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_DREM: {
	double v1, v2, r;
	*((long long *)&v1) = POP_LONG();
	*((long long *)&v2) = POP_LONG();
	r = v2 - ((int)(v2/v1)) * v1;
	PUSH_DOUBLE(r);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_INEG:
	*(exec->sp-1) = -*(exec->sp-1);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_LNEG: {
	s8 l = POP_LONG();
	PUSH_LONG(-l);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_FNEG:
	*(float *)(exec->sp-1) = - *(float *)(exec->sp-1);
	INTERP_NEXT();

/* ------------------------------------------------------ */

_OPC_DNEG: {
	s8 l = POP_LONG();
	double d = -*(double *)&l;
	PUSH_LONG(*(s8 *)&d);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ISHL: {
	s4 value;
	s4 shift;
	shift = POP_INT() & 0x0000001F;
	value = POP_INT();
	PUSH_INT(value << shift);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_ISHR: {
	s4 value;
	s4 shift;
	shift = POP_INT() & 0x0000001F;
	value = POP_INT();
	PUSH_INT(value >> shift);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IUSHR: {
	u4 value;
	s4 shift;
	shift = POP_INT() & 0x0000001F;
	value = (u4)POP_INT();
	PUSH_INT(value >> shift);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_LSHL:
_OPC_LSHR:
_OPC_LUSHR:
_OPC_LAND:
_OPC_LOR:
_OPC_LXOR:
	goto _OPC_INVALID;

/* ------------------------------------------------------ */

_OPC_IAND: {
	s4 v1, v2;
	v1 = POP_INT();
	v2 = POP_INT();
	PUSH_INT(v1 & v2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IOR: {
	s4 v1, v2;
	v1 = POP_INT();
	v2 = POP_INT();
	PUSH_INT(v1 | v2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IXOR: {
	s4 v1, v2;
	v1 = POP_INT();
	v2 = POP_INT();
	PUSH_INT(v1 ^ v2);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_IINC: {
	u1 index;
	char inc;
	READ_U1(index, frame->cp);
	inc = *((char *)frame->cp++);
	frame->locals[index] += (int)inc;
	INTERP_NEXT();
}
