_OPC_I2L: {
	s8 l = (s8)POP_INT();
	PUSH_LONG(l);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_I2F: {
	float f = (float)POP_INT();
	PUSH_FLOAT(f);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_I2D: {
	double d = (double)POP_INT();
	PUSH_LONG(*(s8 *)&d);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_L2I: {
	s4 i = (s4)POP_LONG();
	PUSH_INT(i);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_L2F: {
	s8 l = POP_LONG();
	float f = (float)l;
	PUSH_FLOAT(f);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_L2D: {
	s8 l = POP_LONG();
	double d = (double)l;
	PUSH_LONG(*(s8 *)&d);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_F2I: {
	s4 i = (s4)POP_FLOAT();
	PUSH_INT(i);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_F2L: {
	s8 l = (s8)POP_FLOAT();
	PUSH_LONG(l);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_F2D: {
	double d = (double)POP_FLOAT();
	PUSH_LONG(*(s8 *)&d);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_D2I: {
	double d;
	s8 l;
	s4 i;
	
	l = POP_LONG();
	d = *(double *)&l;
	i = (s4)d;
	PUSH_INT(i);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_D2L: {
	double d;
	s8 l;
	
	l = POP_LONG();
	d = *(double *)&l;
	l = (s8)d;
	PUSH_LONG(l);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_D2F: {
	double d;
	s8 l;
	float f;
	
	l = POP_LONG();
	d = *(double *)&l;
	f = (float)d;
	PUSH_FLOAT(f);
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_I2B: {
	int i = POP_INT();
	if ( i < 0 ) {
		i = -i;
		if ( i > 128 )
			PUSH_INT(-128);
		else
			PUSH_INT(-i);
	} else {
		if ( i > 127 )
			PUSH_INT(127);
		else
			PUSH_INT(i);
	}
	INTERP_NEXT();
}

/* ------------------------------------------------------ */

_OPC_I2C: 
_OPC_I2S: {
	*(exec->sp-1) &= 0x0000FFFF;
	INTERP_NEXT();
}
