/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_TYPES_H__
#define __JVM_TYPES_H__

/**
 * @file types.h
 *
 * Definition of internal types used by JVM
 */

#ifdef VXWORKS
#	include <vxWorks.h>
#endif


/** Boolean type **/
#ifndef FALSE
typedef enum { FALSE = 0, TRUE } bool_t;
#else
typedef int bool_t;
#endif

/** NULL pointer definition **/
#ifndef NULL
#   define NULL ((void*)0)
#endif

/** Counting type **/
typedef unsigned int count_t;

/** Size of an object **/
#ifndef VXWORKS
typedef unsigned int size_t;
#endif

/** Unsigned integer types **/
typedef unsigned long long int  u8;
typedef unsigned long int       u4;
typedef unsigned short int      u2;
typedef unsigned char           u1;

/** Signed integer types **/
typedef signed long long int    s8;
typedef signed long int         s4;
typedef signed short int        s2;
typedef signed char             s1;

/**
 * Macros for fetching integer values.
 * These are valid for IA-32 only!
 */
#define READ_U1(v,p)    v = *p++
#define READ_U2(v,p)    v = (p[0]<<8)|p[1]; p+=2
#define READ_U4(v,p)    v = (p[0]<<24)|(p[1]<<16)|(p[2]<<8)|p[3]; p+=4
#define READ_U8(v,p)    v = ((u8)p[0]<<56)|((u8)p[1]<<48)|((u8)p[2]<<40)| \
                            ((u8)p[3]<<32)|((u8)p[4]<<24)|((u8)p[5]<<16)| \
                            ((u8)p[6]<<8)|(u8)p[7]; p+=8



/**
 * Handling variable parameter lists
 */

#ifndef VXWORKS
/* In VxWorks va_list is defined in stdarg.h */

#ifndef __GNUC_VA_LIST

#define __GNUC_VA_LIST
typedef void *__gnuc_va_list;
typedef __gnuc_va_list va_list;
#define __va_rounded_size(TYPE)	\
	(((sizeof(TYPE) + sizeof(int) - 1) / sizeof(int)) * sizeof(int))
#define va_start(AP, LASTARG)	\
	(AP = ((__gnuc_va_list) __builtin_next_arg(LASTARG)))
#define va_end(AP)	\
	((void)0)
#define va_arg(AP, TYPE)	\
	(AP = (__gnuc_va_list) ((char *)(AP) + __va_rounded_size(TYPE)),	\
	*((TYPE *) (void *) ((char *)(AP) - __va_rounded_size(TYPE))))
#define __va_copy(dest, src)	\
	(dest) = (src)


#endif /* __GNUC_VA_LIST */

#endif VXWORKS

#endif /* __JVM_TYPES_H__ */
