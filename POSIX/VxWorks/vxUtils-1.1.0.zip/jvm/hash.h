/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_HASH_H__
#define __JVM_HASH_H__

/**
 * @file hash.h
 *
 * Handling hash tables
 */

 #include "types.h"
 #include "sync.h"

/**
 * Hash code definition
 */
typedef unsigned int hash_t;

/**
 * A hash table single element.
 * It associates some data with a hash code.
 */
typedef struct hash_entry_s {
    hash_t hash;    /** Hash code */
    void *data;     /** Some data */
} hash_entry_t;

/**
 * Hash table
 */
typedef struct hash_table_s {
    hash_entry_t    *entries;   /** Array of hash entries           */
    size_t          size;       /** Size of \c entries array        */
    count_t         count;      /** Number of used entries          */
    mutex_t         mutex;      /** Mutex to lock the hash table    */
} hash_table_t;

/**
 * Create an empty hash table that is capable
 * to store \a initial_size number of entries.
 *
 * @param initial_size Initial size of the hash table
 * @return pointer to a created hash table or NULL if any problems
 */
hash_table_t *hash_table_create ( size_t initial_size );

/**
 * Destroy hash table
 *
 * @param hash_table Pointer to a hash table to release
 */
void hash_table_release ( hash_table_t *hash_table );

/**
 * Lock hash table
 *
 * @param hash_table Pointer to a hash table
 */
void hash_table_lock ( hash_table_t *hash_table );

/**
 * Unlock hash table
 *
 * @param hash_table Pointer to a hash table
 */
void hash_table_unlock ( hash_table_t *hash_table );

/**
 * Resize hash table conserving all elements.
 * The size of a hash table can only be increased!
 *
 * @param hash_table Pointer to a hash table to be resized
 * @param new_size New size of a hash table
 */
void hash_table_resize ( hash_table_t *hash_table, size_t new_size );

/**
 * Find a hash table entry
 *
 * @param hash_table Pointer to a hash table
 * @param hash Hash code to look for
 * @return Hash table element of NULL if not found
 */
hash_entry_t *hash_table_find ( hash_table_t *hash_table, hash_t hash );

/**
 * Add a new element to the hash table if it is not already there.
 * If element with the same hash code is already in the
 * able, a corresponding hash table entry is returned (element is
 * not replaced by a new one).
 *
 * @param hash_table Pointer to a hash table
 * @param hash Hash code
 * @param data Pointer to some data
 * @return Hash table element with corresponding hash code
 */
hash_entry_t *hash_table_find_or_add ( hash_table_t *hash_table, hash_t hash, void *data );

/**
 * Remove element from a hash table
 *
 * @param hash_table Pointer to a hash table
 * @param hash Hash code of element to be removed
 */
void hash_table_delete ( hash_table_t *hash_table, hash_t hash );

#endif /* __JVM_HASH_H__ */

/* End of file */

