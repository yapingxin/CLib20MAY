/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <stdio.h>

#include "types.h"
#include "assert.h"
#include "exec.h"
#include "class.h"
#include "hash.h"
#include "utf8.h"
#include "sync.h"
#include "opcodes.h"
#include "method.h"

/**
 * Define TRACE_OPCODES macro will cause
 * dumping the bytecode along with execution.
 */
#undef TRACE_OPCODES


#ifdef TRACE_OPCODES
static int level = 0;
#endif

void method_invoke ( class_t *class, object_t *object, method_t *method ) {
    exec_t *exec;
	heap_t *heap;
    frame_t *frame;
    int sp_limit;       /* stack pointer limits */
    bool_t running;
	constant_pool_t *cp;
#ifdef TRACE_OPCODES
	int s, i;
#endif
	u1 opcode;

	/* Table of bytecode handlers */
	#include "interp/switch.h"	

    ASSERT(class);
	ASSERT(method);

    exec = exec_get();
	ASSERT(exec);
	heap = exec->heap;
	ASSERT(heap);
	ASSERT(exec->stack);

    /* lock synchronized method */
    if ( method->access_flags & ACC_SYNCHRONIZED ) {
        mutex_lock(&method->mutex); /** @todo Check if we need to lock the method or just an object */
        if ( object )
            mutex_lock(&object->mutex);
    }

    /* create frame for non-native methods */
    if ( !(method->access_flags & ACC_NATIVE) ) {
        frame = frame_create(method);
	} else {
    /* execute native method */
        ASSERT(method->native);
		/* printf("Call native %s.%s\n", class->name, method->name); */
		method->native();
        if ( method->access_flags & ACC_SYNCHRONIZED ) {
            mutex_unlock(&method->mutex);
            if ( object )
                mutex_unlock(&object->mutex);
        }
        return;
    }

	/* Class constant pool for easy access */
	cp = class->constant_pool;
	
    sp_limit = (int)(exec->sp);

#ifdef TRACE_OPCODES	
	for ( i = 0; i < level; i++ )
		printf("\t");
	printf("Call %s.%s\n", class->name, method->name);
	
	level++;
#endif
	
	/*
	 *  Execution loop
	 */
    running = TRUE;
	
INTERP_LOOP_BEGIN:
	if ( !running )
		goto INTERP_LOOP_END;
	
    /* check if stack pointer is within the limits */
    ASSERT((unsigned)exec->sp >= (unsigned)sp_limit);
	ASSERT((unsigned)exec->sp < sp_limit + exec->stack_size);

	ASSERT(frame == exec->frame);
		
	/* Handling exceptions */
	if ( exec->exception ) {
		int ex;
		int is_handler = FALSE;
		int _cp = frame->cp - method->code;
		
		/* Looking for exception handler */
		for ( ex = 0; ex < method->exception_table_size; ex++ ) {
			exception_t *exception_info = &(method->exception_table[ex]);
			if ( ((int)(exception_info->begin_pc) <= _cp) &&
			     ((int)(exception_info->end_pc) >= _cp) ) {
				int name_index;
				char *class_name;
				class_t *handler_class;
				int class_index = exception_info->catch_type;
				if ( 0 == class_index ) {
					is_handler = TRUE;
					PUSH_OBJECT(exec->exception);
					frame->cp = (u1 *)((int)(method->code + exception_info->handler_pc));
					exec->exception = NULL;
					break;
				}
				name_index = ((class_info_t *)(cp->info[class_index]))->name_index;
				class_name = ((utf8_info_t *)(cp->info[name_index]))->string;					
				heap_lock(heap);
				handler_class = class_resolve(class_name);
				heap_unlock(heap);
				if ( class_is_super(exec->exception->class, handler_class) ) {
					/* Handler is found */
					is_handler = TRUE;
					PUSH_OBJECT(exec->exception);
					frame->cp = (u1 *)((int)(method->code + exception_info->handler_pc));
					exec->exception = NULL;
					break;
				}
			}
		} /* for ( ex = 0; ex < method->exception_table_size; ex++ ) */

		if ( !is_handler ) {
			/* Move the exception to the upper frame */
			/* if ( NULL == frame->prev ) { */
				printf("Unhandled exception: %s at %s.%s%s\n", exec->exception->class->name,
					class->name, method->name, method->signature);
			/* } */
			running = FALSE;
			goto INTERP_LOOP_END;
		}
	} /* if ( exec->exception ) */
		
	ASSERT(frame);
	ASSERT(frame->cp >= method->code);
		
	/* Read the next bytecode */
	READ_U1(opcode, frame->cp);

#ifdef TRACE_OPCODES		
	for ( i = 0; i < level; i++ )
		printf("\t");
	printf("Opcode: %d\n", opcode);
#endif		
				
	/* Jump to the byte code interpreting section */
    INTERP_SWITCH();
		
#include "interp/stack.h"
		
#include "interp/arithm.h"		

#include "interp/conv.h"

#include "interp/comp.h"
		
#include "interp/return.h"
		
#include "interp/field.h"			
		
#include "interp/invoke.h"

#include "interp/object.h"

	/*
	 * Invalid or unsupported opcode detected
	 */
_OPC_INVALID:
	printf("In %s.%s():\n", class->name, method->name);
	printf("Opcode %d at 0x%08X\n", opcode, (unsigned int)frame->cp-1);                
	EXCEPTION("java/lang/RuntimeException", "Invalid opcode");
	running = FALSE;
	INTERP_NEXT();
		
	/*
	 * Out of the execution loop
	 */
INTERP_LOOP_END:

    if ( method->access_flags & ACC_SYNCHRONIZED ) {
    	/* Unblock stuff for synchronized methods */
        mutex_unlock(&method->mutex);
        if ( object )
            mutex_unlock(&object->mutex);
    }
    /* Dispose current frame and move back to previous */
    frame_release();

#ifdef TRACE_OPCODES	
	level--;
	/*
	for ( i = 0; i < level; i++ )
		printf("\t");
	if ( exec->frame )
		printf("Return to %s.%s from %s.%s\n", exec->frame->method->class->name, exec->frame->method->name,
			class->name, method->name);
	else
		printf("Return from %s.%s\n", class->name, method->name);
	*/
#endif
}

/* ------------------------------------------------------ */
/* End of file */
