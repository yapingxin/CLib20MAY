/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_GC_H__
#define __JVM_GC_H__

/**
 * @file gc.h
 *
 * Mark-and-sweep garbage collector implementation
 */
 
#include "exec.h"
 
/**
 * Run the garbage collecting on the specified execution environment
 *
 * @param exec Pointer to execution environment
 */
void gc_run ( exec_t *exec );

/**
 * Perform complete garbage-cleaning cycle
 */
void gc ( );

/**
 * Allocate memory from a heap specified
 * 
 * @param heap Pointer to a heap
 * @param size Number of bytes to allocate
 * @param flags Allocation flags
 * @return Pointer to allocated memory region
 */
void *gc_alloc ( heap_t *heap, unsigned int size, unsigned int flags );

/**
 * Release allocated memory
 *
 * @param heap Pointer to a heap
 * @param ptr Pointer to a memory region to be freed
 */
void gc_free ( heap_t *heap, void *ptr );

/**
 * Unreference pointer (decrement reference counter).
 * If the counter becomes 0, this function will
 * free the memory.
 *
 * @param heap Pointer to a heap
 * @param ptr Pointer to dereferece
 */
void gc_unref_ptr ( heap_t *heap, void *ptr );

/**
 * Unreference a set of pointers. A list of pointers
 * must be terminated by NULL (0x0).
 *
 * @param heap Pointer to a heap
 * @param ... List of pointer to be dereference
 */
void gc_unref ( heap_t *heap, ... );

/**
 * Assign one pointer to another. This will
 * perform automatic (de)referencing.
 *
 * @param heap Pointer to a heap
 * @param ptr Pointer to a pointer that will be rewritten
 * @param val A new pointer to assign
 */
void gc_set_ptr ( heap_t *heap, void **ptr, void *val );
 
/**
 * Memory macros
 */
#define SET(p1,p2)  {  \
        gc_set_ptr(heap, (void**)&(p1), (void*)(p2));   \
    }
    
#define NEW(t,flags) gc_alloc(heap, sizeof(t), flags)

#define ALLOC(size,flags) gc_alloc(heap, size, flags)
    
 
#endif /* __JVM_GC_H__ */

/* End of file */

