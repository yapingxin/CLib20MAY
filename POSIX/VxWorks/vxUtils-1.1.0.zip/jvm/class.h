/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_CLASS_H__
#define __JVM_CLASS_H__

/**
 * @file class.h
 *
 * Handle Java class file format
 */

#include "types.h"
#include "assert.h"
#include "hash.h"
#include "sync.h"
#include "native.h"

/**
 * Java class 'magic' identifier
 */
#define CLASS_MAGIC     0xCAFEBABE


/**
 * Access flags as defined in Java specification
 */
#define ACC_PUBLIC          0x0001  /* class, method, variable  */
#define ACC_PRIVATE         0x0002  /* method, variable         */
#define ACC_PROTECTED       0x0004  /* method, variable         */
#define ACC_STATIC          0x0008  /* method, variable         */
#define ACC_FINAL           0x0010  /* class, method, variable  */
#define ACC_SYNCHRONIZED    0x0020  /* method                   */
#define ACC_VOLATILE        0x0040  /* variable (cannot cache)  */
#define ACC_TRANSIENT       0x0080  /* variable (not to be writen or read
                                       by a persistent  object manager */
#define ACC_NATIVE          0x0100  /* method                   */
#define ACC_INTERFACE       0x0200  /* class                    */
#define ACC_ABSTRACT        0x0400  /* class, method            */

/**
 * Java types signatures
 */
#define SIG_BYTE        'B'
#define SIG_CHAR        'C'
#define SIG_DOUBLE      'D'
#define SIG_FLOAT       'F'
#define SIG_INT         'I'
#define SIG_LONG        'J'
#define SIG_OBJECT      'L'
#define SIG_SHORT       'S'
#define SIG_BOOLEAN     'Z'
#define SIG_ARRAY       '['

/**
 * Java types indices (used for array creation)
 */
#define T_BOOLEAN       4
#define T_CHAR          5
#define T_FLOAT         6
#define T_DOUBLE        7
#define T_BYTE          8
#define T_SHORT         9
#define T_INT           10
#define T_LONG          11
#define T_OBJECT        13 /* Not defined in Java specification */

/**
 * Sizes (in bytes) of different Java types
 */
#define SIZE_BYTE       1
#define SIZE_CHAR       2
#define SIZE_DOUBLE     8
#define SIZE_FLOAT      4
#define SIZE_INT        4
#define SIZE_LONG       8
#define SIZE_OBJECT     4
#define SIZE_SHORT      2
#define SIZE_BOOLEAN    2
#define SIZE_ARRAY      SIZE_OBJECT /* Arrays are objects in Java */

/**
 * Java class constant pool tags
 */
#define CONSTANT_Utf8               1
#define CONSTANT_Unicode            2
#define CONSTANT_Integer            3
#define CONSTANT_Float              4
#define CONSTANT_Long               5
#define CONSTANT_Double             6
#define CONSTANT_Class              7
#define CONSTANT_String             8
#define CONSTANT_FieldRef           9
#define CONSTANT_MethodRef          10
#define CONSTANT_InterfaceMethodRef 11
#define CONSTANT_NameAndType        12


/**
 * Forward declaracion of the \c class_t type
 */
struct class_s;
typedef struct class_s class_t;

/**
 * Constant pool
 */
typedef struct constant_pool_s {
    u2      count;  /* number of constants in this pool     */
    u1      *tag;   /* array of tags                        */
    void    **info; /* array of pointers to constant info   */
} constant_pool_t;

/** Class information */
typedef struct class_info_s {
    u2 name_index;  /* index of utf8_info */
} class_info_t;

/** Field reference */
typedef struct fieldref_info_s {
    u2 class_index; /* index of class_info */
    u2 name_type_index; /* index of name_type_info */
} fieldref_info_t;

/** Method reference */
typedef struct methodref_info_s {
    u2 class_index;     /* index of class_info */
    u2 name_type_index; /* index of name_type_info */
} methodref_info_t;

/** Interface method reference */
typedef struct interface_methodref_info_s {
    u2 class_index;     /* index of class_info */
    u2 name_type_index; /* index of name_type_info */
} interface_methodref_info_t;

/** String information */
typedef struct string_info_s {
    u2 string_index;    /* index of utf8_info */
} string_info_t;

/** Integer information */
typedef struct integer_info_s {
    int value;  /* Signed integer value */
} integer_info_t;

/** Float information */
typedef struct float_info_s {
    float value;
} float_info_t;

/** Long information */
typedef struct long_info_s {
    long long value;
} long_info_t;

/** Double information */
typedef struct double_info_s {
    double value;
} double_info_t;

/** Signature string */
typedef struct name_type_info_s {
    u2 name_index;  /* index of utf8_info */
    u2 signature_index; /* index of utf8_info */
} name_type_info_t;

/** UTF8 string information */
typedef struct utf8_info_s {
    u2 length;  /* length of the string in bytes */
    char *string;   /* UTF8 string */
} utf8_info_t;

/**
 * Field definition
 */
typedef struct field_info_s {
    u2      access_flags;   /** Access flags                    */
    char    *name;          /** Field name                      */
    char    *signature;     /** Field signature                 */
    u2      constant;       /** Constant value                  */
    /* = constant_pool->info[constant].value */
    u4      static_value;   /** Static value of the field       */
    u4      offset;         /** Field offset in objects data    */
    /* This field is also used for 2nd (high) 32-bits value
     * for satic fields.
     */
} field_t;

/**
 * Exception definiton
 */
typedef struct excepion_info_s {
    u2      begin_pc;   /** Code pointer begin value                */
    u2      end_pc;     /** Code pointer end value                  */
    u2      handler_pc; /** Code pointer of a handler               */
    u2      catch_type; /** Exception class index in constant_pool  */
    /* If \c catch_type value is zero, the handler should be called
     * for any exception
     */
} exception_t;

/**
 * Method definiton
 */
typedef struct method_info_s {
    u2      access_flags;   /** Access flags                                            */
    char    *name;          /** Method name                                             */
    char    *signature;     /** Method signature                                        */
    class_t *class;         /** Class this methos belongs to                            */
    hash_t  hash;           /** Hash code of the method                                 */
    u2      max_stack;      /** Stack size required for this method execution           */
    u2      max_locals;     /** Number of 32-bits slots reserved for local variables    */
    u4      code_length;    /** Bytecode size in bytes                                  */
    u1      *code;          /** Bytecode                                                */
    u2      exception_table_size; /** Number of exception handlers                      */
    exception_t *exception_table;  /** Table of exception handlers                      */
    u2      throw_table_size;   /** Number of exceptions this method throws             */
    u2      *throw_table;   /** Array of exception indices of \c class_info_s           */
    u2      args_count;     /** Number of arguments                                     */
    native_func_t   native; /** Native function for native methods                      */
    u2      index;          /** Index in class methods table                            */
    mutex_t mutex;          /** Mutex to lock the method                                */
} method_t;

/**
 * Class states
 */
typedef enum {
    CLASS_STATE_LOADING,    /** Class is loading                        */
    CLASS_STATE_LOADED,     /** Class is loaded but not linked yet      */
    CLASS_STATE_LINKING,    /** Class is linking                        */
    CLASS_STATE_LINKED,     /** Class is linked and ready for use       */
    CLASS_STATE_INVALID     /** Class was not loaded or linked properly */
} class_state_t;

/**
 * Java class definition
 */
struct class_s {
    char            *name;              /** Class name                                      */
    class_t         *super;             /** Superclass                                      */
    constant_pool_t *constant_pool;     /** Constant pool                                   */
    u2              access_flags;       /** Class access flags                              */
    u2              interfaces_count;   /** Number of interfaces implemented by this class  */
    class_t         **interfaces;       /** Array of interfaces                             */
    u2              fields_count;       /** Number of fields                                */
    field_t         *fields;            /** Array of fields                                 */
    u2              methods_count;      /** Number of methods                               */
    method_t        *methods;           /** Array of methods                                */

    /* Information used for class linking */
    class_state_t   state;
    hash_t          hash;
    size_t          object_size;        /** Size of object of this class (non-static fields) */
    u2              method_table_size;  /** Table of virtual methods    */
    method_t        **method_table;
};

/**
 * Java object
 */
typedef struct object_s {
    class_t		*class;		/** Class of the object	*/
    u1			*data;		/** Object data (fields)	*/
	size_t		data_size;	/** Size of the data		*/
    u1			array_type;	/** T_xxx value that defined array element type for array objects   */
    count_t		array_length;	/** Number of elements in array object                              */
    mutex_t		mutex;		/** Mutex for locking the object    */
	waitq_t		waitq;		/** Waiting queue			*/
} object_t;

/**
 * Parsing Java signature string
 */
#define SCAN_SIG(p, D, S)			        		\
   p++;               /* skip start '(' */		\
   while(*p != ')') {				        	\
       if((*p == 'J') || (*p == 'D')) {		\
          D;				                \
          p++;				                \
      } else {				                \
          S;				                \
          if(*p == '[')				        \
              for(p++; *p == '['; p++);		\
          if(*p == 'L')				        \
              while(*p++ != ';');   	    	\
          else					            \
              p++;			            	\
      }						                \
   }						                \
   p++;               /* skip end ')' */

/**
 * Parse Java class file format data to
 * create a class.
 *
 * @param name Class name (may be NULL)
 * @param data Pointer to raw Java class format data
 * @return Pointer to Java class or NULL
 */
class_t *class_define ( const char *name, void *data );

/**
 * Prepare just loaded class
 *
 * @param class Pointer to loaded class
 */
void class_link ( class_t *class );

/**
 * Load and link class using embedded system loader
 *
 * @param name Class name
 * @param data Pointer to raw class data
 * @return Pointer to loaded class
 */
class_t *class_load_system ( char *name, void *data );

/**
 * Resolve a class by its name
 *
 * The class resolving may cause the class loading
 * from the classpath. In this case a heap memory will be
 * allocated for the class data and execution of the
 * <cinit> method. So, the heap should be locked
 * before calling this function.
 * If the class was already resolved, it is put into the
 * resolved classes hash table (of the current execution
 * environment), and thus, will not be loaded from classpath
 * again.
 *
 * @param name Class name
 * @return Java class or NULL if cannot be resolved
 */
class_t *class_resolve ( char *name );

/**
 * Resolving method
 *
 * This function browses the methods table of the class
 * in order to find a requested method. Parent classes are
 * not browsed, since its public methods were transfered
 * to the methods table during the class linkage phase.
 *
 * @param class Class to be used for method search
 * @param hash Method hash code
 * @return Pointer to method or NULL if cannot be resolved
 */
method_t *method_resolve ( class_t *class, hash_t hash );


/**
 * Resolving field
 *
 * @param class Class to be used for field search
 * @param name Field name
 * @return Pointer to field or NULL if cannot be resolved
 */
field_t *field_resolve ( class_t *class, char *name );

/**
 * Check if a class is a subclass of a certain parent class
 *
 * @param class Class to be checked
 * @param parent Superclass
 * @return TRUE if \a class is a subclass of \a parent
 */
bool_t class_is_super ( class_t *class, class_t *parent );

/**
 * Check if a class implements a certain interface
 *
 * @param class Class to be checked
 * @param interface Interface class
 * @return TRUE if \a class implements \a interface
 */
bool_t class_implements ( class_t *class, class_t *interface );

/**
 * Create a new object of a class
 * This function does not call the constructor for
 * the created object, as far as it may have several
 * of them.
 *
 * @param class Pointer to a class
 * @return New object
 */
object_t *object_new ( class_t *class );

/**
 * Create a new 1D array object (class java.lang.Array)
 *
 * @param type Array element type (T_...)
 * @param length number of elements to be created
 * @return New array object
 */
object_t *object_new_array ( u1 type, count_t length );

/**
 * Create a Java String from a C-style zero-terminated string
 *
 * @param str Pointer to a set of 8-bit characters terminated by '\0'
 * @return New Java string object
 */
object_t *object_new_string ( char *str );

/**
 * Create a java.lang.Class object for the class specified
 *
 * @param class Pointer to class
 * @return java.lang.Class object reference
 */
object_t *object_new_class ( class_t *class );

/**
 * Create an exception object  with a specified message
 *
 * @param class Pointer to the Exception class (or subclass)
 * @param str Pointer to a set of 8-bit characters terminated by '\0'
 *            describing the exception.
 * @return New exception object
 */
object_t *object_new_exception ( class_t *class, char *str );

/**
 * Create an object's clone
 * A clone object is an exact copy of the initial object
 *
 * @param object Pointer to an object to clone
 * @return New clone object
 */
object_t *object_clone ( object_t *object );

#endif /* __JVM_CLASS_H__ */
