/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_LOADER_H__
#define __JVM_LOADER_H__

/**
 * @file loader.h
 *
 * Loading system Java classes (bootstrap loader)
 */

/**
 * Initialize class loader
 *
 * @param path Path to classpath.jar and other java classes
 */
void loader_init ( const char *path );

/**
 * Load Java class into memory
 *
 * @param class_name Full name of the class to be loaded
 * @return Pointer to the class raw data
 */
void *load_class ( const char *class_name );

/**
 * Release all memory allocated by loader
 * JVM may keep working after calling this function however
 * unloaded classes will not be resolved.
 */
void loader_release ( );

#endif /* __JVM_LOADER_H__ */

/* End of file */

