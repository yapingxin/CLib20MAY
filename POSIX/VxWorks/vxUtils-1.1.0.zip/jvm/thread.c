/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifdef VXWORKS
#	include <vxWorks.h>
#	include <sysLib.h>
#endif

#include <stdlib.h>
#include <stdio.h>

#include "assert.h"
#include "alloc.h"
#include "utf8.h"
#include "method.h"
#include "sync.h"
#include "thread.h"

#define THREAD_STACK_SIZE	(16*1024)

/**
 * Linked list of Java threads
 */
static java_thread_t *java_threads = NULL;

static mutex_t java_threads_mutex;

/* ------------------------------------------------------ */

void java_thread_init ( size_t stack_size, size_t heap_size ) {
	ASSERT(stack_size > 0);
    ASSERT(heap_size > 0);
	ASSERT(java_threads == NULL);
	
    java_threads = (java_thread_t *)jvm_alloc(sizeof(java_thread_t));
    java_threads->parent = NULL;
    java_threads->next = NULL;
#ifdef VXWORKS
	java_threads->system_thread = taskTcb(taskIdSelf());
#else
    java_threads->system_thread = pthread_self();
#endif
	/* By default the java thread object is null.
	 * This means that the thread is not actually initialized
	 * or even it does not exists. The execution is done in the
	 * C-application thread.
	 */
    java_threads->thread_object = NULL;
    java_threads->exec = exec_create(heap_size);
    java_threads->exec->stack = (s4 *)jvm_alloc(sizeof(s4) * stack_size);
    java_threads->exec->sp = java_threads->exec->stack;
	java_threads->exec->stack_size = stack_size;

    mutex_init(&java_threads_mutex);
}

/* ------------------------------------------------------ */

void java_threads_lock ( ) {
    mutex_lock(&java_threads_mutex);
}

/* ------------------------------------------------------ */

void java_threads_unlock ( ) {
    mutex_unlock(&java_threads_mutex);
}

/* ------------------------------------------------------ */

java_thread_t *java_thread_self ( ) {
#ifdef VXWORKS
	WIND_TCB *thread = taskTcb(taskIdSelf());
#else
    pthread_t thread = pthread_self();
#endif
    java_thread_t *java_thread = java_threads;
    while ( java_thread ) {
        if ( java_thread->system_thread == thread )
            return java_thread;
        java_thread = java_thread->next;
    }
    return NULL;
}

/* ------------------------------------------------------ */

int java_thread0 ( java_thread_t *java_thread ) {
    method_t *method;

    ASSERT(java_thread != NULL);

    /* looking for run() method */
    method = method_resolve(java_thread->thread_object->class, utf8_hash("run") ^ utf8_hash("()V"));
    if ( method ) {
        exec_t *exec = java_thread->exec;
        PUSH_OBJECT(java_thread->thread_object);
        method_invoke(java_thread->thread_object->class, java_thread->thread_object, method);
    } else {
		/* There is no reason to throw an exception here, since
		 * the thread is not runnig. So, we report a fatal error
		 */
		PANIC("Class does not implement run() method");
    }

	/* Release the allocated stack */
	jvm_free(java_thread->exec->stack);
	
    /* removing thread from the list of threads */
    if ( java_thread == java_threads ) {
        java_threads = java_threads->next;
    } else {
        java_thread_t *thread;

        java_threads_lock();
        thread = java_threads;
        while ( thread->next != NULL ) {
            if ( thread->next == java_thread )
                thread->next = java_thread->next;
            thread = thread->next;
        }
        java_threads_unlock();
    }
	
	/**
	 * @todo
	 * Here we have to check if all threads are terminated. And if so, 
	 * deallocate the heap
	 */
	
	return 0;
}

/* ------------------------------------------------------ */

java_thread_t *java_thread_create ( java_thread_t *parent, object_t *thread_object, size_t stack_size, size_t heap_size ) {
    java_thread_t *thread;

    ASSERT(thread_object != NULL);
    ASSERT(stack_size > 0);

    thread = (java_thread_t *)jvm_alloc(sizeof(java_thread_t));
    if ( parent ) {
        /* new thread shares hash tables and heap with a parent */
        thread->exec = (exec_t *)jvm_alloc(sizeof(exec_t));
        thread->exec->hash_table_utf8 = parent->exec->hash_table_utf8;
        thread->exec->hash_table_class = parent->exec->hash_table_class;
        thread->exec->heap = parent->exec->heap;
        thread->exec->frame = NULL;
        thread->exec->exception = NULL;
    } else {
		ASSERT(heap_size > 4);
        thread->exec = exec_create(heap_size);
	}

    thread->thread_object = thread_object;

    /* stack */
    thread->exec->stack = (s4 *)jvm_alloc(sizeof(s4) * stack_size);
	thread->exec->stack_size = stack_size;
    thread->exec->sp = thread->exec->stack;

	waitq_init(&thread->waitq);
	
    /* add this thread to the list of threads */
    java_threads_lock();
    thread->next = java_threads;
    java_threads = thread;
    java_threads_unlock();

    /* Pushing Thread object on stack */
    *(thread->exec->sp++) = (s4)thread_object;

    /* Creating a system thread */
#ifdef VXWORKS
	thread->system_thread = taskTcb(
			taskSpawn(thread_object->class->name, 100, 0, THREAD_STACK_SIZE, java_thread0, thread,
				0, 0, 0, 0, 0, 0, 0, 0, 0)
		);
#else	
    pthread_create(&thread->system_thread, NULL, (void*)&java_thread0, thread);
#endif

    return thread;
}

/* ------------------------------------------------------ */

java_thread_t *java_thread_all ( ) {
	return java_threads;
}

/* ------------------------------------------------------ */

bool_t java_thread_sleep ( int timeout ) {
	java_thread_t *java_thread = java_thread_self();		
	
/* NOTE:
 * If we do not have any threads running, the semaphores
 * waiting will not give any effect. For this reason we
 * use system sleep() routine. In this case sleep cannot
 * be interrupted.
 */ 
	
#ifdef VXWORKS
	int ticks = sysClkRateGet() * timeout / 1000;
	if ( !java_thread->thread_object ) {
		taskDelay(ticks);
		return TRUE;
	}
	if ( OK == semTake(java_thread->waitq, ticks) )
		return FALSE;
	return TRUE;
	
#else

	if ( !java_thread->thread_object ) {
		usleep(timeout * 1000);
		return TRUE;
	}
	if ( 0 != waitq_wait(&java_thread->waitq, timeout) )
		return FALSE;
	return TRUE;
#endif
}

/* ------------------------------------------------------ */

void java_thread_wakeup ( java_thread_t *java_thread ) {
#ifdef VXWORKS
	semGive(java_thread->waitq);
#else	
	waitq_unblock_all(&java_thread->waitq);
#endif
}

/* ------------------------------------------------------ */

void java_thread_yield ( ) {
#ifdef VXWORKS
	taskDelay(0);
#else
	sched_yield();
#endif	
}

/* ------------------------------------------------------ */

java_thread_t *java_thread_get ( object_t *thread_object ) {
	java_thread_t *thread = java_threads;
	while ( thread ) {
		if ( thread->thread_object == thread_object )
			return thread;
		thread = thread->next;
	}
	return NULL;
}

/* ------------------------------------------------------ */
/* End of file */

