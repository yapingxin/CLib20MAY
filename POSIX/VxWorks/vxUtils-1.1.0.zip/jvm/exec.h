/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#ifndef __JVM_EXEC_H__
#define __JVM_EXEC_H__

/**
 * @file exec.h
 *
 * Java bytecode execution environment
 */

#include "types.h"
#include "class.h"
#include "hash.h"
#include "heap.h"

typedef struct frame_s frame_t;
struct frame_s {
	u1			*cp;			/** Code pointer            */
	s4			*locals;		/** Local variables         */
	frame_t		*prev;			/** Previous frame          */
	method_t	*method;		/** Method being executed   */
};

/**
 * Initial sized for the hash tables
 */
#define HASH_UTF8_SIZE      256
#define HASH_CLASS_SIZE     128

/**
 * Execution environment
 */
typedef struct exec_s {
    hash_table_t	*hash_table_utf8;	/** Strings hashes		*/
    hash_table_t	*hash_table_class;	/** Classes hashes		*/
    heap_t			*heap;				/** Memory heap			*/
    s4				*stack;				/** Stack				*/
    size_t			stack_size;			/** Stack size			*/
    s4				*sp;				/** Stack pointer		*/
    object_t		*exception;			/** Exception			*/
    frame_t			*frame;				/** Execution frame		*/
} exec_t;

/**
 * Some useful stack operations
 */
#define POP_INT()       ((s4)*(--(exec->sp)))
#define POP_FLOAT()     (*((float*)(--(exec->sp))))
#define POP_LONG()      ((s8)*(--(exec->sp))) | (((s8)*(--(exec->sp))) << 32)
#define POP_OBJECT()    ((object_t *)*(--(exec->sp)))

#define PUSH_INT(v)     *(exec->sp++)=(s4)(v)
#define PUSH_FLOAT(v)   *((float*)(exec->sp++))=(v)
#define PUSH_LONG(v)    *(exec->sp++)=(s4)((v)>>32); *(exec->sp++)=(s4)(v)
#define PUSH_OBJECT(v)  *(exec->sp++)=(s4)(v)
#define PUSH_DOUBLE(v)	{	\
	long long l;			\
	*((double *)&l) = v;	\
	PUSH_LONG(l);			\
}
	

/**
 * Throwing exceptions;
 */
#define THROW(object)	{			\
	exec_t *exec = exec_get();		\
	heap_lock(exec->heap);			\
	exec_throw_exception(object);	\
	heap_unlock(exec->heap);		\
}

#define EXCEPTION(class,message)	{	\
	exec_t *exec = exec_get();			\
	heap_lock(exec->heap);				\
	exec_throw_exception(object_new_exception(class_resolve(class), message));	\
	heap_unlock(exec->heap);			\
}
 
 
/**
 * Create a new execution frame.
 * A new execution frame is created every time a method is called.
 * When method returns, the corresponding execution frame is released.
 *
 * @param method Method that will be executed
 * @return New execution frame
 */
frame_t *frame_create ( method_t *method );

/**
 * Detele execution frame.
 * The frame is deleted when method returns.
 */
void frame_release ( );

/**
 * Create a new execution environment
 *
 * @param heap_size Heap size for the new environment
 * @return Pointer to new execution environment
 */
exec_t *exec_create ( size_t heap_size );


/**
 * Destroy an execution environment.
 * The root method should return and no unhandled exceptions.
 *
 * @param exec Pointer to execution environment
 */
void exec_release ( exec_t *exec );

/**
 * Returns execution environment of the current thread
 */
exec_t *exec_get ( );

/**
 * Throw exception
 */
void exec_throw_exception ( object_t *exception );

#endif /* __JVM_EXEC_H__ */

/* End of file */

