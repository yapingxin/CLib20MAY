/* Copyright (C) 2008, Arthur Benilov

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.
*/

#include <stdlib.h>
#include <stdio.h>
#include "assert.h"
#include "sync.h"

void mutex_init ( mutex_t *mutex ) {
#ifdef VXWORKS
    *mutex = semMCreate(SEM_Q_PRIORITY | SEM_INVERSION_SAFE | SEM_DELETE_SAFE);
#else
    pthread_mutexattr_t attr;
    
    ASSERT(!pthread_mutexattr_init(&attr));
#ifndef __CYGWIN__
    ASSERT(!pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP));
#else
    ASSERT(!pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE));
#endif
    ASSERT(!pthread_mutex_init (mutex, &attr));
    
    ASSERT(!pthread_mutexattr_destroy(&attr));
    
#endif /* VXWORKS */
}

/* ------------------------------------------------------ */

void mutex_release ( mutex_t *mutex ) {
#ifdef VXWORKS
	semDelete(*mutex);
#else
    pthread_mutex_unlock(mutex);
#endif
}

/* ------------------------------------------------------ */

void mutex_lock ( mutex_t *mutex ) {
#ifdef VXWORKS
	semTake(*mutex, WAIT_FOREVER);
#else
    ASSERT(!pthread_mutex_lock(mutex));
#endif
}

/* ------------------------------------------------------ */

bool_t mutex_try_lock ( mutex_t *mutex ) {
#ifdef VXWORKS
	if ( OK != semTake(*mutex, NO_WAIT) )
#else
    if ( pthread_mutex_trylock(mutex) != 0 )
#endif
        return FALSE; /* Mutex is busy and cannot be locked */
    return TRUE; /* Mutex is now locked */
}

/* ------------------------------------------------------ */

void mutex_unlock ( mutex_t *mutex ) {
#ifdef VXWORKS
	semGive(*mutex);
#else
    ASSERT(!pthread_mutex_unlock(mutex));
#endif
}

/* ------------------------------------------------------ */

void waitq_init ( waitq_t *waitq ) {
#ifdef VXWORKS
	*waitq = semCCreate(SEM_Q_PRIORITY, 0);
#else
	/*
	waitq->mutex = PTHREAD_MUTEX_INITIALIZER;
	waitq->cond = PTHREAD_COND_INITIALIZER;
	*/
	ASSERT(!pthread_mutex_init (&waitq->mutex, NULL));
	ASSERT(!pthread_cond_init(&waitq->cond, NULL));
#endif
}

/* ------------------------------------------------------ */

void waitq_release ( waitq_t *waitq ) {
	waitq_unblock_all(waitq);
#ifdef VXWORKS
	semDelete(*waitq);
#else
	mutex_release(&waitq->mutex);
#endif
}

/* ------------------------------------------------------ */

int waitq_wait ( waitq_t *waitq, int ticks ) {
#ifdef VXWORKS
	/** @todo convert ms to vxWorks ticks */
	return semTake(*waitq, ticks);
#else
	int res;
	struct timespec timeout;
	gettimeofday(&timeout, NULL);
	timeout.tv_sec += ticks/1000;
	timeout.tv_nsec += (ticks % 1000) * 1000000;
	mutex_lock(&waitq->mutex);
	res = pthread_cond_timedwait(&waitq->cond, &waitq->mutex, &timeout);
	mutex_unlock(&waitq->mutex);
	return res;
#endif
}

/* ------------------------------------------------------ */

void waitq_unblock ( waitq_t *waitq ) {
#ifdef VXWORKS
	semGive(*waitq);
#else
	pthread_cond_signal(&waitq->cond);
#endif
}

/* ------------------------------------------------------ */

void waitq_unblock_all ( waitq_t *waitq ) {
#ifdef VXWORKS
	semFlush(*waitq);
#else
	pthread_cond_broadcast(&waitq->cond);
#endif
}

