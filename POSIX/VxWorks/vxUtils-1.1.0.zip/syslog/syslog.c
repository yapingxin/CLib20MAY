/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

#include <vxWorks.h>
#include <stdio.h>
#include <stdlib.h>
#include <tickLib.h>
#include <sockLib.h>
#include <inetLib.h>
#include <hostLib.h>
#include <sysLib.h>
#include <ioLib.h>
#include <msgQLib.h>
#include <taskLib.h>
#include <iosLib.h>
#include <errnoLib.h>
#include <logLib.h>
#include <timers.h>

#include "syslog.h"

/**
 * Logging task parameters
 */
#define SYSLOG_QUEUE_LENGTH     100     /* Message queue length             */
#define SYSLOG_QUEUE_TIMEOUT    5       /* Timeout, ticks                   */
#define SYSLOG_MSG_LENGTH       1280    /* Max bytes in a single message    */
#define SYSLOG_PRIORITY         1       /* Logging task priority            */
#define SYSLOG_STACK            4096    /* Logging task stack size          */

#define SYSLOG_HOST             "SYSLOG_HOST"
#define SYSLOG_PORT             "SYSLOG_PORT"
#define SYSLOG_DEV_NAME         "/syslog"    /* device driver name */

#define NATIVE_MSG(args...)     printf(## args)

static char hostname[128];
static MSG_Q_ID msgLogQId   = NULL;
static int msgLogTaskId     = 0;
static int msgSocket        = 0;
static struct sockaddr_in msgServerAddr;

/**
 * Default severity and facility when
 * using logMsg redirection
 */
static int logMsg_facility;
static int logMsg_severity;

static int syslogFd         = ERROR;    /* logMsg() redirection file descriptor */
static int stdioFd          = ERROR;    /* stdio file descriptor */

/**
 * The following structure described syslog device
 */
typedef struct {
    DEV_HDR     devHdr; 
    unsigned    numOpens;
} SYSLOG_DEV;

static int syslogDrvNum = ERROR;    /* Driver number of syslog driver */

/**
 * The following functions compose syslog device interface.
 * Syslog device can be opened for writing and closed.
 */
static int syslogOpen ( SYSLOG_DEV *dev, char *name, int flags, int mode );
static int syslogClose ( SYSLOG_DEV *dev );
static int syslogWrite ( SYSLOG_DEV *dev, char *buffer, int  nbytes );

/* ------------------------------------------------------ */
/**
 * Installing syslog driver
 */
STATUS syslogDrv ( void ) {

    if ( syslogDrvNum == ERROR ) {
        syslogDrvNum = iosDrvInstall(
                (FUNCPTR)NULL,  /* create */
                (FUNCPTR)NULL,  /* remove */
                syslogOpen,     /* open */
                syslogClose,    /* close */
                (FUNCPTR)NULL,  /* read */
                syslogWrite,    /* write */
                (FUNCPTR)NULL   /* ioctl */
            );
    }
    return (syslogDrvNum == ERROR ? ERROR : OK);
}

/* ------------------------------------------------------ */
/**
 * Create /dev/syslog device
 */
STATUS syslogDevCreate ( void ) {
    SYSLOG_DEV *pSyslogDev;

    if ( syslogDrvNum == ERROR ) {
        NATIVE_MSG("%s: syslog driver is not isntalled\n", __FUNCTION__);
        errnoSet(S_ioLib_NO_DRIVER);
        return ERROR;
    }
    
    pSyslogDev = (SYSLOG_DEV *) malloc((unsigned)sizeof(SYSLOG_DEV));
    if ( pSyslogDev == NULL )
        return ERROR;
    
    pSyslogDev->numOpens = 0;
    
    /* I/O device */
    if ( iosDevAdd(&pSyslogDev->devHdr, SYSLOG_DEV_NAME, syslogDrvNum) != OK ) {
        NATIVE_MSG("%s: iosDevAdd failed: %s\n", __FUNCTION__, strerror(errno));
        return ERROR;
    }
    
    return OK;
}

/* ------------------------------------------------------ */
/**
 * Delete /dev/syslog device
 */
STATUS syslogDevDelete ( void ) {
    SYSLOG_DEV *pSyslogDev;
    char *pTail = NULL;
    
    if ( syslogDrvNum == ERROR ) {
        NATIVE_MSG("%s: syslog driver is not isntalled\n", __FUNCTION__);
        errnoSet(S_ioLib_NO_DRIVER);
        return ERROR;
    }
    
    if ( (pSyslogDev = (SYSLOG_DEV *)iosDevFind(SYSLOG_DEV_NAME, &pTail)) == NULL ) {
        NATIVE_MSG("%s: syslog device cannot be found\n", __FUNCTION__);
        return ERROR;
    }
    
    iosDevDelete(&pSyslogDev->devHdr);
    free((char *)pSyslogDev);
    
    return OK;
}

/* ------------------------------------------------------ */
/**
 * Open syslog device
 */
static int syslogOpen ( SYSLOG_DEV *dev, char *name, int flags, int mode ) {
    (void)flags;
    (void)mode;
    
    if ( (name != NULL) && (strlen(name) > 0) ) {
        errnoSet(S_ioLib_NO_DEVICE_NAME_IN_PATH);
        return ERROR;
    }
    
    ++dev->numOpens;
    return (int)dev;
}

/* ------------------------------------------------------ */
/**
 * Close syslog device
 */
static int syslogClose ( SYSLOG_DEV *dev ) {
    if ( dev != NULL ) {
        if ( dev->numOpens > 0 )
            --dev->numOpens;
        return OK;
    }
    return ERROR;
}

/* ------------------------------------------------------ */
/**
 * Write data to syslog device
 */
static int syslogWrite ( SYSLOG_DEV *dev, char *buffer, int nbytes ) {    
    static char msg[SYSLOG_MSG_LENGTH] = { '\0' };
    static int idx = 0;
    int p;    
    (void)dev;
    
    if ( nbytes <= 0 )
        return 0;
    
    p = 0;
    while ( p < nbytes ) {
        if ( (buffer[p] == '\n') || (buffer[p] == '\0') ) {  
            /* End of line detected */
            msg[idx] = '\0';
            syslog(logMsg_facility, logMsg_severity, msg);
            idx = 0;
        } else {
            msg[idx] = buffer[p];
            idx++;
            if ( (buffer[p] == '%') && (idx < SYSLOG_MSG_LENGTH) ) {
                /* '%' character has a special meaning in printf(), have to replace it by '%%' */
                msg[idx] = '%';
                idx++;
            }
            if ( idx >= SYSLOG_MSG_LENGTH ) {
                /* Overflow detected */
                msg[SYSLOG_MSG_LENGTH - 1] = '\0';
                if ( msg[SYSLOG_MSG_LENGTH - 2] == '%' &&
                     msg[SYSLOG_MSG_LENGTH - 3] != '%' ) {
                    /* Uncomplete formatter */
                    msg[SYSLOG_MSG_LENGTH - 2] = '\0';
                }
                syslog(logMsg_facility, logMsg_severity, msg);
                idx = 0;                
            }
        }
        p++;
    }
    
    /* If stdio is redirected, copy data to console as well */    
    if ( stdioFd != ERROR ) {
        write(stdioFd, buffer, nbytes);
    }
    
    
    return nbytes;
}

/* ------------------------------------------------------ */
/**
 * Message logging task
 * @return ERROR on exit
 */
STATUS syslogTask ( void ) {
    char message[SYSLOG_MSG_LENGTH+1];
    int msgLen, sendLen;
    
    while ( 1 ) {
        msgLen = msgQReceive(msgLogQId, (char *)&message, SYSLOG_MSG_LENGTH, SYSLOG_QUEUE_TIMEOUT);
        if ( msgLen == ERROR ) {
            /* The error may be because of timeout, don't care */
            if ( errno != S_objLib_OBJ_TIMEOUT ) {
                NATIVE_MSG("%s: msgQreceive failed: %s\n", __FUNCTION__, strerror(errno));
                return ERROR;
            }
        } else if ( msgLen != SYSLOG_MSG_LENGTH) {
            NATIVE_MSG("%s: invalid message length: %d (%d required)\n", __FUNCTION__, msgLen, SYSLOG_MSG_LENGTH);
        } else {
            message[SYSLOG_MSG_LENGTH] = '\0';
            if ( msgSocket > 0 ) {
                sendLen = sendto(msgSocket, message, strlen(message), MSG_DONTWAIT,
                                (struct sockaddr*)&msgServerAddr, sizeof(struct sockaddr_in));
                if ( sendLen < 0 ) {
                    NATIVE_MSG("%s: sendto failed: %s\n", __FUNCTION__, strerror(errno));
                }
            }            
        }
        
        if ( stdioFd != ERROR && syslogFd != ERROR ) {
            /* Redirection has been enabled */
            if ( ioGlobalStdGet(1) != syslogFd || ioGlobalStdGet(2) != syslogFd ) {
                /* Redirection has been captured by some other task (rlogin?) */
                stdioFd = ioGlobalStdGet(1);
                logFdSet(syslogFd);
                ioGlobalStdSet(1, syslogFd);
                ioGlobalStdSet(2, syslogFd);
            }
        }
        
    }
    
    return OK;
}

/* ------------------------------------------------------ */
/**
 * Log a message
 */
void syslog ( int facility, int severity, const char *fmt, ... ) {
    STATUS rc;
    va_list ap;
    char buffer[SYSLOG_MSG_LENGTH];
    int len = 0;
    int h, m, s, ms;
    struct timespec tp;
    
    /* Getting current (absolute) time */
    rc = clock_gettime(CLOCK_REALTIME, &tp);
    ms = (int)(tp.tv_nsec / 1000000L);
    
    s = tp.tv_sec % 60;     tp.tv_sec /= 60;
    m = tp.tv_sec % 60;     tp.tv_sec /= 60;
    h = tp.tv_sec % 24;
    
    memset(buffer, 0, SYSLOG_MSG_LENGTH);
    
    len = sprintf(buffer, "<%d> [%02d:%02d:%02d.%03d] ",
                    facility * 8 + (severity & LOG_PRIMASK), h, m, s, ms);
    
    va_start(ap, fmt);
    len += vsprintf(&buffer[len], fmt, ap);
    va_end(ap);
    
    rc = msgQSend(msgLogQId, (char *)buffer, SYSLOG_MSG_LENGTH, NO_WAIT, MSG_PRI_NORMAL);
    
    if ( rc == ERROR ) {
        NATIVE_MSG("%s: msgQSend failed: %s\n", __FUNCTION__, strerror(errno));
    }
    
}

/* ------------------------------------------------------ */

void syslogInit ( ) {        
    /* Installing driver */
    if ( syslogDrv() == ERROR ) {
        NATIVE_MSG("%s: Cannot initialize syslog driver: %s\n", __FUNCTION__, strerror(errno));
    } else {
        if ( syslogDevCreate() == ERROR ) {
            NATIVE_MSG("%s: Cannot create syslog device: %s\n", __FUNCTION__, strerror(errno));
        }
    }
    
    /* Dispose existing task if already exists */
    if ( msgLogTaskId != 0 ) {
        taskDelete(msgLogTaskId);
        msgLogTaskId = 0;
    }
    
    /* Dispoae existing queue if already exists */
    if ( msgLogQId != NULL ) {
        msgQDelete(msgLogQId);
        msgLogQId = NULL;
    }
    
    /* Close existing connection if exists */
    if ( msgSocket != 0 ) {
        close(msgSocket);
        msgSocket = 0;
    }
    
    if ( !getenv(SYSLOG_HOST) ) {
        NATIVE_MSG("%s: SYSLOG_HOST variable is not defined.\n", __FUNCTION__);
    } else {
        if ( !getenv(SYSLOG_PORT) ) {
            NATIVE_MSG("%s: SYSLOG_PORT variable is not defined.\n", __FUNCTION__);
        } else {
            /* Establishing network connection to the logging server */
            bzero((char *)&msgServerAddr, sizeof(struct sockaddr_in));
            msgServerAddr.sin_family = AF_INET;
            msgServerAddr.sin_port = atoi(getenv(SYSLOG_PORT));
            if ( ((msgServerAddr.sin_addr.s_addr = inet_addr(getenv(SYSLOG_HOST))) == (unsigned)ERROR) &&
                 ((msgServerAddr.sin_addr.s_addr = hostGetByName(getenv(SYSLOG_HOST))) == (unsigned)ERROR) ) {
                NATIVE_MSG("%s: Cannot resolve host %s:%s\n", __FUNCTION__, getenv(SYSLOG_HOST), getenv(SYSLOG_PORT));                 
            } else {
                msgSocket = socket(AF_INET, SOCK_DGRAM, 0);
                if ( msgSocket == ERROR ) {
                    NATIVE_MSG("%s: socket failed: %s\n", __FUNCTION__, strerror(errno));
                    msgSocket = 0;
                }
            }
        }
    }
    
    if ( gethostname(hostname, 128) == ERROR ) {
        NATIVE_MSG("%s: gethostname failed: %s\n", __FUNCTION__, strerror(errno));
    }
    
    /* Create a message queue for the logging task */
    msgLogQId = msgQCreate(SYSLOG_QUEUE_LENGTH, SYSLOG_MSG_LENGTH, MSG_Q_FIFO);
    if ( msgLogQId == NULL ) {
        NATIVE_MSG("%s: msgQCreate failed: %s\n", __FUNCTION__, strerror(errno));
        return;
    }
    
    /* Spawn the message logging task */
    msgLogTaskId = taskSpawn("tSyslog", SYSLOG_PRIORITY, 0, SYSLOG_STACK,
                             (FUNCPTR)syslogTask,
                             0,0,0,0,0,0,0,0,0,0);
    if ( msgLogTaskId == ERROR ) {
        NATIVE_MSG("%s: taskSpawn failed: %s\n", __FUNCTION__, strerror(errno));
        return;
    }
    
}

/* ------------------------------------------------------ */

void syslogRedirectEnable ( int facility, int severity ) {
    if ( syslogFd == ERROR ) {
        syslogFd = open(SYSLOG_DEV_NAME, O_WRONLY, 0644);
        if ( syslogFd != ERROR ) {
            logMsg_facility = facility;
            logMsg_severity = severity;
            /* Redirecting stdio */
            stdioFd = ioGlobalStdGet(1);
            ioGlobalStdSet(1, syslogFd);
            ioGlobalStdSet(2, syslogFd);
            /* Redirecting logMsg */
            logFdSet(syslogFd);
        } else {
            NATIVE_MSG("%s: Cannot open '%s'\n", __FUNCTION__, SYSLOG_DEV_NAME);
        }
    } else {
        NATIVE_MSG("%s: Redirection has been already activated\n", __FUNCTION__);
    }
    
}

/* ------------------------------------------------------ */

void syslogRedirectDisable ( ) {
    if ( syslogFd == ERROR ) {
        NATIVE_MSG("%s: Redirection has not been yet activated\n", __FUNCTION__);
    } else {
        logFdSet(stdioFd);    
        ioGlobalStdSet(1, stdioFd); 
        ioGlobalStdSet(2, stdioFd);
        stdioFd = ERROR;
        close(syslogFd);
        syslogFd = ERROR;
    }    
}

/* ------------------------------------------------------ */
/* End of file */
