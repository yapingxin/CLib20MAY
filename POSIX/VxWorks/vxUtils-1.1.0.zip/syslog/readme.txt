/*******************************************************************************
 *  Copyright (c) 2009, Arthur Benilov
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

This library contains an implementation of syslog client that can send
syslog messages to a remote server via UDP protocol.

Features:
---------

Library provides basic functionality of a syslog client.
It allows as well redirecting of logMsg() and printf() (stdio, stderr) output
to syslog server by installing a special driver.

Syslog client works the same way as logMsg() function does. It sends a message
to a dedicated queue. A separate syslog task then fetches the message from the queue
and sends it to a server as an UDP message. This means that call to syslog() function
does not block and can be safely used in tasks and interrupts.

Configuration and usage:
------------------------

In order to make the client functional, you have to define to environmental
variables: SYSLOG_HOST and SYSLOG_PORT. The first one defines a host name or
an IP address of your syslog server, and the other one is for syslog port number.
According to specification syslog port should be set to 514 for UDP. But if
your syslog server listens to a different port, you have to change this value.
Variables SYSLOG_HOST and SYSLOG_PORT can be defined in your boot script
using setenv function:

setenv SYSLOG_HOST 10.11.12.13
setenv SYSLOG_PORT 514

Please see example of syslog client usage in file example.c.

Changes in version 1.1.0
---------------------------
- Message buffer increased from 1024 to 1280 bytes
- Console interception added, allowing redirecting everything a user types in console
- Fixed bug with '%' symbol in messages
- Fixed bug with message buffer overflow for very long messages


--------------------------------------------------------------------------------
2009, by Arthur Benilov (arthur.benilov@gmail.com)
